# brandQED — PHP + MySQL website

A responsive, dark premium brand-agency website starter for cPanel shared hosting. PHP 8.1+, MySQL/MariaDB and PDO; no Composer, Node or build step.

## Important scope note
The public pages, contact inquiry storage, database seed content, one-time admin setup, login protection, settings editor, inquiry list/CSV export and password change are implemented. The requested full CRUD managers for every content type, drag-and-drop gallery, media library, forgot-password email workflow, rich-text editor, favicon generation, WebP conversion, SMTP transport and database export are **not included in this initial release**. Those should be added and security-tested before treating the admin as a complete CMS. Sample projects/testimonials are clearly flagged in the database and must be replaced before launch.

## Requirements
- PHP 8.1+ with `pdo_mysql`, `gd` (optional in this build), `fileinfo`, `mbstring`
- MySQL 5.7+ or MariaDB 10.4+
- Apache with `mod_rewrite`, `mod_headers`, `mod_deflate`
- SSL certificate (cPanel AutoSSL recommended)

## cPanel installation
1. In cPanel → **MySQL Databases**, create a database and a database user. Assign the user **ALL PRIVILEGES** to the database. cPanel may prefix both names.
2. Open **phpMyAdmin**, select the new database, choose Import, and import `database.sql`. If your host does not allow `CREATE DATABASE`/`USE`, remove those first two SQL lines before importing into the selected database.
3. Upload the `brandqed` folder contents to your hosting account. Place the contents of `public_html/` inside your domain's actual `public_html/` document root. Keep `includes/` and `config/` one directory above that document root where possible.
4. Copy `config/config.sample.php` to `config/config.php`. Edit database host, database name, username, password and `site_url`. Keep `config.php` private and never upload it to a public folder.
5. Confirm `includes/db.php` points to the private `config/config.php` location. The provided structure expects `includes/` and `config/` beside `public_html/`.
6. Visit `https://your-domain.com/install.php`. Set a unique admin username, email and password (12+ characters). After successful setup, **delete `public_html/install.php`**. The installer also creates `.installed` as a second lock.
7. Visit `/admin/login.php`. Update hero text, email, WhatsApp and SEO defaults under Site settings. Replace sample portfolio and testimonial content directly in the database until their full CRUD managers are implemented.
8. In cPanel → **SSL/TLS Status** or AutoSSL, issue an SSL certificate. The root `.htaccess` redirects HTTP to HTTPS; temporarily disable that redirect if SSL is not ready.
9. In cPanel → **Select PHP Version**, choose PHP 8.1 or newer and enable `pdo_mysql`, `fileinfo`, and `mbstring`.
10. Contact notifications use PHP `mail()` as a fallback. Set a valid domain mailbox in `contact_email`; for reliable delivery, configure authenticated SMTP through a maintained mail library in a future deployment.
11. Add `https://your-domain.com/sitemap.php` to Google Search Console. Configure analytics only after adding a consent/privacy approach appropriate to your visitors and jurisdiction.
12. Back up both the database (phpMyAdmin → Export) and the complete website folder before updates.

## Folder placement
```
brandqed/
├── public_html/       # upload contents into the domain document root
├── includes/          # private PHP helpers
├── config/            # private config files
├── database.sql
└── README.md
```

## Security and deployment notes
- Use a strong unique admin password and HTTPS.
- Restrict access to `config/` and `includes/` at the server level; never put credentials in `public_html`.
- `uploads/.htaccess` disables PHP execution in uploads. Keep uploads writable only as needed (normally 755 directories, 644 files).
- PDO prepared statements are used for database access. User-visible text is escaped with `htmlspecialchars`; About/legal rich text passes through a small allow-list sanitizer.
- Login has IP-based throttling. The contact form uses CSRF, a honeypot and a time-based session rate limit. For high-traffic production, move rate limiting to a database/IP + email keyed implementation and add proxy-aware IP handling carefully.
- Review legal copy, privacy obligations, analytics, cookies, accessibility and CSP before launch. Add a restrictive Content-Security-Policy after confirming all required CDN/font sources.
- This starter intentionally does not permit SVG uploads; sanitizing arbitrary SVG safely requires a dedicated sanitizer. Raster image uploads are MIME-checked and renamed.
- Never keep `install.php` on the live server.

## Troubleshooting
- **500 error:** check cPanel Errors and PHP error logs; verify PHP version and `.htaccess` modules.
- **Blank page:** enable error logging in hosting PHP settings; do not display errors publicly.
- **Database connection failure:** check cPanel-prefixed DB/user names, password, host and privileges in `config.php`.
- **Uploads fail:** check upload limits and folder permissions; this starter's upload helper allows 5 MB.
- **Clean URLs fail:** ensure `mod_rewrite` is enabled and `.htaccess` is allowed by the host.
- **Email not received:** check spam, domain DNS (SPF/DKIM), PHP mail availability and mailbox configuration.
