<?php
$pageTitle='Our brand building process | brandQED';require dirname(__DIR__,2).'/includes/header.php';
$steps=db()->query("SELECT * FROM process_steps ORDER BY sort_order")->fetchAll();
?><section class="page-hero"><span class="eyebrow">OUR PROCESS</span><h1>Clarity first.<br><em>Great work follows.</em></h1><p class="lead">A collaborative process that keeps the big picture clear and the details considered.</p></section><section class="section timeline"><?php foreach($steps as $i=>$s):?><article><b>0<?=($i+1)?></b><div><h2><?=e($s['title'])?></h2><p><?=e($s['description'])?></p><small><?=e($s['duration'])?></small></div></article><?php endforeach;?></section><?php require dirname(__DIR__,2).'/includes/footer.php';?>
