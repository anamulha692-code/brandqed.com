<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/functions.php';
session_name('brandqed_install');session_start();
if(file_exists(__DIR__.'/.installed')) exit('Installer is locked. Remove this file only if you intentionally need to reinstall.');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$u=trim($_POST['username']??'');$email=filter_var($_POST['email']??'',FILTER_VALIDATE_EMAIL);$pass=$_POST['password']??'';
 if(strlen($u)<4||!$email||strlen($pass)<12)$error='Use a username of at least 4 characters, a valid email, and a password of at least 12 characters.';
 else { $q=db()->prepare("INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,NOW())");$q->execute([$u,$email,password_hash($pass,PASSWORD_DEFAULT)]);file_put_contents(__DIR__.'/.installed','installed '.date(DATE_ATOM));echo 'Admin account created. Delete install.php now, then log in at /admin/login.php.';exit; }
}
?><!doctype html><html lang="en"><meta charset="utf-8"><link rel="stylesheet" href="<?=url('assets/css/style.css')?>"><body><section class="page-hero"><form class="card contact-form" method="post" style="max-width:520px;margin:auto"><h2>Set up your admin</h2><p>This one-time installer creates your first administrator.</p><?php if($error)echo '<p>'.e($error).'</p>';?><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><label>Username<input name="username" required minlength="4"></label><label>Email<input name="email" type="email" required></label><label>Password (12+ characters)<input name="password" type="password" minlength="12" required></label><button class="btn">Create admin account</button></form></section></body></html>
