<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/functions.php';
$path=trim(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH),'/');
if($path==='') $path='home';
$routes=['home'=>'home.php','services'=>'services.php','work'=>'work.php','packages'=>'packages.php','process'=>'process.php','about'=>'about.php','contact'=>'contact.php','privacy'=>'legal.php','terms'=>'legal.php'];
if(str_starts_with($path,'work/')) { $_GET['slug']=substr($path,5); require __DIR__.'/pages/project.php'; exit; }
if(isset($routes[$path])) { require __DIR__.'/pages/'.$routes[$path]; exit; }
http_response_code(404); require __DIR__.'/pages/404.php';
