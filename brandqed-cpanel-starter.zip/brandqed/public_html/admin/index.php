<?php
require_once dirname(__DIR__,2).'/includes/functions.php';
session_name('brandqed_admin');session_start();require_once dirname(__DIR__,2).'/includes/auth.php';enforce_admin_session();admin_only();
header('Location: dashboard.php');exit;
