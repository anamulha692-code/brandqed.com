<?php
$pageTitle=$pageTitle??setting('seo_title','Brand strategy & identity studio | brandQED');
$pageDescription=$pageDescription??setting('seo_description','Strategy, naming and distinctive brand identity for ambitious businesses.');
$canonical=url(trim(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH),'/'));
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=e($pageTitle)?></title><meta name="description" content="<?=e($pageDescription)?>"><link rel="canonical" href="<?=e($canonical)?>">
<meta property="og:type" content="website"><meta property="og:title" content="<?=e($pageTitle)?>"><meta property="og:description" content="<?=e($pageDescription)?>"><meta property="og:url" content="<?=e($canonical)?>">
<meta name="theme-color" content="#070707"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?=url('assets/css/style.css')?>"><script defer src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script><script defer src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script><script defer src="<?=url('assets/js/site.js')?>"></script></head><body>
<header class="nav"><a class="wordmark" href="<?=url()?>">brand<span>QED</span><i></i></a><button class="menu-toggle" aria-label="Toggle navigation">☰</button><nav id="navlinks"><a href="<?=url('services')?>">Services</a><a href="<?=url('work')?>">Work</a><a href="<?=url('packages')?>">Packages</a><a href="<?=url('process')?>">Process</a><a href="<?=url('about')?>">About</a><a href="<?=url('contact')?>">Contact</a><a class="btn btn-small" href="<?=url('contact')?>">Book a Call ↗</a></nav></header><main>
