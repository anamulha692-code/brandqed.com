<?php
declare(strict_types=1);
function upload_image(string $field, array $allowed=['jpg','jpeg','png','webp','ico']): ?string {
  if(empty($_FILES[$field]['name'])) return null;
  $f=$_FILES[$field];
  if($f['error']!==UPLOAD_ERR_OK || $f['size']>5*1024*1024) throw new RuntimeException('Upload failed or file exceeds 5 MB.');
  $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
  if(!in_array($ext,$allowed,true)) throw new RuntimeException('File extension not allowed.');
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  $valid=['image/jpeg','image/png','image/webp','image/x-icon','image/vnd.microsoft.icon'];
  if(!in_array($mime,$valid,true)) throw new RuntimeException('Invalid image file.');
  $name=bin2hex(random_bytes(16)).'.'.$ext;
  $dir=dirname(__DIR__).'/public_html/uploads/';
  if(!is_dir($dir)) mkdir($dir,0755,true);
  if(!move_uploaded_file($f['tmp_name'],$dir.$name)) throw new RuntimeException('Could not save upload.');
  return $name;
}
