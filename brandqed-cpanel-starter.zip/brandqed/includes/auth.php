<?php
declare(strict_types=1);
require_once __DIR__.'/functions.php';
function login_admin(string $identity,string $password): bool {
  $ip=$_SERVER['REMOTE_ADDR']??'unknown';
  $q=db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address=? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
  $q->execute([$ip]); if((int)$q->fetchColumn()>=8) return false;
  $q=db()->prepare("SELECT * FROM users WHERE username=? OR email=? LIMIT 1"); $q->execute([$identity,$identity]); $u=$q->fetch();
  if(!$u || !password_verify($password,$u['password_hash'])) {
    db()->prepare("INSERT INTO login_attempts(ip_address,identity,attempted_at) VALUES(?,?,NOW())")->execute([$ip,$identity]); return false;
  }
  session_regenerate_id(true); $_SESSION['admin_id']=$u['id']; $_SESSION['admin_name']=$u['username']; $_SESSION['last_activity']=time();
  db()->prepare("DELETE FROM login_attempts WHERE ip_address=?")->execute([$ip]); return true;
}
function enforce_admin_session(): void {
  global $config;
  if(!empty($_SESSION['admin_id']) && time()-($_SESSION['last_activity']??0) > ($config['session_timeout']??1800)) { session_unset(); session_destroy(); }
  if(!empty($_SESSION['admin_id'])) $_SESSION['last_activity']=time();
}
