<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function setting(string $key, string $default=''): string {
  static $cache=null;
  if ($cache===null) { $cache=[]; try { foreach(db()->query("SELECT setting_key,setting_value FROM settings") as $r) $cache[$r['setting_key']]=$r['setting_value']; } catch(Throwable $x) {} }
  return (string)($cache[$key] ?? $default);
}
function url(string $path=''): string { global $config; return rtrim($config['site_url'],'/').'/'.ltrim($path,'/'); }
function redirect(string $to): never { header('Location: '.$to); exit; }
function slugify(string $s): string { $s=strtolower(trim($s)); $s=preg_replace('/[^a-z0-9]+/','-',$s); return trim($s,'-') ?: 'project'; }
function flash(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function get_flash(): ?array { $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function csrf_token(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_check(): void { if(!hash_equals($_SESSION['csrf']??'', $_POST['_csrf']??'')) { http_response_code(419); exit('Session expired. Please go back and try again.'); } }
function admin_only(): void { if(empty($_SESSION['admin_id'])) redirect(url('admin/login.php')); }
function site_setting(string $k,string $d=''): string { return setting($k,$d); }
function project_image(array $p): string { return !empty($p['cover_image']) ? url('uploads/'.rawurlencode($p['cover_image'])) : url('assets/img/project-placeholder.svg'); }
function notify_admin(string $subject,string $body): bool {
  global $config; $to=setting('contact_email',$config['admin_email']??'');
  $from=setting('contact_email',$config['admin_email']??'no-reply@brandqed.com');
  $headers="From: brandQED <".str_replace(["\r","\n"],'',$from).">\r\nContent-Type: text/plain; charset=UTF-8";
  return $to ? @mail($to, '=?UTF-8?B?'.base64_encode($subject).'?=', $body, $headers) : false;
}
function clean_rich(string $html): string {
  $allowed='<p><br><strong><b><em><i><ul><ol><li><h2><h3><a><blockquote>';
  $html=strip_tags($html,$allowed);
  return preg_replace_callback('/<a\b([^>]*)>/i',function($m){
    preg_match('/href=["\'](https?:\/\/[^"\']+)["\']/i',$m[1],$u);
    return isset($u[1])?'<a href="'.e($u[1]).'" rel="noopener noreferrer">':'<a>';
  },$html);
}
