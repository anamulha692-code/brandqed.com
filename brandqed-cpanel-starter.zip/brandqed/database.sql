CREATE DATABASE IF NOT EXISTS brandqed CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE brandqed;
SET NAMES utf8mb4;
CREATE TABLE users(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,username VARCHAR(80) NOT NULL UNIQUE,email VARCHAR(190) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,created_at DATETIME NOT NULL) ENGINE=InnoDB;
CREATE TABLE settings(setting_key VARCHAR(100) PRIMARY KEY,setting_value LONGTEXT NOT NULL) ENGINE=InnoDB;
CREATE TABLE projects(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(190) NOT NULL,slug VARCHAR(200) NOT NULL UNIQUE,client_name VARCHAR(190) DEFAULT '',industry VARCHAR(120) DEFAULT '',country VARCHAR(120) DEFAULT '',category VARCHAR(120) DEFAULT 'Brand Identity',year VARCHAR(10) DEFAULT '',cover_image VARCHAR(255) DEFAULT '',overview TEXT,challenge TEXT,solution TEXT,result TEXT,website_url VARCHAR(500) DEFAULT '',is_featured TINYINT(1) DEFAULT 0,status ENUM('draft','published') DEFAULT 'draft',sort_order INT DEFAULT 0,is_sample TINYINT(1) DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,INDEX(status,is_featured,sort_order)) ENGINE=InnoDB;
CREATE TABLE project_images(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,project_id INT UNSIGNED NOT NULL,image VARCHAR(255) NOT NULL,sort_order INT DEFAULT 0,FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE clients(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(190),logo VARCHAR(255),url VARCHAR(500),sort_order INT DEFAULT 0) ENGINE=InnoDB;
CREATE TABLE testimonials(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(190),role VARCHAR(190),company VARCHAR(190),country VARCHAR(100),photo VARCHAR(255),quote TEXT,rating TINYINT DEFAULT 5,sort_order INT DEFAULT 0,visible TINYINT(1) DEFAULT 1,is_sample TINYINT(1) DEFAULT 0) ENGINE=InnoDB;
CREATE TABLE services(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(190),promise VARCHAR(500),bullets TEXT,best_for VARCHAR(500),timeline VARCHAR(100),icon VARCHAR(40),sort_order INT DEFAULT 0) ENGINE=InnoDB;
CREATE TABLE service_points(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,service_id INT UNSIGNED,point_text VARCHAR(500),sort_order INT DEFAULT 0,FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE packages(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),price VARCHAR(80),billing_note VARCHAR(255),features TEXT,popular TINYINT(1) DEFAULT 0,sort_order INT DEFAULT 0) ENGINE=InnoDB;
CREATE TABLE package_features(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,package_id INT UNSIGNED,feature VARCHAR(255),sort_order INT DEFAULT 0,FOREIGN KEY(package_id) REFERENCES packages(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE process_steps(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(150),description TEXT,duration VARCHAR(100),sort_order INT DEFAULT 0) ENGINE=InnoDB;
CREATE TABLE faqs(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,question VARCHAR(500),answer TEXT,sort_order INT DEFAULT 0,visible TINYINT(1) DEFAULT 1) ENGINE=InnoDB;
CREATE TABLE pages(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,slug VARCHAR(100) UNIQUE,title VARCHAR(190),content LONGTEXT) ENGINE=InnoDB;
CREATE TABLE inquiries(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120),email VARCHAR(190),company VARCHAR(190),service VARCHAR(190),budget VARCHAR(100),details TEXT,status ENUM('new','read','replied') DEFAULT 'new',created_at DATETIME,INDEX(created_at),INDEX(status)) ENGINE=InnoDB;
CREATE TABLE login_attempts(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,ip_address VARCHAR(45),identity VARCHAR(190),attempted_at DATETIME,INDEX(ip_address,attempted_at)) ENGINE=InnoDB;
CREATE TABLE media(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,filename VARCHAR(255),original_name VARCHAR(255),mime_type VARCHAR(100),size_bytes INT UNSIGNED,created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
INSERT INTO settings(setting_key,setting_value) VALUES
('hero_title','We build brands people remember and trust.'),('hero_subtitle','Strategy, naming, identity and launch, all under one roof.'),('whatsapp','+8801783475407'),('contact_email','hello@brandqed.com'),('footer_text','Thoughtful strategy. Distinctive identities. Brands built to move forward.'),('seo_title','Brand strategy & identity studio | brandQED'),('seo_description','Strategy, naming and distinctive brand identity for ambitious businesses.');
CREATE TABLE stats(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,value INT NOT NULL,label VARCHAR(100),sort_order INT DEFAULT 0) ENGINE=InnoDB;
INSERT INTO stats(value,label,sort_order) VALUES(45,'Brands built',1),(80,'Projects delivered',2),(12,'Countries served',3),(5,'Years experience',4);

INSERT INTO services(title,promise,bullets,best_for,timeline,icon,sort_order) VALUES
('Brand Strategy','Find the focus that makes your brand matter.','Research & positioning\nAudience personas\nPurpose, mission, vision & values\nPersonality and tone of voice\nGo-to-market roadmap','Founders defining a new direction or preparing to scale.','2–4 weeks','✳',1),
('Naming & Messaging','Give your business a name and a voice worth remembering.','Brand naming\nDomain and social handle checks\nTagline development\nBrand story\nMessaging guide and copywriting','New ventures, product launches and repositioning.','1–3 weeks','Aa',2),
('Brand Identity Design','Turn your strategy into a distinctive visual world.','Logo system\nColour palette and typography\nBrand guidelines\nStationery and packaging\nSocial templates and mockups','Startups and growing businesses ready for a cohesive identity.','3–5 weeks','◈',3),
('Digital Launch','Bring your brand into the places customers meet you.','Website or landing page\nSocial media setup\nLaunch campaign plan\nAds setup\nSEO essentials','Businesses preparing to launch or refresh their digital presence.','2–6 weeks','↗',4);
INSERT INTO packages(name,price,billing_note,features,popular,sort_order) VALUES
('Starter','$490','One-time project','Discovery questionnaire\nCustom name and logo direction\nPrimary logo and variations\nColour and typography palette\nEssential brand guide',0,1),
('Launch','$1,490','One-time project','Everything in Starter\nBrand positioning workshop\nFull visual identity system\nWebsite or landing page design\nSocial media launch kit\nBrand guidelines',1,2),
('Growth','Custom quote','Scoped to your goals','Everything in Launch\nMarketing direction\nCampaign creative support\nMonthly brand partnership\nOngoing design support\nQuarterly brand review',0,3);
INSERT INTO process_steps(title,description,duration,sort_order) VALUES
('Discovery','We learn about your business, audience, ambitions and the challenge to solve.','3–5 days',1),
('Strategy','We define the positioning, story and direction that guide every decision.','1–2 weeks',2),
('Design','We translate the strategy into a distinctive, flexible identity system.','1–3 weeks',3),
('Review & Revisions','We present the work, gather considered feedback and refine the details together.','1 week',4),
('Delivery & Launch','You receive organised final files and guidance to put your brand to work.','2–4 days',5);
INSERT INTO faqs(question,answer,sort_order) VALUES
('Who do you work with?','We partner with founders, startups and growing businesses across a range of industries and markets.',1),
('Can I work with you from another country?','Absolutely. Our process is remote-friendly, with clear communication and scheduled calls.',2),
('How long does a brand identity project take?','Most identity projects take three to five weeks, depending on scope and feedback timelines.',3),
('What files will I receive?','Final deliverables are agreed in the project scope and can include editable vector files, exports and a brand guide.',4),
('Do you offer revisions?','Yes. Each proposal outlines review rounds and how feedback is handled.',5),
('Can you design a website too?','Website and landing-page design are available as part of Digital Launch or a tailored scope.',6),
('How do we get started?','Send an inquiry with a little context. We will reply to arrange a discovery conversation.',7),
('Do you offer ongoing support?','Yes. Monthly Brand Support can help keep your identity consistent as your business evolves.',8);
INSERT INTO testimonials(name,role,company,country,quote,rating,sort_order,visible,is_sample) VALUES
('Alex Morgan','Founder','Northstar Studio','United Kingdom','A thoughtful process and an identity that finally feels like our business.',5,1,1,1),
('Jordan Lee','Co-founder','Fieldnote','United States','Clear communication, strong creative thinking and a polished result.',5,2,1,1),
('Sam Taylor','Director','Forma Works','Australia','The new brand gave our team confidence and consistency across every touchpoint.',5,3,1,1);
INSERT INTO projects(title,slug,client_name,industry,country,category,year,overview,challenge,solution,result,is_featured,status,is_sample,sort_order) VALUES
('Northstar Studio','northstar-studio','Northstar Studio','Professional Services','United Kingdom','Brand Identity','2025','A confident identity for a modern advisory studio.','The business needed to communicate expertise without feeling traditional.','A clear typographic system and warm, considered visual language.','A flexible identity designed to work across digital and print touchpoints.',1,'published',1,1),
('Fieldnote','fieldnote','Fieldnote','Technology','United States','Brand Strategy','2025','A human-centred brand direction for a growing digital product.','A complex offer needed a simpler, more memorable story.','A focused positioning platform supported by a distinctive identity direction.','A consistent foundation for launch communications.',1,'published',1,2),
('Forma Works','forma-works','Forma Works','Architecture','Australia','Visual Identity','2024','A refined identity for a practice shaping better spaces.','The existing presentation lacked consistency across applications.','A flexible mark, restrained palette and practical brand rules.','A cohesive identity across key customer touchpoints.',1,'published',1,3);
INSERT INTO pages(slug,title,content) VALUES
('about','About brandQED','<p>brandQED is an independent brand consultancy helping ambitious businesses build clarity, confidence and recognition. We bring strategy and design together so every part of your brand works toward the same purpose.</p><h2>Our values</h2><ul><li>Clarity over complexity</li><li>Curiosity with purpose</li><li>Craft in every detail</li><li>Partnership built on trust</li></ul>'),
('privacy','Privacy Policy','<p>We use the information you submit through our contact form only to respond to your inquiry and manage potential projects. We do not sell personal information. Contact us to request access or correction of your information.</p>'),
('terms','Terms','<p>Website content is provided for general information. Project scope, fees, timelines, revisions and ownership terms are confirmed in a separate written proposal or agreement.</p>');
