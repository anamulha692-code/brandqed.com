<?php
declare(strict_types=1);
/* Copy to config.php and edit these values. Keep config.php private. */
return [
  'db' => ['host'=>'localhost','name'=>'YOUR_DB_NAME','user'=>'YOUR_DB_USER','pass'=>'YOUR_DB_PASSWORD','charset'=>'utf8mb4'],
  'site_url' => 'https://brandqed.com',
  'site_name' => 'brandQED',
  'admin_email' => 'hello@brandqed.com',
  'timezone' => 'Asia/Dhaka',
  'session_timeout' => 1800,
  'smtp' => ['host'=>'','port'=>587,'username'=>'','password'=>'','encryption'=>'tls','from_email'=>'hello@brandqed.com','from_name'=>'brandQED']
];
