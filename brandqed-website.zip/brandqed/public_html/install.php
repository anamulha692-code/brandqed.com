<?php
/**
 * One-time setup: creates the owner admin account.
 * Needs the install_key from config/config.php so strangers cannot use it.
 * It locks itself and tries to delete itself afterwards. Delete it manually if it is still there.
 */
declare(strict_types=1);
require __DIR__ . '/../includes/init.php';
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store');

$lock = BASE_PATH . '/storage/install.lock';
$key = (string)cfg('install_key', '');
$errors = []; $done = false; $deleted = false; $closed = false; $dbProblem = false;

try { $hasUsers = (int)q_val('SELECT COUNT(*) FROM users') > 0; }
catch (Throwable $e) { $hasUsers = false; $dbProblem = true; }
if (is_file($lock) || $hasUsers) { $closed = true; }

if (!$closed && !$dbProblem && is_post()) {
    csrf_check();
    $u = clean_line((string)($_POST['username'] ?? ''), 40);
    $em = clean_line((string)($_POST['email'] ?? ''), 190);
    $p1 = (string)($_POST['password'] ?? ''); $p2 = (string)($_POST['password2'] ?? '');
    if ($key === '' || $key === 'CHANGE_ME_TO_A_LONG_RANDOM_TEXT' || !hash_equals($key, (string)($_POST['install_key'] ?? ''))) { $errors['install_key'] = 'The setup key does not match the install_key in config/config.php.'; }
    if (!preg_match('~^[A-Za-z0-9_.-]{3,40}$~', $u)) { $errors['username'] = 'Use 3 to 40 letters, numbers, dots, dashes or underscores.'; }
    if (!valid_email($em)) { $errors['email'] = 'Enter a valid email.'; }
    if ($p1 !== $p2) { $errors['password2'] = 'The two passwords do not match.'; }
    elseif (($pp = password_problem($p1)) !== '') { $errors['password'] = $pp; }
    if (!$errors) {
        q("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'owner')", [$u, $em, hash_password($p1)]);
        @file_put_contents($lock, 'installed ' . gmdate('c'));
        $done = true;
        $deleted = @unlink(__FILE__);
    }
}
$err = static fn(string $k): string => isset($GLOBALS['errors'][$k]) ? '<small class="a-error">' . e($GLOBALS['errors'][$k]) . '</small>' : '';
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow">
<title>Setup | brandQED</title>
<link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>"></head>
<body class="a-body a-auth"><main class="a-auth__box a-card">
<p class="a-brand">brand<b>QED</b> <small>setup</small></p>
<?php if ($done): ?>
  <h1>All set</h1>
  <div class="a-flash a-flash--success">Your admin account was created.</div>
  <?php if (!$deleted): ?><div class="a-flash a-flash--warn">Please delete <strong>install.php</strong> from your public_html folder now (cPanel File Manager). It is locked, but it should not stay.</div><?php endif; ?>
  <p><a class="a-btn a-btn--block" href="<?= e(admin_url('login.php')) ?>">Go to sign in</a></p>
<?php elseif ($closed): ?>
  <h1>Already installed</h1>
  <p>Setup has been completed. For safety, delete <strong>install.php</strong> from your public_html folder.</p>
<?php elseif ($dbProblem): ?>
  <h1>Database not ready</h1>
  <p>The tables were not found. Import <strong>database.sql</strong> in phpMyAdmin first, then reload this page.</p>
<?php else: ?>
  <h1>Create your admin account</h1>
  <form method="post" class="a-form"><?= csrf_field() ?>
    <div class="a-field"><label for="install_key">Setup key (from config/config.php)</label><input id="install_key" name="install_key" type="password" required autocomplete="off"><?= $err('install_key') ?></div>
    <div class="a-field"><label for="username">Username</label><input id="username" name="username" type="text" maxlength="40" required autocomplete="username"><?= $err('username') ?></div>
    <div class="a-field"><label for="email">Email</label><input id="email" name="email" type="email" required autocomplete="email"><?= $err('email') ?></div>
    <div class="a-field"><label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="new-password"><small class="a-hint">At least 10 characters, with letters and numbers.</small><?= $err('password') ?></div>
    <div class="a-field"><label for="password2">Repeat password</label><input id="password2" name="password2" type="password" required autocomplete="new-password"><?= $err('password2') ?></div>
    <button class="a-btn a-btn--block" type="submit">Create account</button>
  </form>
<?php endif; ?>
</main></body></html>
