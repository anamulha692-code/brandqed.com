/* brandQED public site. Small, dependency-light. GSAP is optional: the site works without it. */
(function () {
  'use strict';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  /* Mobile menu */
  var toggle = $('.nav__toggle'), links = $('#nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && links.classList.contains('is-open')) { toggle.click(); toggle.focus(); }
    });
    $$('a', links).forEach(function (a) { a.addEventListener('click', function () { if (links.classList.contains('is-open')) { toggle.click(); } }); });
  }

  /* Scroll reveal (IntersectionObserver, works without GSAP) */
  var revealSel = '.section__head,.stat,.card,.work-card,.step,.timeline__item,.testi,.faq details,.cta-band,.service-block__intro,.gallery figure,.case__block';
  var items = $$(revealSel);
  items.forEach(function (el, i) { el.classList.add('reveal'); el.style.setProperty('--d', ((i % 4) * 0.07) + 's'); });
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    items.forEach(function (el) { io.observe(el); });
  } else { items.forEach(function (el) { el.classList.add('is-in'); }); }

  /* Number counters */
  function runCounter(el) {
    var end = parseInt(el.getAttribute('data-count'), 10);
    if (isNaN(end) || reduce) { return; }
    var start = null, dur = 1400;
    el.textContent = '0';
    function step(ts) {
      if (start === null) { start = ts; }
      var p = Math.min((ts - start) / dur, 1);
      el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3)));
      if (p < 1) { requestAnimationFrame(step); }
    }
    requestAnimationFrame(step);
  }
  var counters = $$('[data-count]');
  if (counters.length && 'IntersectionObserver' in window) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { runCounter(en.target); cio.unobserve(en.target); } });
    }, { threshold: 0.6 });
    counters.forEach(function (c) { cio.observe(c); });
  }

  /* Hero intro and parallax (only when GSAP loaded) */
  window.addEventListener('load', function () {
    if (!window.gsap || reduce) { return; }
    var tl = window.gsap.timeline({ defaults: { ease: 'power3.out' } });
    if ($('.hero__title')) {
      tl.from('.hero__ghost', { opacity: 0, y: 40, duration: 1.2 })
        .from('.hero__title', { opacity: 0, y: 40, duration: 0.9 }, '-=0.8')
        .from('.hero__sub', { opacity: 0, y: 24, duration: 0.7 }, '-=0.5')
        .from('.hero .btn-row .btn', { opacity: 0, y: 20, duration: 0.6, stagger: 0.1 }, '-=0.4')
        .from('.hero__trust', { opacity: 0, duration: 0.6 }, '-=0.2');
    }
    if (window.ScrollTrigger && $('.hero')) {
      window.gsap.registerPlugin(window.ScrollTrigger);
      window.gsap.to('.hero__orb', { yPercent: -18, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
      window.gsap.to('.hero__ghost', { yPercent: 14, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
    }
  });

  /* Work filters */
  var filters = $('[data-filters]'), grid = $('[data-work-grid]');
  if (filters && grid) {
    var empty = $('[data-empty]');
    filters.addEventListener('click', function (e) {
      var b = e.target.closest('[data-filter]');
      if (!b) { return; }
      var f = b.getAttribute('data-filter'), shown = 0;
      $$('[data-filter]', filters).forEach(function (x) {
        var on = x === b; x.classList.toggle('is-active', on); x.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      $$('.work-card', grid).forEach(function (c) {
        var show = f === 'all' || (c.getAttribute('data-cats') || '').split(' ').indexOf(f) > -1;
        c.hidden = !show; if (show) { shown++; c.classList.add('is-in'); }
      });
      if (empty) { empty.hidden = shown > 0; }
    });
  }

  /* Testimonial slider (all items stay visible if JS is off) */
  var slider = $('[data-slider]');
  if (slider) {
    var slides = $$('.testi__item', slider);
    if (slides.length > 1) {
      slider.classList.add('is-js');
      var idx = 0, timer = null;
      var dots = document.createElement('div'); dots.className = 'testi__dots';
      slides.forEach(function (_, i) {
        var d = document.createElement('button'); d.type = 'button'; d.setAttribute('aria-label', 'Show review ' + (i + 1));
        d.addEventListener('click', function () { go(i); play(); }); dots.appendChild(d);
      });
      slider.appendChild(dots);
      var go = function (i) {
        idx = (i + slides.length) % slides.length;
        slides.forEach(function (s, n) { s.classList.toggle('is-active', n === idx); });
        $$('button', dots).forEach(function (d, n) { d.setAttribute('aria-current', n === idx ? 'true' : 'false'); });
      };
      var play = function () { clearInterval(timer); if (!reduce) { timer = setInterval(function () { go(idx + 1); }, 7000); } };
      slider.addEventListener('mouseenter', function () { clearInterval(timer); });
      slider.addEventListener('mouseleave', play);
      go(0); play();
    }
  }
})();
