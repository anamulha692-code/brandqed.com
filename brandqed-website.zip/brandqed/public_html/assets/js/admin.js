/* brandQED admin helpers: menu, confirm dialogs, rich text, drag-to-sort gallery. */
(function () {
  'use strict';
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  var side = document.getElementById('a-side'), btn = document.querySelector('[data-toggle-side]');
  if (side && btn) { btn.addEventListener('click', function () { side.classList.toggle('is-open'); }); }

  $$('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) { e.preventDefault(); } });
  });

  /* Rich text editor (Quill) for the Pages screen */
  if (window.Quill) {
    $$('.a-rich[data-rich-for]').forEach(function (box) {
      var ta = document.getElementById(box.getAttribute('data-rich-for'));
      var q = new window.Quill(box, { theme: 'snow', modules: { toolbar: [[{ header: [2, 3, false] }], ['bold', 'italic', 'underline'], [{ list: 'ordered' }, { list: 'bullet' }], ['blockquote', 'link'], ['clean']] } });
      q.root.innerHTML = ta.value;
      var form = ta.closest('form');
      form.addEventListener('submit', function () { ta.value = q.root.innerHTML; });
    });
  }

  /* Drag to reorder gallery images */
  $$('[data-sortable]').forEach(function (list) {
    var input = document.getElementById(list.getAttribute('data-order-input')), dragged = null;
    var save = function () { input.value = $$('[data-id]', list).map(function (n) { return n.getAttribute('data-id'); }).join(','); };
    list.addEventListener('dragstart', function (e) {
      dragged = e.target.closest('[data-id]'); if (!dragged) { return; }
      dragged.classList.add('is-dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragged.getAttribute('data-id'));
    });
    list.addEventListener('dragover', function (e) {
      e.preventDefault();
      var over = e.target.closest('[data-id]');
      if (!dragged || !over || over === dragged) { return; }
      var r = over.getBoundingClientRect(), after = (e.clientX - r.left) > r.width / 2;
      list.insertBefore(dragged, after ? over.nextSibling : over);
    });
    list.addEventListener('dragend', function () { if (dragged) { dragged.classList.remove('is-dragging'); dragged = null; save(); } });
  });
})();
