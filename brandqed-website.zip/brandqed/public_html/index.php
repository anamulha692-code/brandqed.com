<?php
/**
 * Front controller: every public URL comes through here (see .htaccess).
 */
declare(strict_types=1);
require __DIR__ . '/../includes/init.php';

$path = trim((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? ''), '/');
if ($path === 'index.php') { $path = ''; }
if (!preg_match('~^[A-Za-z0-9/_.-]*$~', $path) || str_contains($path, '..')) { $path = '__404'; }
$parts = $path === '' ? [] : explode('/', $path);
$route = $parts[0] ?? '';
$slug  = $parts[1] ?? null;

$pages = [
    ''            => 'home.php',
    'services'    => 'services.php',
    'work'        => 'work.php',
    'packages'    => 'packages.php',
    'process'     => 'process.php',
    'about'       => 'page.php',
    'privacy'     => 'page.php',
    'terms'       => 'page.php',
    'contact'     => 'contact.php',
    'sitemap.xml' => 'sitemap.php',
];

$file = $pages[$route] ?? null;
// Only /work accepts a second segment; everything else has exactly one
if ($file === null || count($parts) > 2 || (count($parts) === 2 && $route !== 'work')) {
    $file = '404.php';
} elseif ($route === 'work' && $slug !== null) {
    $file = 'project.php';
}
require __DIR__ . '/pages/' . $file;
