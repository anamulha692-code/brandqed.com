<?php
declare(strict_types=1);
$meta = [
    'title' => 'Our Work: Brand Identity Projects | ' . setting('site_name', 'brandQED'),
    'description' => 'Browse brand strategy, naming and identity projects by brandQED for startups and growing businesses around the world.',
    'schema' => [['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => site_url()],
        ['@type' => 'ListItem', 'position' => 2, 'name' => 'Work', 'item' => site_url('/work')]]]],
];
$projects = q_all('SELECT * FROM projects WHERE is_published = 1 ORDER BY sort_order, id DESC');
$cats = q_all("SELECT slug, title FROM services WHERE kind = 'service' AND is_visible = 1 ORDER BY sort_order, id");
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>Our work</h1>
    <p class="lead">Projects where clear thinking met sharp design.</p>
  </div>
</section>
<section class="section section--tight">
  <div class="container">
    <?php if ($projects): ?>
      <div class="filters" role="group" aria-label="Filter projects" data-filters>
        <button type="button" class="chip is-active" data-filter="all" aria-pressed="true">All</button>
        <?php foreach ($cats as $c): ?>
          <button type="button" class="chip" data-filter="<?= e($c['slug']) ?>" aria-pressed="false"><?= e($c['title']) ?></button>
        <?php endforeach; ?>
      </div>
      <div class="grid grid--3" data-work-grid>
        <?php foreach ($projects as $p) { echo project_card($p); } ?>
      </div>
      <p class="muted empty-note" hidden data-empty>No projects in this category yet.</p>
    <?php else: ?>
      <p class="lead">Projects are coming soon. <a class="link" href="/contact">Tell us about yours.</a></p>
    <?php endif; ?>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
