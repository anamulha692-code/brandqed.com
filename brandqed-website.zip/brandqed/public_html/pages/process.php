<?php
declare(strict_types=1);
$meta = [
    'title' => 'Our Process: From Discovery to Launch | ' . setting('site_name', 'brandQED'),
    'description' => 'How a brandQED project works, step by step: discovery, strategy, design, revisions and launch.',
    'schema' => [['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => site_url()],
        ['@type' => 'ListItem', 'position' => 2, 'name' => 'Process', 'item' => site_url('/process')]]]],
];
$steps = q_all('SELECT * FROM process_steps ORDER BY sort_order, id');
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>How we work</h1>
    <p class="lead">A clear path from first call to launch, with you involved at every stage.</p>
  </div>
</section>
<section class="section section--tight">
  <div class="container container--narrow">
    <ol class="timeline">
      <?php foreach ($steps as $i => $s): ?>
        <li class="timeline__item">
          <span class="timeline__n"><?= $i + 1 ?></span>
          <div class="timeline__body">
            <h2><?= e($s['title']) ?></h2>
            <p><?= e($s['description']) ?></p>
            <?php if ($s['duration']): ?><p class="muted">Typical time: <?= e($s['duration']) ?></p><?php endif; ?>
          </div>
        </li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>
<section class="section">
  <div class="container">
    <div class="cta-band">
      <h2>Let us start with a conversation</h2>
      <p>A free call is the first step. No pressure, no commitment.</p>
      <div class="btn-row btn-row--center"><a class="btn btn--primary" href="/contact">Book a free call</a></div>
    </div>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
