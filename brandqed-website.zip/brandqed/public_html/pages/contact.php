<?php
declare(strict_types=1);
ensure_session();

$services = q_all("SELECT slug, title FROM services WHERE is_visible = 1 ORDER BY kind, sort_order, id");
$serviceTitles = array_column($services, 'title');
$packageNames  = array_column(q_all('SELECT name FROM packages WHERE is_visible = 1'), 'name');
$budgets = ['Under $1,000', '$1,000 to $2,500', '$2,500 to $5,000', '$5,000 and above', 'Not sure yet'];

$v = ['name' => '', 'email' => '', 'company' => '', 'service' => '', 'budget' => '', 'message' => '', 'project_link' => ''];
$errors = [];
$sent = isset($_GET['sent']);

if (!$sent && !is_post()) {
    // Preselect from links like /contact?service=brand-strategy or ?package=Launch
    foreach ($services as $s) { if (($_GET['service'] ?? '') === $s['slug']) { $v['service'] = $s['title']; } }
    $pk = (string)($_GET['package'] ?? '');
    if ($pk !== '' && in_array($pk, $packageNames, true)) { $v['message'] = 'I am interested in the ' . $pk . ' package.'; }
    $_SESSION['form_t'] = time();   // used for the "too fast = bot" check
}

if (is_post()) {
    csrf_check();
    foreach ($v as $k => $_) { $v[$k] = isset($_POST[$k]) && is_string($_POST[$k]) ? $_POST[$k] : ''; }
    $v['name'] = clean_line($v['name'], 120);
    $v['email'] = clean_line($v['email'], 190);
    $v['company'] = clean_line($v['company'], 160);
    $v['service'] = clean_line($v['service'], 120);
    $v['budget'] = clean_line($v['budget'], 80);
    $v['message'] = clean_text($v['message'], 4000);
    $v['project_link'] = clean_line($v['project_link'], 255);

    $isBot = !empty($_POST['website'])                                     // honeypot must stay empty
          || (time() - (int)($_SESSION['form_t'] ?? time())) < 3;          // submitted faster than a human can type
    if ($isBot) {
        $sent = true;   // pretend success so bots learn nothing
    } elseif (rate_limited('contact', 3, 3600)) {
        $errors['form'] = 'You have sent several messages recently. Please wait a while or message us on WhatsApp.';
    } else {
        if ($v['name'] === '') { $errors['name'] = 'Enter your name.'; }
        if (!valid_email($v['email'])) { $errors['email'] = 'Enter a valid email address.'; }
        if (mb_strlen($v['message']) < 10) { $errors['message'] = 'Tell us a little about your project (at least 10 characters).'; }
        if ($v['service'] !== '' && $v['service'] !== 'Not sure yet' && !in_array($v['service'], $serviceTitles, true)) { $errors['service'] = 'Choose a service from the list.'; }
        if ($v['budget'] !== '' && !in_array($v['budget'], $budgets, true)) { $errors['budget'] = 'Choose a budget from the list.'; }
        $link = '';
        if ($v['project_link'] !== '') {
            $link = clean_url($v['project_link']);
            if ($link === '') { $errors['project_link'] = 'Enter a valid link, or leave it empty.'; }
        }
        if (!$errors) {
            rate_hit('contact');
            q('INSERT INTO inquiries (name, email, company, service, budget, message, link, ip) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [$v['name'], $v['email'], $v['company'] ?: null, $v['service'] ?: null, $v['budget'] ?: null, $v['message'], $link ?: null, client_ip()]);
            $to = setting('admin_notify_email', setting('email'));
            $html = '<h2>New enquiry from ' . e($v['name']) . '</h2>'
                . '<p><strong>Email:</strong> ' . e($v['email']) . '<br><strong>Company:</strong> ' . e($v['company'])
                . '<br><strong>Service:</strong> ' . e($v['service']) . '<br><strong>Budget:</strong> ' . e($v['budget'])
                . '<br><strong>Link:</strong> ' . e($link) . '</p><p>' . nl2br(e($v['message'])) . '</p>';
            send_mail($to, 'New enquiry from ' . $v['name'], $html, $v['email']);
            unset($_SESSION['form_t']);
            redirect('/contact?sent=1');
        }
    }
}

$meta = [
    'title' => 'Contact and Book a Call | ' . setting('site_name', 'brandQED'),
    'description' => 'Tell brandQED about your project. We reply within one business day. You can also message us on WhatsApp.',
    'schema' => [['@context' => 'https://schema.org', '@type' => 'ContactPage', 'name' => 'Contact brandQED', 'url' => site_url('/contact')]],
];
require BASE_PATH . '/includes/header.php';
$err = static fn(string $k): string => isset($GLOBALS['errors'][$k]) ? '<span class="field__error" role="alert">' . e($GLOBALS['errors'][$k]) . '</span>' : '';
$cal = setting('calendly_url');
?>
<section class="page-hero">
  <div class="container">
    <h1>Let us talk about your brand</h1>
    <p class="lead">Share a few details and we will reply within one business day.</p>
  </div>
</section>
<section class="section section--tight">
  <div class="container contact-grid">
    <div class="card contact-form">
      <?php if ($sent): ?>
        <div class="success" role="status">
          <h2>Message sent</h2>
          <p>Thank you. We will reply to your email within one business day. If it is urgent, message us on WhatsApp.</p>
          <a class="btn btn--primary" href="<?= e(whatsapp_link('Hi brandQED, I just sent an enquiry on your website.')) ?>" target="_blank" rel="noopener noreferrer">Open WhatsApp</a>
        </div>
      <?php else: ?>
        <form method="post" action="/contact" novalidate>
          <?= csrf_field() ?>
          <?php if (!empty($errors['form'])): ?><p class="field__error" role="alert"><?= e($errors['form']) ?></p><?php endif; ?>
          <div class="field"><label for="name">Your name</label>
            <input id="name" name="name" type="text" maxlength="120" autocomplete="name" required value="<?= e($v['name']) ?>"><?= $err('name') ?></div>
          <div class="field"><label for="email">Email</label>
            <input id="email" name="email" type="email" maxlength="190" autocomplete="email" required value="<?= e($v['email']) ?>"><?= $err('email') ?></div>
          <div class="field"><label for="company">Company or project name</label>
            <input id="company" name="company" type="text" maxlength="160" autocomplete="organization" value="<?= e($v['company']) ?>"></div>
          <div class="field-row">
            <div class="field"><label for="service">Service you need</label>
              <select id="service" name="service">
                <option value="">Select a service</option>
                <?php foreach ($serviceTitles as $t): ?><option<?= $v['service'] === $t ? ' selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
                <option<?= $v['service'] === 'Not sure yet' ? ' selected' : '' ?>>Not sure yet</option>
              </select><?= $err('service') ?></div>
            <div class="field"><label for="budget">Budget range</label>
              <select id="budget" name="budget">
                <option value="">Select a range</option>
                <?php foreach ($budgets as $b): ?><option<?= $v['budget'] === $b ? ' selected' : '' ?>><?= e($b) ?></option><?php endforeach; ?>
              </select><?= $err('budget') ?></div>
          </div>
          <div class="field"><label for="message">About your project</label>
            <textarea id="message" name="message" rows="6" maxlength="4000" required><?= e($v['message']) ?></textarea><?= $err('message') ?></div>
          <div class="field"><label for="project_link">Link to your website or reference (optional)</label>
            <input id="project_link" name="project_link" type="text" maxlength="255" inputmode="url" value="<?= e($v['project_link']) ?>"><?= $err('project_link') ?></div>
          <div class="hp" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
          <button class="btn btn--primary" type="submit">Send message</button>
        </form>
      <?php endif; ?>
    </div>
    <aside class="contact-side">
      <div class="card">
        <h2>Prefer to chat?</h2>
        <p>Message us directly. We usually reply within a few hours.</p>
        <a class="btn btn--primary" href="<?= e(whatsapp_link('Hi brandQED, I would like to talk about my brand.')) ?>" target="_blank" rel="noopener noreferrer"><?= icon('whatsapp', 20) ?> WhatsApp</a>
        <p class="contact-line"><?= icon('mail', 18) ?> <a class="link" href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a></p>
        <p class="contact-line muted"><?= e(setting('address')) ?></p>
      </div>
      <?php if ($cal): ?>
      <div class="card">
        <h2>Book a free call</h2>
        <p>Pick a time that suits you.</p>
        <a class="btn btn--ghost" href="<?= e($cal) ?>" target="_blank" rel="noopener noreferrer">Choose a time <?= icon('external', 18) ?></a>
      </div>
      <?php endif; ?>
    </aside>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
