<?php
declare(strict_types=1);
global $slug;
$p = q_one('SELECT * FROM projects WHERE slug = ? AND is_published = 1', [(string)$slug]);
if (!$p) { require __DIR__ . '/404.php'; exit; }

$gallery = q_all('SELECT * FROM project_images WHERE project_id = ? ORDER BY sort_order, id', [$p['id']]);
$prev = q_one('SELECT slug, title FROM projects WHERE is_published = 1 AND (sort_order < ? OR (sort_order = ? AND id < ?)) ORDER BY sort_order DESC, id DESC LIMIT 1', [$p['sort_order'], $p['sort_order'], $p['id']]);
$next = q_one('SELECT slug, title FROM projects WHERE is_published = 1 AND (sort_order > ? OR (sort_order = ? AND id > ?)) ORDER BY sort_order ASC, id ASC LIMIT 1', [$p['sort_order'], $p['sort_order'], $p['id']]);

$catSlugs = array_filter(array_map('trim', explode(',', (string)$p['categories'])));
$catNames = [];
if ($catSlugs) {
    $in = implode(',', array_fill(0, count($catSlugs), '?'));
    $catNames = array_column(q_all("SELECT title FROM services WHERE slug IN ($in) ORDER BY sort_order", array_values($catSlugs)), 'title');
}
$site = clean_url((string)$p['website_url']);

$meta = [
    'title' => ($p['seo_title'] ?: $p['title'] . ' | Brand project') . ' | ' . setting('site_name', 'brandQED'),
    'description' => $p['seo_description'] ?: truncate((string)$p['overview'], 155),
    'og_image' => $p['cover_image'] ? site_url(upload_url($p['cover_image'])) : '',
    'schema' => [
        ['@context' => 'https://schema.org', '@type' => 'CreativeWork', 'name' => $p['title'], 'description' => truncate((string)$p['overview'], 200),
         'creator' => ['@type' => 'Organization', 'name' => setting('site_name', 'brandQED')],
         'dateCreated' => $p['project_year'] ? (string)$p['project_year'] : null,
         'image' => $p['cover_image'] ? site_url(upload_url($p['cover_image'])) : null],
        ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => site_url()],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'Work', 'item' => site_url('/work')],
            ['@type' => 'ListItem', 'position' => 3, 'name' => $p['title'], 'item' => site_url('/work/' . $p['slug'])]]],
    ],
];
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <p class="muted"><a class="link" href="/work">Work</a> / <?= e($p['title']) ?></p>
    <h1><?= e($p['title']) ?></h1>
    <?php if ($p['overview']): ?><p class="lead"><?= e($p['overview']) ?></p><?php endif; ?>
  </div>
</section>

<section class="section section--tight">
  <div class="container">
    <div class="project-cover">
      <?= $p['cover_image']
          ? img_tag($p['cover_image'], $p['title'], ['class' => 'project-cover__img', 'eager' => true, 'sizes' => '(max-width: 1200px) 100vw, 1200px'])
          : '<div class="work-card__ph work-card__ph--large" aria-hidden="true"><span>' . e(mb_strtoupper(mb_substr((string)$p['title'], 0, 1))) . '</span></div>' ?>
    </div>
    <dl class="facts facts--row">
      <?php if ($p['client_name']): ?><div><dt>Client</dt><dd><?= e($p['client_name']) ?></dd></div><?php endif; ?>
      <?php if ($p['industry']): ?><div><dt>Industry</dt><dd><?= e($p['industry']) ?></dd></div><?php endif; ?>
      <?php if ($p['country']): ?><div><dt>Country</dt><dd><?= e($p['country']) ?></dd></div><?php endif; ?>
      <?php if ($p['project_year']): ?><div><dt>Year</dt><dd><?= (int)$p['project_year'] ?></dd></div><?php endif; ?>
      <?php if ($catNames): ?><div><dt>Services</dt><dd><?= e(implode(', ', $catNames)) ?></dd></div><?php endif; ?>
    </dl>
  </div>
</section>

<section class="section section--tight">
  <div class="container container--narrow case">
    <?php foreach (['challenge' => 'The challenge', 'solution' => 'What we did', 'result' => 'The result'] as $key => $label): if (trim((string)$p[$key]) === '') { continue; } ?>
      <div class="case__block"><h2><?= e($label) ?></h2><p><?= nl2br(e($p[$key])) ?></p></div>
    <?php endforeach; ?>
    <?php if ($site): ?>
      <p><a class="btn btn--ghost" href="<?= e($site) ?>" target="_blank" rel="noopener noreferrer">Visit website <?= icon('external', 18) ?></a></p>
    <?php endif; ?>
  </div>
</section>

<?php if ($gallery): ?>
<section class="section section--tight">
  <div class="container gallery">
    <?php foreach ($gallery as $g): ?>
      <figure><?= img_tag($g['image'], (string)($g['caption'] ?: $p['title']), ['sizes' => '(max-width: 768px) 100vw, 50vw']) ?>
        <?php if ($g['caption']): ?><figcaption><?= e($g['caption']) ?></figcaption><?php endif; ?></figure>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="section section--tight">
  <div class="container pager">
    <?php if ($prev): ?><a class="pager__link" href="/work/<?= e($prev['slug']) ?>"><span class="muted">Previous</span><strong><?= e($prev['title']) ?></strong></a><?php else: ?><span></span><?php endif; ?>
    <?php if ($next): ?><a class="pager__link pager__link--next" href="/work/<?= e($next['slug']) ?>"><span class="muted">Next</span><strong><?= e($next['title']) ?></strong></a><?php endif; ?>
  </div>
</section>
<section class="section">
  <div class="container">
    <div class="cta-band">
      <h2>Want a brand like this?</h2>
      <p>Tell us about your project and we will reply within one business day.</p>
      <div class="btn-row btn-row--center"><a class="btn btn--primary" href="/contact">Start a project</a></div>
    </div>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
