<?php
declare(strict_types=1);
$meta = [
    'title' => setting('site_title', 'brandQED'),
    'description' => setting('seo_description'),
    'body_class' => 'page-home',
];
$stats    = q_all('SELECT * FROM stats ORDER BY sort_order, id');
$clients  = q_all('SELECT * FROM clients WHERE is_visible = 1 ORDER BY sort_order, id');
$services = q_all("SELECT * FROM services WHERE kind = 'service' AND is_visible = 1 ORDER BY sort_order, id");
$featured = q_all('SELECT * FROM projects WHERE is_published = 1 AND is_featured = 1 ORDER BY sort_order, id DESC LIMIT 6');
$steps    = q_all('SELECT * FROM process_steps ORDER BY sort_order, id');
$testis   = q_all('SELECT * FROM testimonials WHERE is_visible = 1 ORDER BY sort_order, id');
$packages = q_all('SELECT * FROM packages WHERE is_visible = 1 ORDER BY sort_order, id');
$faqs     = q_all('SELECT * FROM faqs WHERE is_visible = 1 ORDER BY sort_order, id');

$meta['schema'] = [['@context' => 'https://schema.org', '@type' => 'ProfessionalService', 'name' => setting('site_name', 'brandQED'),
    'url' => site_url(), 'description' => setting('seo_description'), 'areaServed' => 'Worldwide',
    'hasOfferCatalog' => ['@type' => 'OfferCatalog', 'name' => 'Brand services', 'itemListElement' => array_map(
        static fn($s) => ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => $s['title'], 'description' => $s['promise']]], $services)]]];
if ($faqs) {
    $meta['schema'][] = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(
        static fn($f) => ['@type' => 'Question', 'name' => $f['question'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['answer']]], $faqs)];
}
require BASE_PATH . '/includes/header.php';
?>
<section class="hero">
  <div class="hero__bg" aria-hidden="true">
    <div class="hero__glow"></div>
    <div class="hero__bars"><?php for ($i = 0; $i < 28; $i++): ?><i style="--i:<?= $i ?>"></i><?php endfor; ?></div>
    <div class="hero__orb"></div>
  </div>
  <div class="hero__ghost" aria-hidden="true">brandQED</div>
  <div class="container hero__content">
    <h1 class="hero__title"><?= e(setting('hero_headline', 'We build brands people remember and trust.')) ?></h1>
    <p class="hero__sub"><?= e(setting('hero_subheadline')) ?></p>
    <div class="btn-row">
      <a class="btn btn--primary" href="<?= e(setting('hero_btn1_link', '/work')) ?>"><?= e(setting('hero_btn1_text', 'View our work')) ?> <?= icon('arrow', 18) ?></a>
      <a class="btn btn--ghost" href="<?= e(setting('hero_btn2_link', '/contact')) ?>"><?= e(setting('hero_btn2_text', 'Book a free call')) ?></a>
    </div>
    <p class="hero__trust"><?= e(setting('trust_line')) ?></p>
  </div>
</section>

<?php if ($stats): ?>
<section class="section section--tight" aria-label="Numbers">
  <div class="container stats">
    <?php foreach ($stats as $s): ?>
      <div class="stat">
        <div class="stat__num"><span data-count="<?= (int)$s['value'] ?>"><?= e($s['value']) ?></span><?= e($s['suffix']) ?></div>
        <div class="stat__label"><?= e($s['label']) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($clients): ?>
<section class="section section--tight" aria-label="Clients">
  <div class="marquee">
    <div class="marquee__track">
      <?php for ($loop = 0; $loop < 2; $loop++): foreach ($clients as $c): ?>
        <span class="marquee__item"<?= $loop ? ' aria-hidden="true"' : '' ?>>
          <?= $c['logo'] ? img_tag($c['logo'], $loop ? '' : $c['name'], ['class' => 'marquee__logo', 'sizes' => '160px']) : e($c['name']) ?>
        </span>
      <?php endforeach; endfor; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <div class="container">
    <div class="section__head">
      <h2>One partner from first idea to launch day</h2>
      <p class="lead">Four connected services. Use one, or take them all.</p>
    </div>
    <div class="grid grid--2">
      <?php foreach ($services as $s): ?>
        <a class="card service-card" href="/services#<?= e($s['slug']) ?>">
          <span class="service-card__icon"><?= icon((string)$s['icon'], 28) ?></span>
          <h3><?= e($s['title']) ?></h3>
          <p><?= e($s['promise']) ?></p>
          <span class="service-card__more">Learn more <?= icon('arrow', 18) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if ($featured): ?>
<section class="section">
  <div class="container">
    <div class="section__head section__head--row">
      <div><h2>Selected work</h2><p class="lead">Brands we helped find their shape.</p></div>
      <a class="btn btn--ghost" href="/work">All projects</a>
    </div>
    <div class="grid grid--3">
      <?php foreach ($featured as $p) { echo project_card($p); } ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($steps): ?>
<section class="section">
  <div class="container">
    <div class="section__head"><h2>How a project runs</h2><p class="lead">Clear steps, regular check-ins, no surprises.</p></div>
    <ol class="steps">
      <?php foreach ($steps as $i => $st): ?>
        <li class="step"><span class="step__n"><?= $i + 1 ?></span><h3><?= e($st['title']) ?></h3><p><?= e(truncate((string)$st['description'], 110)) ?></p></li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>
<?php endif; ?>

<?php if ($testis): ?>
<section class="section">
  <div class="container">
    <div class="section__head"><h2>What clients say</h2></div>
    <div class="testi" data-slider>
      <?php foreach ($testis as $t): ?>
        <figure class="testi__item">
          <div class="stars" aria-label="<?= (int)$t['rating'] ?> out of 5"><?php for ($i = 0; $i < (int)$t['rating']; $i++) { echo icon('star', 18); } ?></div>
          <blockquote><?= e($t['quote']) ?></blockquote>
          <figcaption>
            <?= $t['photo'] ? img_tag($t['photo'], $t['name'], ['class' => 'testi__photo', 'sizes' => '56px']) : '' ?>
            <span><strong><?= e($t['name']) ?></strong><br><?= e(trim($t['role'] . ($t['role'] && $t['company'] ? ', ' : '') . $t['company'])) ?><?= $t['country'] ? ' · ' . e($t['country']) : '' ?></span>
          </figcaption>
        </figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($packages): ?>
<section class="section">
  <div class="container">
    <div class="section__head section__head--row">
      <div><h2>Packages</h2><p class="lead">Start small or go end to end.</p></div>
      <a class="btn btn--ghost" href="/packages">Compare packages</a>
    </div>
    <div class="grid grid--3">
      <?php foreach ($packages as $pk): ?>
        <div class="card pkg<?= $pk['is_popular'] ? ' pkg--popular' : '' ?>">
          <?php if ($pk['is_popular']): ?><span class="badge">Most popular</span><?php endif; ?>
          <h3><?= e($pk['name']) ?></h3>
          <p class="pkg__price"><?= e($pk['price']) ?></p>
          <p class="muted"><?= e($pk['tagline']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($faqs): ?>
<section class="section">
  <div class="container container--narrow">
    <div class="section__head"><h2>Questions we hear often</h2></div>
    <div class="faq">
      <?php foreach ($faqs as $f): ?>
        <details><summary><?= e($f['question']) ?></summary><p><?= e($f['answer']) ?></p></details>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <div class="container">
    <div class="cta-band">
      <h2><?= e(setting('cta_headline', 'Ready to build a brand that lasts?')) ?></h2>
      <p><?= e(setting('cta_text')) ?></p>
      <div class="btn-row btn-row--center">
        <a class="btn btn--primary" href="/contact">Start a project</a>
        <a class="btn btn--ghost" href="<?= e(whatsapp_link('Hi brandQED, I would like to talk about my brand.')) ?>" target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a>
      </div>
    </div>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
