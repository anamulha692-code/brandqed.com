<?php
/** Generic text pages: About, Privacy, Terms. Content is edited in admin > Pages. */
declare(strict_types=1);
global $route;
$row = q_one('SELECT * FROM pages WHERE slug = ?', [$route]);
if (!$row) { require __DIR__ . '/404.php'; exit; }
$meta = [
    'title' => ($row['seo_title'] ?: $row['title']) . ' | ' . setting('site_name', 'brandQED'),
    'description' => $row['seo_description'] ?: truncate((string)$row['content'], 155),
    'schema' => [['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => site_url()],
        ['@type' => 'ListItem', 'position' => 2, 'name' => $row['title'], 'item' => site_url('/' . $route)],
    ]]],
];
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1><?= e($row['title']) ?></h1>
  </div>
</section>
<section class="section section--tight">
  <div class="container container--narrow prose">
    <?= sanitize_html((string)$row['content']) ?>
    <?php if ($route === 'about'): ?>
      <p><a class="btn btn--primary" href="/contact">Work with us</a></p>
    <?php endif; ?>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
