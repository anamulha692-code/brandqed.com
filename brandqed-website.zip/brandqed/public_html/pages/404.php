<?php
declare(strict_types=1);
http_response_code(404);
$meta = ['title' => 'Page not found | ' . setting('site_name', 'brandQED'), 'robots' => 'noindex, follow', 'description' => 'This page could not be found.'];
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero page-hero--center">
  <div class="container">
    <p class="muted">Error 404</p>
    <h1>We could not find that page.</h1>
    <p class="lead">The link may be old or mistyped. Try one of these instead.</p>
    <div class="btn-row">
      <a class="btn btn--primary" href="/">Go home</a>
      <a class="btn btn--ghost" href="/work">See our work</a>
      <a class="btn btn--ghost" href="/contact">Contact us</a>
    </div>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
