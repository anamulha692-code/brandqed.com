<?php
declare(strict_types=1);
$meta = [
    'title' => 'Brand Strategy, Naming and Identity Services | ' . setting('site_name', 'brandQED'),
    'description' => 'Brand strategy, naming and messaging, identity design and digital launch. Everything a new brand needs, from one consultancy.',
];
$services = q_all("SELECT * FROM services WHERE kind = 'service' AND is_visible = 1 ORDER BY sort_order, id");
$addons   = q_all("SELECT * FROM services WHERE kind = 'addon' AND is_visible = 1 ORDER BY sort_order, id");
$points = [];
foreach (q_all('SELECT service_id, point_text FROM service_points ORDER BY sort_order, id') as $p) { $points[$p['service_id']][] = $p['point_text']; }
$meta['schema'] = array_map(static fn($s) => ['@context' => 'https://schema.org', '@type' => 'Service', 'name' => $s['title'],
    'description' => $s['promise'], 'provider' => ['@type' => 'Organization', 'name' => setting('site_name', 'brandQED')]], $services);
$meta['schema'][] = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
    ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => site_url()],
    ['@type' => 'ListItem', 'position' => 2, 'name' => 'Services', 'item' => site_url('/services')]]];
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>Services</h1>
    <p class="lead">Four services that work alone or together, from first research to launch.</p>
  </div>
</section>

<?php foreach ($services as $i => $s): ?>
<section class="section service-block<?= $i % 2 ? ' service-block--flip' : '' ?>" id="<?= e($s['slug']) ?>">
  <div class="container service-block__grid">
    <div class="service-block__intro">
      <span class="service-card__icon"><?= icon((string)$s['icon'], 30) ?></span>
      <h2><?= e($s['title']) ?></h2>
      <p class="lead"><?= e($s['promise']) ?></p>
      <dl class="facts">
        <?php if ($s['best_for']): ?><div><dt>Best for</dt><dd><?= e($s['best_for']) ?></dd></div><?php endif; ?>
        <?php if ($s['timeline']): ?><div><dt>Typical timeline</dt><dd><?= e($s['timeline']) ?></dd></div><?php endif; ?>
      </dl>
      <a class="btn btn--primary" href="/contact?service=<?= e(rawurlencode($s['slug'])) ?>">Get started <?= icon('arrow', 18) ?></a>
    </div>
    <div class="card service-block__list">
      <h3>What you get</h3>
      <ul class="checks">
        <?php foreach (($points[$s['id']] ?? []) as $pt): ?><li><?= icon('check', 18) ?><span><?= e($pt) ?></span></li><?php endforeach; ?>
      </ul>
    </div>
  </div>
</section>
<?php endforeach; ?>

<?php if ($addons): ?>
<section class="section" id="add-ons">
  <div class="container">
    <div class="section__head"><h2>Add-ons</h2><p class="lead">Extras you can attach to any project.</p></div>
    <div class="grid grid--4">
      <?php foreach ($addons as $a): ?>
        <div class="card addon">
          <span class="service-card__icon"><?= icon((string)$a['icon'], 24) ?></span>
          <h3><?= e($a['title']) ?></h3>
          <p><?= e($a['promise']) ?></p>
          <?php if ($a['timeline']): ?><p class="muted"><?= e($a['timeline']) ?></p><?php endif; ?>
          <a class="link" href="/contact?service=<?= e(rawurlencode($a['slug'])) ?>">Ask about this</a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <div class="container">
    <div class="cta-band">
      <h2>Not sure what you need?</h2>
      <p>Book a free call. We will recommend the simplest path for your goals.</p>
      <div class="btn-row btn-row--center"><a class="btn btn--primary" href="/contact">Book a free call</a></div>
    </div>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
