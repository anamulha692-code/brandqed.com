<?php
/** Auto-generated sitemap at /sitemap.xml */
declare(strict_types=1);
header('Content-Type: application/xml; charset=utf-8');
$urls = [];
foreach (['/', '/services', '/work', '/packages', '/process', '/about', '/contact', '/privacy', '/terms'] as $p) {
    $urls[] = [site_url($p === '/' ? '' : $p), null];
}
foreach (q_all('SELECT slug, updated_at FROM projects WHERE is_published = 1 ORDER BY sort_order') as $r) {
    $urls[] = [site_url('/work/' . $r['slug']), substr((string)$r['updated_at'], 0, 10)];
}
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach ($urls as [$loc, $mod]) {
    echo '  <url><loc>' . e($loc) . '</loc>' . ($mod ? '<lastmod>' . e($mod) . '</lastmod>' : '') . "</url>\n";
}
echo '</urlset>';
