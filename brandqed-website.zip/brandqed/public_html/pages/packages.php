<?php
declare(strict_types=1);
$meta = [
    'title' => 'Brand Packages and Pricing | ' . setting('site_name', 'brandQED'),
    'description' => 'Compare brandQED packages: Starter, Launch and Growth. Brand naming, identity, strategy, website and ongoing support.',
    'schema' => [['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => site_url()],
        ['@type' => 'ListItem', 'position' => 2, 'name' => 'Packages', 'item' => site_url('/packages')]]]],
];
$packages = q_all('SELECT * FROM packages WHERE is_visible = 1 ORDER BY sort_order, id');
$feat = [];
foreach (q_all('SELECT package_id, feature FROM package_features ORDER BY sort_order, id') as $f) { $feat[$f['package_id']][] = $f['feature']; }
$faqs = q_all('SELECT * FROM faqs WHERE is_visible = 1 ORDER BY sort_order, id LIMIT 4');
require BASE_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>Packages</h1>
    <p class="lead">Three ways to work together. Every package includes unlimited revisions.</p>
  </div>
</section>
<section class="section section--tight">
  <div class="container grid grid--3 pkg-grid">
    <?php foreach ($packages as $pk): ?>
      <div class="card pkg<?= $pk['is_popular'] ? ' pkg--popular' : '' ?>">
        <?php if ($pk['is_popular']): ?><span class="badge">Most popular</span><?php endif; ?>
        <h2><?= e($pk['name']) ?></h2>
        <p class="muted"><?= e($pk['tagline']) ?></p>
        <p class="pkg__price"><?= e($pk['price']) ?></p>
        <?php if ($pk['price_note']): ?><p class="muted pkg__note"><?= e($pk['price_note']) ?></p><?php endif; ?>
        <ul class="checks">
          <?php foreach (($feat[$pk['id']] ?? []) as $ft): ?><li><?= icon('check', 18) ?><span><?= e($ft) ?></span></li><?php endforeach; ?>
        </ul>
        <a class="btn <?= $pk['is_popular'] ? 'btn--primary' : 'btn--ghost' ?>" href="/contact?package=<?= e(rawurlencode($pk['name'])) ?>"><?= e($pk['cta_label']) ?></a>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php if ($faqs): ?>
<section class="section">
  <div class="container container--narrow">
    <div class="section__head"><h2>Before you choose</h2></div>
    <div class="faq"><?php foreach ($faqs as $f): ?><details><summary><?= e($f['question']) ?></summary><p><?= e($f['answer']) ?></p></details><?php endforeach; ?></div>
  </div>
</section>
<?php endif; ?>
<section class="section">
  <div class="container">
    <div class="cta-band">
      <h2>Need something different?</h2>
      <p>Every project is shaped to your goals. Ask for a custom quote.</p>
      <div class="btn-row btn-row--center"><a class="btn btn--primary" href="/contact">Request a quote</a></div>
    </div>
  </div>
</section>
<?php require BASE_PATH . '/includes/footer.php';
