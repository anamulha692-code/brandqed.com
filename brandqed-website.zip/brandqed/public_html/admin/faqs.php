<?php
require __DIR__ . '/_boot.php';
a_crud([
    'table' => 'faqs', 'title' => 'FAQs', 'singular' => 'question',
    'columns' => ['question' => 'Question', 'sort_order' => 'Order', 'is_visible' => 'Visible'],
    'fields' => [
        ['name' => 'question', 'label' => 'Question', 'type' => 'text', 'required' => true],
        ['name' => 'answer', 'label' => 'Answer', 'type' => 'textarea', 'required' => true, 'rows' => 5],
        ['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number', 'default' => 0],
        ['name' => 'is_visible', 'label' => 'Show on website', 'type' => 'check', 'default' => 1],
    ],
]);
