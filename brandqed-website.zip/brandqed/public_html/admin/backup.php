<?php
require __DIR__ . '/_boot.php';
if (is_post()) {
    csrf_check();
    $pdo = db();
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="brandqed-backup-' . date('Y-m-d-His') . '.sql"');
    header('Cache-Control: no-store');
    echo "-- brandQED backup, " . gmdate('Y-m-d H:i:s') . " UTC\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";
    $skip = ['rate_limits', 'login_attempts'];
    foreach ($pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $table) {
        if (in_array($table, $skip, true)) { continue; }
        $create = $pdo->query('SHOW CREATE TABLE `' . str_replace('`', '', $table) . '`')->fetch(PDO::FETCH_NUM);
        echo 'DROP TABLE IF EXISTS `' . $table . "`;\n" . $create[1] . ";\n\n";
        $st = $pdo->query('SELECT * FROM `' . str_replace('`', '', $table) . '`');
        while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
            $vals = array_map(static fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), array_values($row));
            echo 'INSERT INTO `' . $table . '` (`' . implode('`, `', array_keys($row)) . '`) VALUES (' . implode(', ', $vals) . ");\n";
        }
        echo "\n";
    }
    echo "SET FOREIGN_KEY_CHECKS = 1;\n";
    exit;
}
a_head('Backup', 'backup');
?>
<div class="a-card">
  <h2>Download a database backup</h2>
  <p>This file contains all your content: projects, services, packages, inquiries and settings. Uploaded images are not inside it, so also download the <code>uploads</code> folder from cPanel File Manager (right-click, Compress, then Download).</p>
  <p class="a-hint">The backup includes admin password hashes. Keep it private.</p>
  <form method="post"><?= csrf_field() ?><button class="a-btn" type="submit">Download backup (.sql)</button></form>
</div>
<div class="a-card">
  <h2>Restoring</h2>
  <p>In cPanel open phpMyAdmin, choose your database, click Import and select the backup file.</p>
</div>
<?php a_foot();
