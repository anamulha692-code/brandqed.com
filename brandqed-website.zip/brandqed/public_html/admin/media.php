<?php
require __DIR__ . '/_boot.php';

/** Returns a short description of where a file is used, or null when it is unused. */
function media_in_use(string $f): ?string {
    $checks = ['projects' => ['cover_image', 'project cover'], 'project_images' => ['image', 'project gallery'],
               'clients' => ['logo', 'client logo'], 'testimonials' => ['photo', 'testimonial photo']];
    foreach ($checks as $table => [$col, $label]) {
        if (q_val("SELECT COUNT(*) FROM `$table` WHERE `$col` = ?", [$f])) { return $label; }
    }
    if (q_val('SELECT COUNT(*) FROM settings WHERE svalue = ?', [$f])) { return 'site settings (logo, favicon or sharing image)'; }
    return null;
}

if (is_post()) {
    csrf_check();
    $f = basename((string)($_POST['filename'] ?? ''));
    if (($_POST['action'] ?? '') === 'delete' && $f !== '') {
        $use = media_in_use($f);
        if ($use) { flash('This file is still used in: ' . $use . '. Remove it there first.', 'error'); }
        else { media_delete($f); flash('File deleted.'); }
    }
    redirect('media.php');
}
$rows = q_all('SELECT * FROM media ORDER BY id DESC LIMIT 200');
a_head('Media library', 'media');
?>
<p class="a-hint">Every image you upload appears here. Files that are still in use cannot be deleted.</p>
<div class="a-media">
<?php if (!$rows): ?><p class="a-empty">No uploads yet.</p><?php endif; ?>
<?php foreach ($rows as $m): $use = media_in_use($m['filename']); ?>
  <div class="a-card a-media__item">
    <div class="a-thumb"><?= img_tag($m['filename'], '', ['sizes' => '200px']) ?></div>
    <small><?= e($m['original_name']) ?><br><?= $m['width'] ? (int)$m['width'] . ' x ' . (int)$m['height'] . ' · ' : '' ?><?= round(((int)$m['size_bytes']) / 1024) ?> KB</small>
    <small class="<?= $use ? 'a-ok' : 'a-warn' ?>"><?= $use ? 'Used in ' . e($use) : 'Not used' ?></small>
    <?php if (!$use): ?>
      <form method="post" data-confirm="Delete this file?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="filename" value="<?= e($m['filename']) ?>"><button class="a-btn a-btn--danger a-btn--sm" type="submit">Delete</button></form>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<?php a_foot();
