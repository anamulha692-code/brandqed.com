<?php
require __DIR__ . '/_boot.php';
$icons = ['compass' => 'Compass', 'message' => 'Message', 'palette' => 'Palette', 'rocket' => 'Rocket', 'repeat' => 'Repeat', 'image' => 'Image', 'calendar' => 'Calendar', 'search' => 'Search', 'check' => 'Check'];
$errors = []; $v = []; $editId = null;

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    if ($act === 'delete' && $id) { q('DELETE FROM services WHERE id = ?', [$id]); flash('Deleted.'); redirect('services.php'); }
    if ($act === 'save') {
        $s = static fn(string $k, int $m = 255): string => clean_line((string)($_POST[$k] ?? ''), $m);
        $kind = ($_POST['kind'] ?? '') === 'addon' ? 'addon' : 'service';
        $icon = array_key_exists((string)($_POST['icon'] ?? ''), $icons) ? (string)$_POST['icon'] : 'check';
        $v = ['title' => $s('title', 120), 'kind' => $kind, 'promise' => $s('promise'), 'best_for' => $s('best_for'), 'timeline' => $s('timeline', 80),
              'icon' => $icon, 'description' => clean_text((string)($_POST['description'] ?? ''), 2000),
              'sort_order' => (int)($_POST['sort_order'] ?? 0), 'is_visible' => isset($_POST['is_visible']) ? 1 : 0];
        $points = array_slice(array_filter(array_map(fn($l) => clean_line($l, 255), preg_split('~\R~', (string)($_POST['points'] ?? '')) ?: [])), 0, 20);
        if ($v['title'] === '') { $errors['title'] = 'Enter a title.'; }
        if (!$errors) {
            if ($id && q_val('SELECT id FROM services WHERE id = ?', [$id])) {
                q('UPDATE services SET ' . implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($v))) . ' WHERE id = ?', [...array_values($v), $id]);
            } else {
                $v['slug'] = unique_slug('services', slugify($v['title']));
                q('INSERT INTO services (' . implode(', ', array_map(fn($k) => "`$k`", array_keys($v))) . ') VALUES (' . implode(', ', array_fill(0, count($v), '?')) . ')', array_values($v));
                $id = (int)db()->lastInsertId();
            }
            q('DELETE FROM service_points WHERE service_id = ?', [$id]);
            foreach (array_values($points) as $i => $p) { q('INSERT INTO service_points (service_id, point_text, sort_order) VALUES (?, ?, ?)', [$id, $p, $i + 1]); }
            flash('Saved.'); redirect('services.php');
        }
        $editId = $id; $v['points'] = (string)($_POST['points'] ?? '');
    }
}
if ($editId === null && isset($_GET['new'])) { $editId = 0; $v = ['is_visible' => 1, 'kind' => 'service', 'icon' => 'check', 'sort_order' => 0]; }
if ($editId === null && isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $v = q_one('SELECT * FROM services WHERE id = ?', [$editId]) ?? [];
    if (!$v) { redirect('services.php'); }
    $v['points'] = implode("\n", array_column(q_all('SELECT point_text FROM service_points WHERE service_id = ? ORDER BY sort_order, id', [$editId]), 'point_text'));
}
a_head('Services', 'services');
if ($editId !== null): $t = static fn(string $k) => $v[$k] ?? ''; ?>
<form method="post" class="a-card a-form">
  <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)$editId ?>">
  <h2><?= $editId ? 'Edit' : 'Add' ?> service</h2>
  <?= a_field(['name' => 'title', 'label' => 'Title', 'type' => 'text', 'required' => true], $t('title'), $errors['title'] ?? null) ?>
  <?= a_field(['name' => 'kind', 'label' => 'Type', 'type' => 'select', 'options' => ['service' => 'Main service (large block)', 'addon' => 'Add-on (small card)']], $t('kind')) ?>
  <?= a_field(['name' => 'promise', 'label' => 'One-line promise', 'type' => 'text'], $t('promise')) ?>
  <?= a_field(['name' => 'points', 'label' => 'What you get (one item per line)', 'type' => 'textarea', 'rows' => 7], $t('points')) ?>
  <?= a_field(['name' => 'best_for', 'label' => 'Best for', 'type' => 'text'], $t('best_for')) ?>
  <?= a_field(['name' => 'timeline', 'label' => 'Typical timeline', 'type' => 'text'], $t('timeline')) ?>
  <?= a_field(['name' => 'icon', 'label' => 'Icon', 'type' => 'select', 'options' => $icons], $t('icon')) ?>
  <?= a_field(['name' => 'description', 'label' => 'Short description (optional)', 'type' => 'textarea', 'rows' => 3], $t('description')) ?>
  <?= a_field(['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number'], $t('sort_order')) ?>
  <?= a_field(['name' => 'is_visible', 'label' => 'Show on website', 'type' => 'check'], $t('is_visible')) ?>
  <div class="a-actions"><button class="a-btn" type="submit">Save</button> <a class="a-btn a-btn--ghost" href="services.php">Cancel</a></div>
</form>
<?php else: $rows = q_all('SELECT * FROM services ORDER BY kind, sort_order, id'); ?>
<p><a class="a-btn" href="services.php?new=1">Add service</a></p>
<div class="a-card a-table-wrap"><table class="a-table"><thead><tr><th>Order</th><th>Title</th><th>Type</th><th>Visible</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
  <tr><td><?= (int)$r['sort_order'] ?></td><td><?= e($r['title']) ?></td><td><?= $r['kind'] === 'addon' ? 'Add-on' : 'Service' ?></td><td><?= $r['is_visible'] ? 'Yes' : 'No' ?></td>
  <td class="a-row-actions"><a class="a-btn a-btn--ghost a-btn--sm" href="services.php?edit=<?= (int)$r['id'] ?>">Edit</a> <?= a_confirm_form('delete', (int)$r['id']) ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; a_foot();
