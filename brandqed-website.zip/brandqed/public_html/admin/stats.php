<?php
require __DIR__ . '/_boot.php';
a_crud([
    'table' => 'stats', 'title' => 'Counters', 'singular' => 'counter',
    'help' => 'These numbers appear on the home page. Use only numbers that are true.',
    'columns' => ['label' => 'Label', 'value' => 'Number', 'suffix' => 'Suffix', 'sort_order' => 'Order'],
    'fields' => [
        ['name' => 'label', 'label' => 'Label', 'type' => 'text', 'required' => true, 'maxlength' => 80, 'hint' => 'Example: Brands built'],
        ['name' => 'value', 'label' => 'Number', 'type' => 'text', 'required' => true, 'maxlength' => 20, 'hint' => 'Digits only, for example 50'],
        ['name' => 'suffix', 'label' => 'Suffix', 'type' => 'text', 'maxlength' => 10, 'hint' => 'Example: + '],
        ['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number', 'default' => 0],
    ],
]);
