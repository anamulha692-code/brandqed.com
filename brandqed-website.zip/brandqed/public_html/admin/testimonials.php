<?php
require __DIR__ . '/_boot.php';
a_crud([
    'table' => 'testimonials', 'title' => 'Testimonials', 'singular' => 'testimonial',
    'help' => 'Delete the three SAMPLE testimonials once you have real reviews.',
    'columns' => ['photo' => 'Photo', 'name' => 'Name', 'company' => 'Company', 'quote' => 'Quote', 'is_visible' => 'Visible'],
    'fields' => [
        ['name' => 'name', 'label' => 'Client name', 'type' => 'text', 'required' => true, 'maxlength' => 120],
        ['name' => 'role', 'label' => 'Role', 'type' => 'text', 'maxlength' => 120],
        ['name' => 'company', 'label' => 'Company', 'type' => 'text', 'maxlength' => 120],
        ['name' => 'country', 'label' => 'Country', 'type' => 'text', 'maxlength' => 80],
        ['name' => 'photo', 'label' => 'Photo (optional)', 'type' => 'image', 'max_width' => 400],
        ['name' => 'quote', 'label' => 'Review text', 'type' => 'textarea', 'required' => true, 'rows' => 5],
        ['name' => 'rating', 'label' => 'Rating (1 to 5)', 'type' => 'number', 'default' => 5],
        ['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number', 'default' => 0],
        ['name' => 'is_sample', 'label' => 'This is sample content', 'type' => 'check'],
        ['name' => 'is_visible', 'label' => 'Show on website', 'type' => 'check', 'default' => 1],
    ],
]);
