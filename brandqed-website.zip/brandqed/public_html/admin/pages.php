<?php
require __DIR__ . '/_boot.php';
$errors = [];
if (is_post()) {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $row = q_one('SELECT * FROM pages WHERE id = ?', [$id]);
    if ($row) {
        $title = clean_line((string)($_POST['title'] ?? ''), 160);
        if ($title === '') { $errors['title'] = 'Enter a title.'; }
        else {
            q('UPDATE pages SET title = ?, content = ?, seo_title = ?, seo_description = ? WHERE id = ?', [
                $title, sanitize_html((string)($_POST['content'] ?? '')),
                clean_line((string)($_POST['seo_title'] ?? ''), 190) ?: null, clean_line((string)($_POST['seo_description'] ?? ''), 300) ?: null, $id]);
            flash('Page saved.'); redirect('pages.php');
        }
    }
}
$editing = isset($_GET['edit']) ? q_one('SELECT * FROM pages WHERE id = ?', [(int)$_GET['edit']]) : null;
if (is_post() && $errors && !empty($row)) { $editing = $row; }
a_head('Pages', 'pages', (bool)$editing);
if ($editing): ?>
<form method="post" class="a-card a-form" data-rich-form>
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>">
  <h2>Edit: <?= e($editing['title']) ?></h2>
  <?= a_field(['name' => 'title', 'label' => 'Page title', 'type' => 'text', 'required' => true], $_POST['title'] ?? $editing['title'], $errors['title'] ?? null) ?>
  <?= a_field(['name' => 'content', 'label' => 'Content', 'type' => 'richtext'], $_POST['content'] ?? $editing['content']) ?>
  <?= a_field(['name' => 'seo_title', 'label' => 'SEO title (optional)', 'type' => 'text'], $editing['seo_title']) ?>
  <?= a_field(['name' => 'seo_description', 'label' => 'SEO description (optional)', 'type' => 'textarea', 'rows' => 2], $editing['seo_description']) ?>
  <div class="a-actions"><button class="a-btn" type="submit">Save page</button> <a class="a-btn a-btn--ghost" href="pages.php">Cancel</a></div>
</form>
<?php else: ?>
<div class="a-card a-table-wrap"><table class="a-table"><thead><tr><th>Page</th><th>Address</th><th>Updated</th><th></th></tr></thead><tbody>
<?php foreach (q_all('SELECT * FROM pages ORDER BY id') as $r): ?>
  <tr><td><?= e($r['title']) ?></td><td>/<?= e($r['slug']) ?></td><td><?= e($r['updated_at']) ?> UTC</td>
  <td class="a-row-actions"><a class="a-btn a-btn--ghost a-btn--sm" href="pages.php?edit=<?= (int)$r['id'] ?>">Edit</a></td></tr>
<?php endforeach; ?></tbody></table></div>
<p class="a-hint">The Home, Services, Work, Packages, Process and Contact pages are edited from their own sections in the menu.</p>
<?php endif; a_foot();
