<?php
require __DIR__ . '/_auth.php';
$done = false;
if (is_post()) {
    csrf_check();
    $email = clean_line((string)($_POST['email'] ?? ''), 190);
    if (!rate_limited('reset', 3, 3600)) {
        rate_hit('reset');
        if (valid_email($email) && ($token = reset_create($email))) {
            $link = site_url(admin_url('reset.php')) . '?token=' . $token;
            send_mail($email, 'Reset your brandQED admin password',
                '<p>Click the link below to choose a new password. It works for one hour.</p><p><a href="' . e($link) . '">' . e($link) . '</a></p><p>If you did not ask for this, ignore this email.</p>');
        }
    }
    $done = true;   // same message whether or not the email exists
}
auth_head('Reset password');
if ($done): ?>
  <div class="a-flash a-flash--success">If that email belongs to an admin account, a reset link is on its way. Check your inbox and spam folder.</div>
  <p class="a-center"><a class="a-link" href="login.php">Back to sign in</a></p>
<?php else: ?>
  <form method="post" class="a-form">
    <?= csrf_field() ?>
    <div class="a-field"><label for="email">Your admin email</label><input id="email" name="email" type="email" required autofocus></div>
    <button class="a-btn a-btn--block" type="submit">Send reset link</button>
  </form>
  <p class="a-center"><a class="a-link" href="login.php">Back to sign in</a></p>
<?php endif; auth_foot();
