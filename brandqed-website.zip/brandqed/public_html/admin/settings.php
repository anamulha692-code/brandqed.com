<?php
require __DIR__ . '/_boot.php';

$groups = [
    'Brand' => [
        ['site_name', 'Site name', 'text'], ['site_title', 'Browser title (home page)', 'text'], ['tagline', 'Tagline', 'text'],
        ['footer_text', 'Footer text', 'textarea'],
    ],
    'Home page' => [
        ['hero_headline', 'Main headline', 'text'], ['hero_subheadline', 'Sub-headline', 'textarea'],
        ['hero_btn1_text', 'First button text', 'text'], ['hero_btn1_link', 'First button link', 'text'],
        ['hero_btn2_text', 'Second button text', 'text'], ['hero_btn2_link', 'Second button link', 'text'],
        ['trust_line', 'Trust line under the buttons', 'text'],
        ['cta_headline', 'Bottom banner headline', 'text'], ['cta_text', 'Bottom banner text', 'text'],
    ],
    'Contact' => [
        ['whatsapp', 'WhatsApp number (with country code)', 'text'], ['email', 'Public email', 'email'],
        ['admin_notify_email', 'Send new inquiries to this email', 'email'], ['address', 'Location text', 'text'],
        ['calendly_url', 'Booking link (Calendly or similar)', 'url'],
    ],
    'Social links' => [
        ['social_instagram', 'Instagram', 'url'], ['social_facebook', 'Facebook', 'url'], ['social_linkedin', 'LinkedIn', 'url'],
        ['social_behance', 'Behance', 'url'], ['social_dribbble', 'Dribbble', 'url'],
    ],
    'SEO and tracking' => [
        ['seo_description', 'Default meta description', 'textarea'], ['ga_id', 'Google Analytics ID (looks like G-XXXXXXXXXX)', 'text'],
        ['custom_head', 'Extra code for the head (advanced)', 'textarea'], ['custom_footer', 'Extra code before the end of the page (advanced)', 'textarea'],
    ],
];
$images = [
    'logo' => ['Main logo (header). Dark or colourful logos that work on a dark background.', true],
    'logo_light' => ['Footer logo (optional, if different)', true],
    'og_image' => ['Social sharing image (1200 x 630 recommended)', false],
];
$errors = [];

/** Favicon: PNG becomes a 48px icon plus a 180px Apple icon; ICO and SVG are kept as they are. */
function save_favicon(array $file): array {
    $info = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if ($info !== 'image/png' || !function_exists('imagecreatefrompng')) {
        return upload_image($file, ['allow_svg' => true, 'allow_ico' => true]);
    }
    if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name']) || $file['size'] > 2 * 1024 * 1024) { return ['ok' => false, 'error' => 'Favicon upload failed or is too large.']; }
    $src = @imagecreatefrompng($file['tmp_name']);
    if (!$src) { return ['ok' => false, 'error' => 'This PNG could not be read.']; }
    $w = imagesx($src); $h = imagesy($src); $base = bin2hex(random_bytes(12));
    $make = static function (int $size, string $path) use ($src, $w, $h): void {
        $c = imagecreatetruecolor($size, $size);
        imagealphablending($c, false); imagesavealpha($c, true);
        imagefill($c, 0, 0, imagecolorallocatealpha($c, 0, 0, 0, 127));
        $scale = min($size / $w, $size / $h);
        $nw = (int)round($w * $scale); $nh = (int)round($h * $scale);
        imagecopyresampled($c, $src, intdiv($size - $nw, 2), intdiv($size - $nh, 2), 0, 0, $nw, $nh, $w, $h);
        imagepng($c, $path, 9); imagedestroy($c);
    };
    $make(48, UPLOAD_PATH . "/$base.png");
    $make(180, UPLOAD_PATH . "/$base-180.png");
    imagedestroy($src);
    return media_record("$base.png", 'favicon', 'image/png', 48, 48, (int)filesize(UPLOAD_PATH . "/$base.png"), [180 => "$base-180.png"]);
}

if (is_post()) {
    csrf_check();
    foreach ($groups as $items) {
        foreach ($items as [$key, $label, $type]) {
            $raw = is_string($_POST[$key] ?? null) ? $_POST[$key] : '';
            if ($type === 'url') { $val = clean_url($raw); if ($raw !== '' && $val === '') { $errors[$key] = 'Enter a valid link.'; continue; } }
            elseif ($type === 'email') { $val = clean_line($raw, 190); if ($val !== '' && !valid_email($val)) { $errors[$key] = 'Enter a valid email.'; continue; } }
            elseif ($key === 'ga_id') { $val = clean_line($raw, 30); if ($val !== '' && !preg_match('~^G-[A-Z0-9]{4,20}$~', $val)) { $errors[$key] = 'It should look like G-XXXXXXXXXX.'; continue; } }
            elseif ($key === 'whatsapp') { $val = clean_line($raw, 30); if ($val !== '' && !preg_match('~^\+?[0-9 ()-]{7,20}$~', $val)) { $errors[$key] = 'Use digits and an optional + sign.'; continue; } }
            elseif (in_array($key, ['custom_head', 'custom_footer'], true)) { $val = clean_text($raw, 5000); }
            elseif ($type === 'textarea') { $val = clean_text($raw, 1000); }
            else { $val = clean_line($raw, 255); }
            setting_save($key, $val);
        }
    }
    $all = $images + ['favicon' => ['Favicon', false]];
    foreach ($all as $key => $_) {
        $cur = setting($key);
        if (!empty($_POST[$key . '__remove']) && $cur) { media_delete($cur); setting_save($key, ''); $cur = ''; }
        if (isset($_FILES[$key]) && $_FILES[$key]['error'] !== UPLOAD_ERR_NO_FILE) {
            $r = $key === 'favicon' ? save_favicon($_FILES[$key])
               : upload_image($_FILES[$key], ['allow_svg' => $key !== 'og_image', 'max_width' => $key === 'og_image' ? 1600 : 1200]);
            if ($r['ok']) { if ($cur) { media_delete($cur); } setting_save($key, $r['filename']); }
            else { $errors[$key] = $r['error']; }
        }
    }
    if (!$errors) { flash('Settings saved.'); redirect('settings.php'); }
    flash('Some settings were saved. Please fix the highlighted fields.', 'warn');
}

a_head('Site settings', 'settings');
?>
<form method="post" enctype="multipart/form-data" class="a-form">
  <?= csrf_field() ?>
  <div class="a-card">
    <h2>Logos and icons</h2>
    <?php foreach ($images as $key => [$label, $svg]): ?>
      <?= a_field(['name' => $key, 'label' => $label, 'type' => 'image', 'accept' => $svg ? 'image/png,image/jpeg,image/webp,image/svg+xml' : 'image/png,image/jpeg,image/webp'], setting($key), $errors[$key] ?? null) ?>
    <?php endforeach; ?>
    <?= a_field(['name' => 'favicon', 'label' => 'Favicon (square PNG, 512 x 512 recommended; ICO or SVG also work)', 'type' => 'image', 'accept' => 'image/png,image/x-icon,image/svg+xml,.ico'], setting('favicon'), $errors['favicon'] ?? null) ?>
    <p class="a-hint">If no logo is uploaded, the site shows the default brandQED logo.</p>
  </div>
  <?php foreach ($groups as $title => $items): ?>
    <div class="a-card">
      <h2><?= e($title) ?></h2>
      <?php foreach ($items as [$key, $label, $type]): ?>
        <?= a_field(['name' => $key, 'label' => $label, 'type' => $type, 'rows' => 3], $_POST[$key] ?? setting($key), $errors[$key] ?? null) ?>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
  <div class="a-actions"><button class="a-btn" type="submit">Save settings</button></div>
</form>
<?php a_foot();
