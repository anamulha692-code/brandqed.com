<?php
require __DIR__ . '/_boot.php';
a_crud([
    'table' => 'process_steps', 'title' => 'Process steps', 'singular' => 'step', 'active' => 'process',
    'help' => 'Steps appear on the Process page in this order.',
    'columns' => ['sort_order' => 'Order', 'title' => 'Step', 'duration' => 'Time'],
    'fields' => [
        ['name' => 'title', 'label' => 'Step name', 'type' => 'text', 'required' => true, 'maxlength' => 100],
        ['name' => 'description', 'label' => 'Description', 'type' => 'textarea', 'rows' => 4],
        ['name' => 'duration', 'label' => 'Typical time', 'type' => 'text', 'maxlength' => 60, 'hint' => 'Example: 1 to 2 weeks'],
        ['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number', 'default' => 0],
    ],
]);
