<?php
require __DIR__ . '/_boot.php';

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    if ($act === 'export') {
        $safe = static fn($v) => (preg_match('~^[=+\-@\t\r]~', (string)$v) ? "'" : '') . (string)$v;   // blocks spreadsheet formula tricks
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="brandqed-inquiries-' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['ID', 'Date (UTC)', 'Name', 'Email', 'Company', 'Service', 'Budget', 'Link', 'Message', 'Read', 'Replied']);
        foreach (q_all('SELECT * FROM inquiries ORDER BY id DESC') as $r) {
            fputcsv($out, [$r['id'], $r['created_at'], $safe($r['name']), $safe($r['email']), $safe($r['company']), $safe($r['service']), $safe($r['budget']), $safe($r['link']), $safe($r['message']), $r['is_read'] ? 'yes' : 'no', $r['is_replied'] ? 'yes' : 'no']);
        }
        fclose($out); exit;
    }
    if ($id && $act === 'delete') { q('DELETE FROM inquiries WHERE id = ?', [$id]); flash('Inquiry deleted.'); redirect('inquiries.php'); }
    if ($id && $act === 'replied') { q('UPDATE inquiries SET is_replied = 1, is_read = 1 WHERE id = ?', [$id]); flash('Marked as replied.'); redirect('inquiries.php?view=' . $id); }
    if ($id && $act === 'unread') { q('UPDATE inquiries SET is_read = 0 WHERE id = ?', [$id]); flash('Marked as unread.'); redirect('inquiries.php'); }
    redirect('inquiries.php');
}

$view = isset($_GET['view']) ? q_one('SELECT * FROM inquiries WHERE id = ?', [(int)$_GET['view']]) : null;
if ($view && !$view['is_read']) { q('UPDATE inquiries SET is_read = 1 WHERE id = ?', [$view['id']]); }
a_head('Inquiries', 'inquiries');
if ($view): ?>
<p><a class="a-link" href="inquiries.php">&larr; All inquiries</a></p>
<div class="a-card">
  <h2><?= e($view['name']) ?></h2>
  <dl class="a-dl">
    <dt>Email</dt><dd><a class="a-link" href="mailto:<?= e($view['email']) ?>"><?= e($view['email']) ?></a></dd>
    <dt>Company</dt><dd><?= e($view['company']) ?: '-' ?></dd>
    <dt>Service</dt><dd><?= e($view['service']) ?: '-' ?></dd>
    <dt>Budget</dt><dd><?= e($view['budget']) ?: '-' ?></dd>
    <dt>Link</dt><dd><?= $view['link'] ? '<a class="a-link" href="' . e($view['link']) . '" target="_blank" rel="noopener noreferrer">' . e($view['link']) . '</a>' : '-' ?></dd>
    <dt>Received</dt><dd><?= e($view['created_at']) ?> UTC</dd>
    <dt>Status</dt><dd><?= $view['is_replied'] ? 'Replied' : 'Not replied yet' ?></dd>
  </dl>
  <h3>Message</h3>
  <p class="a-message"><?= nl2br(e($view['message'])) ?></p>
  <div class="a-actions">
    <a class="a-btn" href="mailto:<?= e($view['email']) ?>?subject=<?= e(rawurlencode('Re: your brandQED enquiry')) ?>">Reply by email</a>
    <form method="post" class="a-inline-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['id'] ?>"><button class="a-btn a-btn--ghost" name="action" value="replied">Mark as replied</button></form>
    <form method="post" class="a-inline-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['id'] ?>"><button class="a-btn a-btn--ghost" name="action" value="unread">Mark as unread</button></form>
    <?= a_confirm_form('delete', (int)$view['id']) ?>
  </div>
</div>
<?php else: $rows = q_all('SELECT * FROM inquiries ORDER BY id DESC LIMIT 300'); ?>
<form method="post" class="a-inline-form"><?= csrf_field() ?><button class="a-btn a-btn--ghost" name="action" value="export">Export all as CSV</button></form>
<div class="a-card a-table-wrap"><table class="a-table"><thead><tr><th>Name</th><th>Email</th><th>Service</th><th>Budget</th><th>Received</th><th>Status</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="6" class="a-empty">No inquiries yet.</td></tr><?php endif; ?>
<?php foreach ($rows as $r): ?>
  <tr class="<?= $r['is_read'] ? '' : 'is-unread' ?>">
    <td><a class="a-link" href="inquiries.php?view=<?= (int)$r['id'] ?>"><?= e($r['name']) ?></a></td><td><?= e($r['email']) ?></td><td><?= e($r['service']) ?></td><td><?= e($r['budget']) ?></td>
    <td><?= e($r['created_at']) ?></td><td><?= $r['is_replied'] ? 'Replied' : ($r['is_read'] ? 'Read' : 'New') ?></td>
  </tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; a_foot();
