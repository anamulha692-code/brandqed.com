<?php
/** Admin layout and form helpers. */
declare(strict_types=1);

function a_head(string $title, string $active = '', bool $rich = false): void {
    global $admin;
    $GLOBALS['a_rich'] = $rich;
    $unread = (int)q_val('SELECT COUNT(*) FROM inquiries WHERE is_read = 0');
    $nav = [
        'index'        => ['Dashboard', 'index.php'],
        'inquiries'    => ['Inquiries', 'inquiries.php'],
        'projects'     => ['Portfolio', 'projects.php'],
        'services'     => ['Services', 'services.php'],
        'packages'     => ['Packages', 'packages.php'],
        'process'      => ['Process steps', 'process.php'],
        'testimonials' => ['Testimonials', 'testimonials.php'],
        'clients'      => ['Clients', 'clients.php'],
        'stats'        => ['Counters', 'stats.php'],
        'faqs'         => ['FAQs', 'faqs.php'],
        'pages'        => ['Pages', 'pages.php'],
        'media'        => ['Media', 'media.php'],
        'settings'     => ['Site settings', 'settings.php'],
        'users'        => ['Account and users', 'users.php'],
        'backup'       => ['Backup', 'backup.php'],
    ];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title) ?> | Admin</title>
<link rel="icon" href="/assets/img/favicon.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600&family=Sora:wght@600;700&display=swap">
<link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>">
<?php if ($rich): ?><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.snow.css"><?php endif; ?>
</head>
<body class="a-body">
<div class="a-shell">
  <aside class="a-side" id="a-side">
    <a class="a-brand" href="<?= e(admin_url('index.php')) ?>">brand<b>QED</b> <small>admin</small></a>
    <nav>
      <?php foreach ($nav as $key => [$label, $file]): ?>
        <a href="<?= e(admin_url($file)) ?>"<?= $key === $active ? ' class="is-active"' : '' ?>><?= e($label) ?><?= ($key === 'inquiries' && $unread) ? ' <span class="a-badge">' . $unread . '</span>' : '' ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="a-side__foot">
      <a href="/" target="_blank" rel="noopener">View website</a>
      <form method="post" action="<?= e(admin_url('logout.php')) ?>"><?= csrf_field() ?><button class="a-link" type="submit">Sign out (<?= e($admin['username']) ?>)</button></form>
    </div>
  </aside>
  <div class="a-main">
    <header class="a-top">
      <button class="a-menu" type="button" data-toggle-side aria-label="Menu">Menu</button>
      <h1><?= e($title) ?></h1>
    </header>
    <div class="a-content">
<?php
    if ($f = flash()) { echo '<div class="a-flash a-flash--' . e($f['t']) . '" role="status">' . e($f['m']) . '</div>'; }
}

function a_foot(): void {
    $nonce = csp_nonce();
    ?>
    </div>
  </div>
</div>
<?php if (!empty($GLOBALS['a_rich'])): ?><script src="https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.min.js"></script><?php endif; ?>
<script src="<?= e(asset('js/admin.js')) ?>" defer></script>
</body>
</html>
<?php
}

/** Render one form field from a config array. */
function a_field(array $f, $value, ?string $error = null): string {
    $n = $f['name']; $id = 'f_' . $n; $type = $f['type'] ?? 'text';
    $label = e($f['label'] ?? $n);
    $hint = !empty($f['hint']) ? '<small class="a-hint">' . e($f['hint']) . '</small>' : '';
    $req = !empty($f['required']) ? ' required' : '';
    $err = $error ? '<small class="a-error" role="alert">' . e($error) . '</small>' : '';
    $v = (string)($value ?? '');
    switch ($type) {
        case 'textarea':
            $in = '<textarea id="' . $id . '" name="' . e($n) . '" rows="' . (int)($f['rows'] ?? 4) . '"' . $req . '>' . e($v) . '</textarea>'; break;
        case 'richtext':
            $in = '<div class="a-rich" data-rich-for="' . $id . '"></div><textarea id="' . $id . '" name="' . e($n) . '" hidden>' . e($v) . '</textarea>'; break;
        case 'check':
            return '<div class="a-field a-field--check"><label><input type="checkbox" name="' . e($n) . '" value="1"' . ($value ? ' checked' : '') . '> ' . $label . '</label>' . $hint . '</div>';
        case 'select':
            $in = '<select id="' . $id . '" name="' . e($n) . '">';
            foreach ($f['options'] as $k => $lab) { $in .= '<option value="' . e((string)$k) . '"' . ((string)$k === $v ? ' selected' : '') . '>' . e($lab) . '</option>'; }
            $in .= '</select>'; break;
        case 'image':
            $in = '';
            if ($v !== '') {
                $in .= '<div class="a-thumb">' . img_tag($v, '', ['sizes' => '160px']) . '</div>'
                    . '<label class="a-inline"><input type="checkbox" name="' . e($n) . '__remove" value="1"> Remove current image</label>';
            }
            $in .= '<input id="' . $id . '" type="file" name="' . e($n) . '" accept="' . e($f['accept'] ?? 'image/jpeg,image/png,image/webp') . '">'; break;
        default:
            $t = in_array($type, ['number', 'email', 'url'], true) ? $type : 'text';
            $in = '<input id="' . $id . '" type="' . $t . '" name="' . e($n) . '" value="' . e($v) . '"' . $req
                . (isset($f['maxlength']) ? ' maxlength="' . (int)$f['maxlength'] . '"' : '') . '>';
    }
    return '<div class="a-field"><label for="' . $id . '">' . $label . '</label>' . $in . $hint . $err . '</div>';
}

/** Re-arrange a multi-file $_FILES entry into a list of single files. */
function a_files(string $key): array {
    $out = [];
    if (empty($_FILES[$key]['name']) || !is_array($_FILES[$key]['name'])) { return $out; }
    foreach ($_FILES[$key]['name'] as $i => $name) {
        if ($_FILES[$key]['error'][$i] === UPLOAD_ERR_NO_FILE) { continue; }
        $out[] = ['name' => $name, 'type' => $_FILES[$key]['type'][$i], 'tmp_name' => $_FILES[$key]['tmp_name'][$i],
                  'error' => $_FILES[$key]['error'][$i], 'size' => $_FILES[$key]['size'][$i]];
    }
    return $out;
}

function a_confirm_form(string $action, int $id, string $label = 'Delete'): string {
    return '<form method="post" class="a-inline-form" data-confirm="Delete this item? This cannot be undone.">' . csrf_field()
        . '<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="' . $id . '">'
        . '<button class="a-btn a-btn--danger a-btn--sm" type="submit">' . e($label) . '</button></form>';
}
