<?php
require __DIR__ . '/_boot.php';
$errors = []; $isOwner = $admin['role'] === 'owner';

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'pw') {
        $me = q_one('SELECT * FROM users WHERE id = ?', [$admin['id']]);
        $cur = (string)($_POST['current'] ?? ''); $p1 = (string)($_POST['password'] ?? ''); $p2 = (string)($_POST['password2'] ?? '');
        if (!$me || !password_verify($cur, $me['password_hash'])) { $errors['current'] = 'Your current password is not correct.'; }
        elseif ($p1 !== $p2) { $errors['password2'] = 'The two passwords do not match.'; }
        elseif (($pp = password_problem($p1)) !== '') { $errors['password'] = $pp; }
        else {
            q('UPDATE users SET password_hash = ? WHERE id = ?', [hash_password($p1), $admin['id']]);
            session_regenerate_id(true);
            flash('Password changed.'); redirect('users.php');
        }
    }
    if ($isOwner && $act === 'add') {
        $u = clean_line((string)($_POST['username'] ?? ''), 40); $em = clean_line((string)($_POST['email'] ?? ''), 190); $pw = (string)($_POST['new_password'] ?? '');
        if (!preg_match('~^[A-Za-z0-9_.-]{3,40}$~', $u)) { $errors['username'] = 'Use 3 to 40 letters, numbers, dots, dashes or underscores.'; }
        elseif (!valid_email($em)) { $errors['email'] = 'Enter a valid email.'; }
        elseif (($pp = password_problem($pw)) !== '') { $errors['new_password'] = $pp; }
        elseif (q_val('SELECT id FROM users WHERE username = ? OR email = ?', [$u, $em])) { $errors['username'] = 'That username or email is already used.'; }
        else { q("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'admin')", [$u, $em, hash_password($pw)]); flash('Admin added.'); redirect('users.php'); }
    }
    if ($isOwner && $act === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $target = q_one('SELECT * FROM users WHERE id = ?', [$id]);
        if (!$target || $id === (int)$admin['id']) { flash('You cannot delete this account.', 'error'); }
        elseif ($target['role'] === 'owner') { flash('The owner account cannot be deleted.', 'error'); }
        else { q('DELETE FROM users WHERE id = ?', [$id]); flash('Admin removed.'); }
        redirect('users.php');
    }
}
a_head('Account and users', 'users');
?>
<form method="post" class="a-card a-form">
  <?= csrf_field() ?><input type="hidden" name="action" value="pw">
  <h2>Change my password</h2>
  <div class="a-field"><label for="current">Current password</label><input id="current" type="password" name="current" autocomplete="current-password" required><?= isset($errors['current']) ? '<small class="a-error">' . e($errors['current']) . '</small>' : '' ?></div>
  <div class="a-field"><label for="password">New password</label><input id="password" type="password" name="password" autocomplete="new-password" required><small class="a-hint">At least 10 characters, with letters and numbers.</small><?= isset($errors['password']) ? '<small class="a-error">' . e($errors['password']) . '</small>' : '' ?></div>
  <div class="a-field"><label for="password2">Repeat new password</label><input id="password2" type="password" name="password2" autocomplete="new-password" required><?= isset($errors['password2']) ? '<small class="a-error">' . e($errors['password2']) . '</small>' : '' ?></div>
  <div class="a-actions"><button class="a-btn" type="submit">Change password</button></div>
</form>
<?php if ($isOwner): ?>
<div class="a-card a-table-wrap"><h2>Admins</h2><table class="a-table"><thead><tr><th>Username</th><th>Email</th><th>Role</th><th>Last sign-in</th><th></th></tr></thead><tbody>
<?php foreach (q_all('SELECT * FROM users ORDER BY id') as $u): ?>
  <tr><td><?= e($u['username']) ?></td><td><?= e($u['email']) ?></td><td><?= e($u['role']) ?></td><td><?= e($u['last_login'] ?: 'never') ?></td>
  <td class="a-row-actions"><?= ($u['role'] !== 'owner' && (int)$u['id'] !== (int)$admin['id']) ? a_confirm_form('delete', (int)$u['id'], 'Remove') : '' ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<form method="post" class="a-card a-form">
  <?= csrf_field() ?><input type="hidden" name="action" value="add">
  <h2>Add another admin</h2>
  <div class="a-field"><label for="username">Username</label><input id="username" name="username" type="text" required maxlength="40"><?= isset($errors['username']) ? '<small class="a-error">' . e($errors['username']) . '</small>' : '' ?></div>
  <div class="a-field"><label for="email">Email</label><input id="email" name="email" type="email" required><?= isset($errors['email']) ? '<small class="a-error">' . e($errors['email']) . '</small>' : '' ?></div>
  <div class="a-field"><label for="new_password">Password</label><input id="new_password" name="new_password" type="password" autocomplete="new-password" required><?= isset($errors['new_password']) ? '<small class="a-error">' . e($errors['new_password']) . '</small>' : '' ?></div>
  <div class="a-actions"><button class="a-btn" type="submit">Add admin</button></div>
</form>
<?php endif; a_foot();
