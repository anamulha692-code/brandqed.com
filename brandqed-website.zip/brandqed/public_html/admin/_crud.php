<?php
/**
 * Generic list / add / edit / delete screen for simple tables.
 * Config: table, title, singular, fields[], columns[ col => label ], order
 * Field: name, label, type (text, textarea, number, url, email, check, select, image), required, hint, default, options, maxlength
 * Table and column names come from our own code, never from user input.
 */
declare(strict_types=1);

function a_crud(array $c): void {
    $table = $c['table']; $fields = $c['fields']; $order = $c['order'] ?? 'sort_order, id';
    $self = basename($_SERVER['SCRIPT_NAME']);
    $errors = []; $values = []; $editId = null;

    if (is_post()) {
        csrf_check();
        $act = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
        if ($act === 'delete' && $id) {
            $old = q_one("SELECT * FROM `$table` WHERE id = ?", [$id]);
            if ($old) {
                foreach ($fields as $f) { if ($f['type'] === 'image' && !empty($old[$f['name']])) { media_delete($old[$f['name']]); } }
                q("DELETE FROM `$table` WHERE id = ?", [$id]);
                flash('Deleted.');
            }
            redirect($self);
        }
        if ($act === 'save') {
            $old = $id ? q_one("SELECT * FROM `$table` WHERE id = ?", [$id]) : null;
            $vals = []; 
            foreach ($fields as $f) {
                $n = $f['name']; $raw = $_POST[$n] ?? '';
                $raw = is_string($raw) ? $raw : '';
                switch ($f['type']) {
                    case 'image': break;
                    case 'check': $vals[$n] = isset($_POST[$n]) ? 1 : 0; break;
                    case 'number': $vals[$n] = (int)$raw; break;
                    case 'textarea': $vals[$n] = clean_text($raw, 5000); break;
                    case 'url': $vals[$n] = clean_url($raw); if ($raw !== '' && $vals[$n] === '') { $errors[$n] = 'Enter a valid link.'; } break;
                    case 'email': $vals[$n] = clean_line($raw, 190); if ($vals[$n] !== '' && !valid_email($vals[$n])) { $errors[$n] = 'Enter a valid email.'; } break;
                    case 'select': $vals[$n] = array_key_exists($raw, $f['options']) ? $raw : (string)array_key_first($f['options']); break;
                    default: $vals[$n] = clean_line($raw, (int)($f['maxlength'] ?? 255));
                }
                if (!empty($f['required']) && $f['type'] !== 'image' && ($vals[$n] ?? '') === '') { $errors[$n] = 'This field is required.'; }
            }
            if (!$errors) {   // process images only when everything else is valid
                foreach ($fields as $f) {
                    if ($f['type'] !== 'image') { continue; }
                    $n = $f['name']; $cur = $old[$n] ?? null; $vals[$n] = $cur;
                    if (!empty($_POST[$n . '__remove']) && $cur) { media_delete($cur); $vals[$n] = null; }
                    if (isset($_FILES[$n]) && $_FILES[$n]['error'] !== UPLOAD_ERR_NO_FILE) {
                        $r = upload_image($_FILES[$n], ['allow_svg' => !empty($f['allow_svg']), 'max_width' => (int)($f['max_width'] ?? 1600)]);
                        if ($r['ok']) { if ($cur) { media_delete($cur); } $vals[$n] = $r['filename']; }
                        else { $errors[$n] = $r['error']; }
                    }
                }
            }
            if (!$errors) {
                $cols = array_keys($vals);
                if ($old) {
                    q("UPDATE `$table` SET " . implode(', ', array_map(fn($k) => "`$k` = ?", $cols)) . ' WHERE id = ?', [...array_values($vals), $id]);
                } else {
                    q("INSERT INTO `$table` (" . implode(', ', array_map(fn($k) => "`$k`", $cols)) . ') VALUES (' . implode(', ', array_fill(0, count($cols), '?')) . ')', array_values($vals));
                }
                flash('Saved.');
                redirect($self);
            }
            $values = $_POST; $editId = $id;
            if ($old) { foreach ($fields as $f) { if ($f['type'] === 'image') { $values[$f['name']] = $old[$f['name']]; } } }
        }
    }

    if ($editId === null && isset($_GET['new'])) { $editId = 0; foreach ($fields as $f) { $values[$f['name']] = $f['default'] ?? ''; } }
    if ($editId === null && isset($_GET['edit'])) {
        $editId = (int)$_GET['edit'];
        $values = q_one("SELECT * FROM `$table` WHERE id = ?", [$editId]) ?? [];
        if (!$values) { redirect($self); }
    }

    a_head($c['title'], $c['active'] ?? pathinfo($self, PATHINFO_FILENAME));
    if ($editId !== null) {
        echo '<form method="post" enctype="multipart/form-data" class="a-card a-form">' . csrf_field()
           . '<input type="hidden" name="action" value="save"><input type="hidden" name="id" value="' . (int)$editId . '">'
           . '<h2>' . ($editId ? 'Edit' : 'Add') . ' ' . e($c['singular']) . '</h2>';
        foreach ($fields as $f) { echo a_field($f, $values[$f['name']] ?? '', $errors[$f['name']] ?? null); }
        echo '<div class="a-actions"><button class="a-btn" type="submit">Save</button> <a class="a-btn a-btn--ghost" href="' . e($self) . '">Cancel</a></div></form>';
    } else {
        $rows = q_all("SELECT * FROM `$table` ORDER BY $order");
        echo '<p><a class="a-btn" href="' . e($self) . '?new=1">Add ' . e($c['singular']) . '</a></p>';
        if ($c['help'] ?? '') { echo '<p class="a-hint">' . e($c['help']) . '</p>'; }
        echo '<div class="a-card a-table-wrap"><table class="a-table"><thead><tr>';
        foreach ($c['columns'] as $label) { echo '<th>' . e($label) . '</th>'; }
        echo '<th></th></tr></thead><tbody>';
        if (!$rows) { echo '<tr><td colspan="' . (count($c['columns']) + 1) . '" class="a-empty">Nothing here yet. Add your first one.</td></tr>'; }
        foreach ($rows as $r) {
            echo '<tr>';
            foreach ($c['columns'] as $col => $label) {
                $cell = $r[$col] ?? '';
                $isImg = false;
                foreach ($fields as $f) { if ($f['name'] === $col && $f['type'] === 'image') { $isImg = true; } }
                if ($isImg) { echo '<td class="a-thumb-sm">' . ($cell ? img_tag($cell, '', ['sizes' => '60px']) : '') . '</td>'; }
                else { echo '<td>' . e(truncate((string)$cell, 80)) . '</td>'; }
            }
            echo '<td class="a-row-actions"><a class="a-btn a-btn--ghost a-btn--sm" href="' . e($self) . '?edit=' . (int)$r['id'] . '">Edit</a> ' . a_confirm_form('delete', (int)$r['id']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    a_foot();
}
