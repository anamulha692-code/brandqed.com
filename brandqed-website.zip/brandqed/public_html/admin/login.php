<?php
require __DIR__ . '/_auth.php';
if (admin_user()) { redirect(admin_url('index.php')); }
$error = '';
if (is_post()) {
    csrf_check();
    [$ok, $msg] = admin_login((string)($_POST['identifier'] ?? ''), (string)($_POST['password'] ?? ''));
    if ($ok) { redirect(admin_url('index.php')); }
    $error = $msg;
}
auth_head('Sign in');
?>
  <?php if ($error): ?><div class="a-flash a-flash--error" role="alert"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="a-form" autocomplete="on">
    <?= csrf_field() ?>
    <div class="a-field"><label for="identifier">Username or email</label><input id="identifier" name="identifier" type="text" autocomplete="username" required autofocus></div>
    <div class="a-field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required></div>
    <button class="a-btn a-btn--block" type="submit">Sign in</button>
  </form>
  <p class="a-center"><a class="a-link" href="forgot.php">Forgot your password?</a></p>
<?php auth_foot();
