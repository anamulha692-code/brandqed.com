<?php
require __DIR__ . '/_auth.php';
$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$row = reset_find($token);
$error = ''; $done = false;
if ($row && is_post()) {
    csrf_check();
    $p1 = (string)($_POST['password'] ?? ''); $p2 = (string)($_POST['password2'] ?? '');
    if ($p1 !== $p2) { $error = 'The two passwords do not match.'; }
    elseif (($pp = password_problem($p1)) !== '') { $error = $pp; }
    else { reset_apply($row, $p1); $done = true; }
}
auth_head('Choose a new password');
if ($done): ?>
  <div class="a-flash a-flash--success">Password changed. You can sign in now.</div>
  <p class="a-center"><a class="a-btn" href="login.php">Sign in</a></p>
<?php elseif (!$row): ?>
  <div class="a-flash a-flash--error">This link is invalid or has expired.</div>
  <p class="a-center"><a class="a-link" href="forgot.php">Request a new link</a></p>
<?php else: ?>
  <?php if ($error): ?><div class="a-flash a-flash--error" role="alert"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="a-form">
    <?= csrf_field() ?><input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="a-field"><label for="password">New password</label><input id="password" name="password" type="password" autocomplete="new-password" required><small class="a-hint">At least 10 characters, with letters and numbers.</small></div>
    <div class="a-field"><label for="password2">Repeat new password</label><input id="password2" name="password2" type="password" autocomplete="new-password" required></div>
    <button class="a-btn a-btn--block" type="submit">Save password</button>
  </form>
<?php endif; auth_foot();
