<?php
require __DIR__ . '/_boot.php';
$cats = q_all("SELECT slug, title FROM services WHERE kind = 'service' ORDER BY sort_order, id");
$errors = []; $v = []; $editId = null;

function project_delete(int $id): void {
    $p = q_one('SELECT cover_image FROM projects WHERE id = ?', [$id]);
    if (!$p) { return; }
    if ($p['cover_image']) { media_delete($p['cover_image']); }
    foreach (q_all('SELECT image FROM project_images WHERE project_id = ?', [$id]) as $g) { media_delete($g['image']); }
    q('DELETE FROM projects WHERE id = ?', [$id]);   // gallery rows go with it (foreign key)
}

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    if ($act === 'delete' && $id) { project_delete($id); flash('Project deleted.'); redirect('projects.php'); }
    if ($act === 'save') {
        $old = $id ? q_one('SELECT * FROM projects WHERE id = ?', [$id]) : null;
        $s = static fn(string $k, int $max = 255): string => clean_line((string)($_POST[$k] ?? ''), $max);
        $t = static fn(string $k): string => clean_text((string)($_POST[$k] ?? ''), 5000);
        $v = ['title' => $s('title', 160), 'client_name' => $s('client_name', 120), 'industry' => $s('industry', 80), 'country' => $s('country', 80),
              'project_year' => (int)($_POST['project_year'] ?? 0), 'overview' => $t('overview'), 'challenge' => $t('challenge'),
              'solution' => $t('solution'), 'result' => $t('result'), 'website_url' => clean_url((string)($_POST['website_url'] ?? '')),
              'is_featured' => isset($_POST['is_featured']) ? 1 : 0, 'is_published' => isset($_POST['is_published']) ? 1 : 0,
              'sort_order' => (int)($_POST['sort_order'] ?? 0), 'seo_title' => $s('seo_title', 190), 'seo_description' => $s('seo_description', 300)];
        $picked = array_values(array_intersect(array_column($cats, 'slug'), (array)($_POST['cats'] ?? [])));
        $v['categories'] = implode(',', $picked);
        if ($v['title'] === '') { $errors['title'] = 'Enter a project title.'; }
        if (trim((string)($_POST['website_url'] ?? '')) !== '' && $v['website_url'] === '') { $errors['website_url'] = 'Enter a valid link.'; }
        if ($v['project_year'] && ($v['project_year'] < 1990 || $v['project_year'] > 2100)) { $errors['project_year'] = 'Enter a valid year.'; }

        if (!$errors) {
            $slug = unique_slug('projects', slugify($s('slug', 190) ?: $v['title']), $id ?: null);
            $cover = $old['cover_image'] ?? null;
            if (!empty($_POST['cover_image__remove']) && $cover) { media_delete($cover); $cover = null; }
            if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                $r = upload_image($_FILES['cover_image'], ['max_width' => 1800]);
                if ($r['ok']) { if ($cover) { media_delete($cover); } $cover = $r['filename']; } else { $errors['cover_image'] = $r['error']; }
            }
        }
        if (!$errors) {
            $data = $v + ['slug' => $slug, 'cover_image' => $cover];
            if ($old) {
                q('UPDATE projects SET ' . implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($data))) . ' WHERE id = ?', [...array_values($data), $id]);
            } else {
                q('INSERT INTO projects (' . implode(', ', array_map(fn($k) => "`$k`", array_keys($data))) . ') VALUES (' . implode(', ', array_fill(0, count($data), '?')) . ')', array_values($data));
                $id = (int)db()->lastInsertId();
            }
            // Gallery: delete ticked, captions, new order, new uploads
            foreach ((array)($_POST['gal_del'] ?? []) as $gid) {
                $g = q_one('SELECT image FROM project_images WHERE id = ? AND project_id = ?', [(int)$gid, $id]);
                if ($g) { media_delete($g['image']); q('DELETE FROM project_images WHERE id = ?', [(int)$gid]); }
            }
            foreach ((array)($_POST['gal_caption'] ?? []) as $gid => $cap) {
                q('UPDATE project_images SET caption = ? WHERE id = ? AND project_id = ?', [clean_line((string)$cap, 190), (int)$gid, $id]);
            }
            $pos = 1;
            foreach (array_filter(explode(',', (string)($_POST['gallery_order'] ?? ''))) as $gid) {
                q('UPDATE project_images SET sort_order = ? WHERE id = ? AND project_id = ?', [$pos++, (int)$gid, $id]);
            }
            $next = (int)q_val('SELECT COALESCE(MAX(sort_order), 0) FROM project_images WHERE project_id = ?', [$id]);
            $failed = [];
            foreach (a_files('gallery') as $file) {
                $r = upload_image($file, ['max_width' => 1800]);
                if ($r['ok']) { q('INSERT INTO project_images (project_id, image, sort_order) VALUES (?, ?, ?)', [$id, $r['filename'], ++$next]); }
                else { $failed[] = $file['name'] . ': ' . $r['error']; }
            }
            if ($failed) { flash('Project saved, but some images failed: ' . implode(' | ', $failed), 'warn'); }
            else { flash('Project saved.'); }
            redirect($failed ? 'projects.php?edit=' . $id : 'projects.php');
        }
        $editId = $id; $v['categories'] = implode(',', $picked);
        $v['cover_image'] = $old['cover_image'] ?? '';
        $v['slug'] = $_POST['slug'] ?? '';
    }
}

if ($editId === null && isset($_GET['new'])) { $editId = 0; $v = ['is_published' => 1, 'sort_order' => 0, 'project_year' => (int)date('Y')]; }
if ($editId === null && isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $v = q_one('SELECT * FROM projects WHERE id = ?', [$editId]) ?? [];
    if (!$v) { redirect('projects.php'); }
}

a_head('Portfolio', 'projects');
if ($editId !== null):
    $gallery = $editId ? q_all('SELECT * FROM project_images WHERE project_id = ? ORDER BY sort_order, id', [$editId]) : [];
    $sel = array_filter(explode(',', (string)($v['categories'] ?? '')));
    $t = static fn(string $k) => $v[$k] ?? '';
?>
<form method="post" enctype="multipart/form-data" class="a-form">
  <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)$editId ?>">
  <div class="a-card">
    <h2><?= $editId ? 'Edit' : 'Add' ?> project</h2>
    <?= a_field(['name' => 'title', 'label' => 'Project title', 'type' => 'text', 'required' => true, 'maxlength' => 160], $t('title'), $errors['title'] ?? null) ?>
    <div class="a-row">
      <?= a_field(['name' => 'client_name', 'label' => 'Client name', 'type' => 'text'], $t('client_name')) ?>
      <?= a_field(['name' => 'industry', 'label' => 'Industry', 'type' => 'text'], $t('industry')) ?>
      <?= a_field(['name' => 'country', 'label' => 'Country', 'type' => 'text'], $t('country')) ?>
      <?= a_field(['name' => 'project_year', 'label' => 'Year', 'type' => 'number'], $t('project_year'), $errors['project_year'] ?? null) ?>
    </div>
    <fieldset class="a-field"><legend>Services provided</legend>
      <?php foreach ($cats as $c): ?>
        <label class="a-inline"><input type="checkbox" name="cats[]" value="<?= e($c['slug']) ?>"<?= in_array($c['slug'], $sel, true) ? ' checked' : '' ?>> <?= e($c['title']) ?></label>
      <?php endforeach; ?>
      <small class="a-hint">These power the filter buttons on the Work page.</small>
    </fieldset>
    <?= a_field(['name' => 'cover_image', 'label' => 'Cover image', 'type' => 'image'], $t('cover_image'), $errors['cover_image'] ?? null) ?>
    <?= a_field(['name' => 'overview', 'label' => 'Overview (short summary)', 'type' => 'textarea', 'rows' => 3], $t('overview')) ?>
    <?= a_field(['name' => 'challenge', 'label' => 'The challenge', 'type' => 'textarea', 'rows' => 4], $t('challenge')) ?>
    <?= a_field(['name' => 'solution', 'label' => 'What you did', 'type' => 'textarea', 'rows' => 4], $t('solution')) ?>
    <?= a_field(['name' => 'result', 'label' => 'The result', 'type' => 'textarea', 'rows' => 4], $t('result')) ?>
    <?= a_field(['name' => 'website_url', 'label' => 'Client website (optional)', 'type' => 'url'], $t('website_url'), $errors['website_url'] ?? null) ?>
  </div>
  <div class="a-card">
    <h2>Gallery</h2>
    <p class="a-hint">Drag images to change their order. Add as many as you like.</p>
    <input type="hidden" name="gallery_order" id="gallery_order" value="<?= e(implode(',', array_column($gallery, 'id'))) ?>">
    <div class="a-gallery" data-sortable data-order-input="gallery_order">
      <?php foreach ($gallery as $g): ?>
        <div class="a-gallery__item" draggable="true" data-id="<?= (int)$g['id'] ?>">
          <div class="a-thumb"><?= img_tag($g['image'], '', ['sizes' => '160px']) ?></div>
          <input type="text" name="gal_caption[<?= (int)$g['id'] ?>]" value="<?= e($g['caption']) ?>" placeholder="Caption (optional)" maxlength="190">
          <label class="a-inline"><input type="checkbox" name="gal_del[]" value="<?= (int)$g['id'] ?>"> Delete</label>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="a-field"><label for="gallery">Add images</label><input id="gallery" type="file" name="gallery[]" multiple accept="image/jpeg,image/png,image/webp"></div>
  </div>
  <div class="a-card">
    <h2>Publishing and SEO</h2>
    <?= a_field(['name' => 'is_published', 'label' => 'Published (visible on the website)', 'type' => 'check'], $t('is_published')) ?>
    <?= a_field(['name' => 'is_featured', 'label' => 'Featured on the home page', 'type' => 'check'], $t('is_featured')) ?>
    <?= a_field(['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number'], $t('sort_order')) ?>
    <?= a_field(['name' => 'slug', 'label' => 'Web address ending (leave empty to create from the title)', 'type' => 'text'], $t('slug')) ?>
    <?= a_field(['name' => 'seo_title', 'label' => 'SEO title (optional)', 'type' => 'text'], $t('seo_title')) ?>
    <?= a_field(['name' => 'seo_description', 'label' => 'SEO description (optional)', 'type' => 'textarea', 'rows' => 2], $t('seo_description')) ?>
  </div>
  <div class="a-actions"><button class="a-btn" type="submit">Save project</button> <a class="a-btn a-btn--ghost" href="projects.php">Cancel</a></div>
</form>
<?php else:
    $rows = q_all('SELECT id, title, cover_image, client_name, is_published, is_featured, is_sample, sort_order FROM projects ORDER BY sort_order, id DESC');
?>
<p><a class="a-btn" href="projects.php?new=1">Add project</a></p>
<div class="a-card a-table-wrap"><table class="a-table">
  <thead><tr><th>Cover</th><th>Title</th><th>Client</th><th>Status</th><th>Order</th><th></th></tr></thead><tbody>
  <?php if (!$rows): ?><tr><td colspan="6" class="a-empty">No projects yet.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="a-thumb-sm"><?= $r['cover_image'] ? img_tag($r['cover_image'], '', ['sizes' => '60px']) : '' ?></td>
      <td><?= e($r['title']) ?><?= $r['is_sample'] ? ' <span class="a-tag">sample</span>' : '' ?></td>
      <td><?= e($r['client_name']) ?></td>
      <td><?= $r['is_published'] ? 'Published' : 'Draft' ?><?= $r['is_featured'] ? ' <span class="a-tag">featured</span>' : '' ?></td>
      <td><?= (int)$r['sort_order'] ?></td>
      <td class="a-row-actions"><a class="a-btn a-btn--ghost a-btn--sm" href="projects.php?edit=<?= (int)$r['id'] ?>">Edit</a> <?= a_confirm_form('delete', (int)$r['id']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table></div>
<?php endif; a_foot();
