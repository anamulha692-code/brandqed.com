<?php
/** Loaded first by every admin page (except login, forgot and reset). */
declare(strict_types=1);
define('BQ_SESSION_NAME', 'bq_admin');   // separate session from the public site
require __DIR__ . '/../../includes/init.php';
$admin = admin_require();
require __DIR__ . '/_layout.php';
require __DIR__ . '/_crud.php';
