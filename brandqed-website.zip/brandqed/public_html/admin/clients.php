<?php
require __DIR__ . '/_boot.php';
a_crud([
    'table' => 'clients', 'title' => 'Clients', 'singular' => 'client',
    'help' => 'Client logos scroll across the home page. If there is no logo, the name is shown as text.',
    'columns' => ['logo' => 'Logo', 'name' => 'Name', 'sort_order' => 'Order'],
    'fields' => [
        ['name' => 'name', 'label' => 'Client name', 'type' => 'text', 'required' => true, 'maxlength' => 120],
        ['name' => 'logo', 'label' => 'Logo (PNG with transparent background works best)', 'type' => 'image', 'max_width' => 600],
        ['name' => 'url', 'label' => 'Website (optional)', 'type' => 'url'],
        ['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number', 'default' => 0],
        ['name' => 'is_visible', 'label' => 'Show on website', 'type' => 'check', 'default' => 1],
    ],
]);
