<?php
require __DIR__ . '/_boot.php';
$errors = []; $v = []; $editId = null;
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    if ($act === 'delete' && $id) { q('DELETE FROM packages WHERE id = ?', [$id]); flash('Deleted.'); redirect('packages.php'); }
    if ($act === 'save') {
        $s = static fn(string $k, int $m = 255): string => clean_line((string)($_POST[$k] ?? ''), $m);
        $v = ['name' => $s('name', 80), 'tagline' => $s('tagline'), 'price' => $s('price', 40), 'price_note' => $s('price_note', 120),
              'is_popular' => isset($_POST['is_popular']) ? 1 : 0, 'cta_label' => $s('cta_label', 60) ?: 'Get started',
              'sort_order' => (int)($_POST['sort_order'] ?? 0), 'is_visible' => isset($_POST['is_visible']) ? 1 : 0];
        $features = array_slice(array_filter(array_map(fn($l) => clean_line($l, 255), preg_split('~\R~', (string)($_POST['features'] ?? '')) ?: [])), 0, 30);
        if ($v['name'] === '') { $errors['name'] = 'Enter a package name.'; }
        if (!$errors) {
            if ($id && q_val('SELECT id FROM packages WHERE id = ?', [$id])) {
                q('UPDATE packages SET ' . implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($v))) . ' WHERE id = ?', [...array_values($v), $id]);
            } else {
                q('INSERT INTO packages (' . implode(', ', array_map(fn($k) => "`$k`", array_keys($v))) . ') VALUES (' . implode(', ', array_fill(0, count($v), '?')) . ')', array_values($v));
                $id = (int)db()->lastInsertId();
            }
            q('DELETE FROM package_features WHERE package_id = ?', [$id]);
            foreach (array_values($features) as $i => $f) { q('INSERT INTO package_features (package_id, feature, sort_order) VALUES (?, ?, ?)', [$id, $f, $i + 1]); }
            flash('Saved.'); redirect('packages.php');
        }
        $editId = $id; $v['features'] = (string)($_POST['features'] ?? '');
    }
}
if ($editId === null && isset($_GET['new'])) { $editId = 0; $v = ['is_visible' => 1, 'sort_order' => 0, 'cta_label' => 'Get started']; }
if ($editId === null && isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $v = q_one('SELECT * FROM packages WHERE id = ?', [$editId]) ?? [];
    if (!$v) { redirect('packages.php'); }
    $v['features'] = implode("\n", array_column(q_all('SELECT feature FROM package_features WHERE package_id = ? ORDER BY sort_order, id', [$editId]), 'feature'));
}
a_head('Packages', 'packages');
if ($editId !== null): $t = static fn(string $k) => $v[$k] ?? ''; ?>
<form method="post" class="a-card a-form">
  <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)$editId ?>">
  <h2><?= $editId ? 'Edit' : 'Add' ?> package</h2>
  <?= a_field(['name' => 'name', 'label' => 'Package name', 'type' => 'text', 'required' => true], $t('name'), $errors['name'] ?? null) ?>
  <?= a_field(['name' => 'tagline', 'label' => 'Short description', 'type' => 'text'], $t('tagline')) ?>
  <?= a_field(['name' => 'price', 'label' => 'Price', 'type' => 'text', 'hint' => 'Example: $990 or Custom quote'], $t('price')) ?>
  <?= a_field(['name' => 'price_note', 'label' => 'Price note', 'type' => 'text', 'hint' => 'Example: one-time payment'], $t('price_note')) ?>
  <?= a_field(['name' => 'features', 'label' => 'Features (one per line)', 'type' => 'textarea', 'rows' => 9], $t('features')) ?>
  <?= a_field(['name' => 'cta_label', 'label' => 'Button text', 'type' => 'text'], $t('cta_label')) ?>
  <?= a_field(['name' => 'is_popular', 'label' => 'Show the "Most popular" badge', 'type' => 'check'], $t('is_popular')) ?>
  <?= a_field(['name' => 'sort_order', 'label' => 'Order (small numbers first)', 'type' => 'number'], $t('sort_order')) ?>
  <?= a_field(['name' => 'is_visible', 'label' => 'Show on website', 'type' => 'check'], $t('is_visible')) ?>
  <div class="a-actions"><button class="a-btn" type="submit">Save</button> <a class="a-btn a-btn--ghost" href="packages.php">Cancel</a></div>
</form>
<?php else: $rows = q_all('SELECT * FROM packages ORDER BY sort_order, id'); ?>
<p><a class="a-btn" href="packages.php?new=1">Add package</a></p>
<p class="a-hint">The prices that came with the site are placeholders. Set your real prices here.</p>
<div class="a-card a-table-wrap"><table class="a-table"><thead><tr><th>Order</th><th>Name</th><th>Price</th><th>Popular</th><th>Visible</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
  <tr><td><?= (int)$r['sort_order'] ?></td><td><?= e($r['name']) ?></td><td><?= e($r['price']) ?></td><td><?= $r['is_popular'] ? 'Yes' : '' ?></td><td><?= $r['is_visible'] ? 'Yes' : 'No' ?></td>
  <td class="a-row-actions"><a class="a-btn a-btn--ghost a-btn--sm" href="packages.php?edit=<?= (int)$r['id'] ?>">Edit</a> <?= a_confirm_form('delete', (int)$r['id']) ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; a_foot();
