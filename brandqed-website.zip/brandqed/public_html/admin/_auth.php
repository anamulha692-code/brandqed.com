<?php
/** Shared bootstrap and layout for pages shown BEFORE login (login, forgot, reset). */
declare(strict_types=1);
define('BQ_SESSION_NAME', 'bq_admin');
require __DIR__ . '/../../includes/init.php';
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store');

function auth_head(string $title): void { ?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title) ?> | brandQED Admin</title>
<link rel="icon" href="/assets/img/favicon.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600&family=Sora:wght@600;700&display=swap">
<link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>">
</head><body class="a-body a-auth">
<main class="a-auth__box a-card">
  <p class="a-brand">brand<b>QED</b> <small>admin</small></p>
  <h1><?= e($title) ?></h1>
<?php }
function auth_foot(): void { echo '</main></body></html>'; }
