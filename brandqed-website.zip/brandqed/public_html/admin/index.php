<?php
require __DIR__ . '/_boot.php';
$count = static fn(string $sql): int => (int)q_val($sql);
$cards = [
    ['Portfolio projects', $count('SELECT COUNT(*) FROM projects WHERE is_published = 1'), 'projects.php'],
    ['New inquiries', $count('SELECT COUNT(*) FROM inquiries WHERE is_read = 0'), 'inquiries.php'],
    ['All inquiries', $count('SELECT COUNT(*) FROM inquiries'), 'inquiries.php'],
    ['Testimonials', $count('SELECT COUNT(*) FROM testimonials WHERE is_visible = 1'), 'testimonials.php'],
];
$latest = q_all('SELECT id, name, email, service, is_read, created_at FROM inquiries ORDER BY id DESC LIMIT 6');
$samples = $count('SELECT COUNT(*) FROM projects WHERE is_sample = 1') + $count('SELECT COUNT(*) FROM testimonials WHERE is_sample = 1');
a_head('Dashboard', 'index');
?>
<?php if ($samples): ?>
  <div class="a-flash a-flash--warn">Your site still shows <?= $samples ?> sample item(s). Replace them with real projects and reviews before you promote the site.</div>
<?php endif; ?>
<div class="a-grid">
  <?php foreach ($cards as [$label, $n, $file]): ?>
    <a class="a-card a-stat" href="<?= e($file) ?>"><span class="a-stat__n"><?= $n ?></span><span><?= e($label) ?></span></a>
  <?php endforeach; ?>
</div>
<div class="a-card">
  <h2>Latest inquiries</h2>
  <?php if (!$latest): ?><p class="a-empty">No messages yet.</p><?php else: ?>
  <table class="a-table"><thead><tr><th>Name</th><th>Email</th><th>Service</th><th>Received</th></tr></thead><tbody>
    <?php foreach ($latest as $r): ?>
      <tr class="<?= $r['is_read'] ? '' : 'is-unread' ?>">
        <td><a class="a-link" href="inquiries.php?view=<?= (int)$r['id'] ?>"><?= e($r['name']) ?></a></td>
        <td><?= e($r['email']) ?></td><td><?= e($r['service']) ?></td><td><?= e($r['created_at']) ?> UTC</td>
      </tr>
    <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>
</div>
<div class="a-card">
  <h2>Quick start</h2>
  <ol class="a-list">
    <li><a class="a-link" href="settings.php">Site settings</a>: upload your logo and favicon, check your email and WhatsApp.</li>
    <li><a class="a-link" href="projects.php">Portfolio</a>: add your best projects with images.</li>
    <li><a class="a-link" href="testimonials.php">Testimonials</a> and <a class="a-link" href="stats.php">Counters</a>: replace the samples with real numbers and reviews.</li>
    <li><a class="a-link" href="packages.php">Packages</a>: set your real prices.</li>
  </ol>
</div>
<?php a_foot();
