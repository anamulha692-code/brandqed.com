<?php
define('BQ_SESSION_NAME', 'bq_admin');
require __DIR__ . '/../../includes/init.php';
if (is_post()) { csrf_check(); admin_logout(); }
redirect(admin_url('login.php'));
