<?php
declare(strict_types=1);

/* ---------- Output and URLs ---------- */

/** Escape text for safe HTML output. Use on ALL user-controlled values. */
function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function is_https(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

function site_url(string $path = ''): string {
    return rtrim((string)cfg('site_url', ''), '/') . '/' . ltrim($path, '/');
}

/** Link to a page on this site, e.g. url('/work'). */
function url(string $path = '/'): string {
    return '/' . ltrim($path, '/');
}

function admin_url(string $path = ''): string {
    return '/' . trim((string)cfg('admin_path', 'admin'), '/') . '/' . ltrim($path, '/');
}

/** Link to a static asset with cache-busting version. */
function asset(string $path): string {
    $file = PUBLIC_PATH . '/assets/' . ltrim($path, '/');
    $v = is_file($file) ? (string)filemtime($file) : '1';
    return '/assets/' . ltrim($path, '/') . '?v=' . $v;
}

function redirect(string $to, int $code = 302): never {
    header('Location: ' . $to, true, $code);
    exit;
}

function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'; }

function json_out(array $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function slugify(string $text): string {
    $text = strtolower(trim($text));
    if (function_exists('iconv')) {
        $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if ($t !== false) { $text = $t; }
    }
    $text = preg_replace('~[^a-z0-9]+~', '-', $text) ?? '';
    $text = trim($text, '-');
    return $text !== '' ? $text : 'item';
}

/** Make a slug unique in a table (table and column names are fixed by our code, never user input). */
function unique_slug(string $table, string $base, ?int $ignoreId = null): string {
    $allowed = ['projects', 'services', 'pages'];
    if (!in_array($table, $allowed, true)) { throw new InvalidArgumentException('Bad table'); }
    $slug = $base; $i = 2;
    while (q_val("SELECT id FROM `$table` WHERE slug = ? AND id <> ?", [$slug, $ignoreId ?? 0])) {
        $slug = $base . '-' . $i++;
    }
    return $slug;
}

function truncate(string $text, int $len = 160): string {
    $text = trim(strip_tags($text));
    return mb_strlen($text) > $len ? rtrim(mb_substr($text, 0, $len - 1)) . '…' : $text;
}

/* ---------- Settings (editable in admin) ---------- */

function settings_all(bool $refresh = false): array {
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = [];
        try {
            foreach (q_all('SELECT skey, svalue FROM settings') as $r) {
                $cache[$r['skey']] = (string)$r['svalue'];
            }
        } catch (Throwable $e) { error_log($e->getMessage()); }
    }
    return $cache;
}
function setting(string $key, string $default = ''): string {
    $all = settings_all();
    return (isset($all[$key]) && $all[$key] !== '') ? $all[$key] : $default;
}
function setting_save(string $key, string $value): void {
    q('INSERT INTO settings (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)', [$key, $value]);
    settings_all(true);
}

function whatsapp_digits(): string { return preg_replace('~\D+~', '', setting('whatsapp', '8801783475407')) ?? ''; }
function whatsapp_link(string $text = ''): string {
    return 'https://wa.me/' . whatsapp_digits() . ($text !== '' ? '?text=' . rawurlencode($text) : '');
}

/* ---------- Sessions, flash messages ---------- */

function ensure_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) { return; }
    $name = defined('BQ_SESSION_NAME') ? BQ_SESSION_NAME : 'bq_site';
    session_name($name);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

function flash(?string $message = null, string $type = 'success') {
    ensure_session();
    if ($message !== null) {
        $_SESSION['_flash'] = ['m' => $message, 't' => $type];
        return null;
    }
    $f = $_SESSION['_flash'] ?? null;
    unset($_SESSION['_flash']);
    return $f;
}

/* ---------- Security headers ---------- */

function csp_nonce(): string {
    static $n = null;
    if ($n === null) { $n = rtrim(strtr(base64_encode(random_bytes(16)), '+/', '-_'), '='); }
    return $n;
}

function send_security_headers(): void {
    if (headers_sent()) { return; }
    $n = csp_nonce();
    header_remove('X-Powered-By');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header("Content-Security-Policy: default-src 'self'; "
        . "script-src 'self' 'nonce-$n' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net https://www.googletagmanager.com; "
        . "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; "
        . "font-src 'self' https://fonts.gstatic.com data:; "
        . "img-src 'self' data: blob: https://www.google-analytics.com; "
        . "connect-src 'self' https://www.google-analytics.com https://*.google-analytics.com; "
        . "frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/** Add our CSP nonce to <script> tags the owner pasted into settings (e.g. analytics). */
function with_nonce(string $html): string {
    return preg_replace('~<script\b(?![^>]*\bnonce=)~i', '<script nonce="' . csp_nonce() . '"', $html) ?? $html;
}

/* ---------- Client info and rate limiting ---------- */

function client_ip(): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}

/** True when the visitor has made $max or more hits in the bucket within $seconds. */
function rate_limited(string $bucket, int $max, int $seconds): bool {
    $c = (int)q_val(
        'SELECT COUNT(*) FROM rate_limits WHERE bucket = ? AND ip = ? AND created_at > (UTC_TIMESTAMP() - INTERVAL ? SECOND)',
        [$bucket, client_ip(), $seconds]
    );
    return $c >= $max;
}
function rate_hit(string $bucket): void {
    q('INSERT INTO rate_limits (bucket, ip) VALUES (?, ?)', [$bucket, client_ip()]);
    if (random_int(1, 50) === 1) {
        q('DELETE FROM rate_limits WHERE created_at < (UTC_TIMESTAMP() - INTERVAL 2 DAY)');
        q('DELETE FROM login_attempts WHERE created_at < (UTC_TIMESTAMP() - INTERVAL 7 DAY)');
    }
}

/* ---------- Validation ---------- */

function clean_line(string $v, int $max = 200): string {
    $v = preg_replace('~[\r\n\t\0]+~', ' ', $v) ?? '';
    return mb_substr(trim($v), 0, $max);
}
function clean_text(string $v, int $max = 5000): string {
    $v = str_replace("\0", '', $v);
    return mb_substr(trim($v), 0, $max);
}
function valid_email(string $v): bool { return (bool)filter_var($v, FILTER_VALIDATE_EMAIL) && mb_strlen($v) <= 190; }
/** Only http(s) links are allowed. Returns '' when invalid. */
function clean_url(string $v): string {
    $v = trim($v);
    if ($v === '') { return ''; }
    if (!preg_match('~^https?://~i', $v)) { $v = 'https://' . $v; }
    return filter_var($v, FILTER_VALIDATE_URL) ? mb_substr($v, 0, 255) : '';
}

/* ---------- Rich text sanitizer (allow-list) ---------- */

function sanitize_html(string $html): string {
    if (trim($html) === '') { return ''; }
    $allowed = ['p','br','strong','b','em','i','u','ul','ol','li','h2','h3','h4','blockquote','a','span'];
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="utf-8"?><div id="root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    $root = $doc->getElementById('root');
    if (!$root) { return e(strip_tags($html)); }
    _sanitize_node($root, $allowed);
    $out = '';
    foreach ($root->childNodes as $child) { $out .= $doc->saveHTML($child); }
    return $out;
}
function _sanitize_node(DOMNode $node, array $allowed): void {
    foreach (iterator_to_array($node->childNodes) as $child) {
        if ($child instanceof DOMElement) {
            $tag = strtolower($child->nodeName);
            if (in_array($tag, ['script','style','iframe','object','embed','svg','math','form','link','meta','base'], true)) {
                $node->removeChild($child); continue;
            }
            _sanitize_node($child, $allowed);
            if (!in_array($tag, $allowed, true)) {
                while ($child->firstChild) { $node->insertBefore($child->firstChild, $child); }
                $node->removeChild($child); continue;
            }
            foreach (iterator_to_array($child->attributes) as $attr) {
                $n = $attr->nodeName;
                if ($tag === 'a' && $n === 'href') {
                    $v = preg_replace('~[\x00-\x20]+~', '', $attr->nodeValue) ?? '';
                    if (!preg_match('~^(https?://|mailto:|tel:|/|#)~i', $v)) { $child->removeAttribute('href'); }
                } else {
                    $child->removeAttribute($n);
                }
            }
            if ($tag === 'a') { $child->setAttribute('rel', 'noopener noreferrer'); }
        } elseif (!($child instanceof DOMText)) {
            $node->removeChild($child);
        }
    }
}

/* ---------- Media helpers ---------- */

function media_get(string $filename): ?array {
    static $cache = [];
    if ($filename === '') { return null; }
    if (!array_key_exists($filename, $cache)) {
        $cache[$filename] = q_one('SELECT * FROM media WHERE filename = ?', [$filename]);
    }
    return $cache[$filename];
}

function upload_url(string $filename): string { return '/uploads/' . rawurlencode($filename); }

/**
 * Responsive <img> with srcset, width/height and lazy loading.
 * $opts: class, sizes, eager (bool), fetchpriority
 */
function img_tag(?string $filename, string $alt = '', array $opts = []): string {
    if (!$filename) { return ''; }
    $m = media_get($filename);
    $cls = isset($opts['class']) ? ' class="' . e($opts['class']) . '"' : '';
    $loading = !empty($opts['eager']) ? 'eager' : 'lazy';
    $extra = !empty($opts['eager']) ? ' fetchpriority="high"' : ' decoding="async"';
    $wh = ($m && $m['width'] && $m['height']) ? ' width="' . (int)$m['width'] . '" height="' . (int)$m['height'] . '"' : '';
    $srcset = '';
    if ($m && !empty($m['variants'])) {
        $v = json_decode((string)$m['variants'], true) ?: [];
        $parts = [];
        foreach ($v as $w => $file) { $parts[] = upload_url($file) . ' ' . (int)$w . 'w'; }
        if ($m['width']) { $parts[] = upload_url($filename) . ' ' . (int)$m['width'] . 'w'; }
        if (count($parts) > 1) {
            $sizes = $opts['sizes'] ?? '(max-width: 768px) 100vw, 50vw';
            $srcset = ' srcset="' . e(implode(', ', $parts)) . '" sizes="' . e($sizes) . '"';
        }
    }
    return '<img src="' . e(upload_url($filename)) . '" alt="' . e($alt) . '"' . $cls . $wh . $srcset
        . ' loading="' . $loading . '"' . $extra . '>';
}
