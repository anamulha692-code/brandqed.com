<?php
declare(strict_types=1);

/**
 * Send an email. Uses SMTP when smtp_host is set in config, otherwise PHP mail().
 * All header values are stripped of line breaks to prevent header injection.
 * Returns true on success.
 */
function send_mail(string $to, string $subject, string $htmlBody, ?string $replyTo = null): bool {
    $strip = static fn(string $v): string => trim(preg_replace('~[\r\n]+~', ' ', $v) ?? '');
    $to = $strip($to);
    if (!valid_email($to)) { return false; }
    $subject = $strip($subject);
    $fromEmail = $strip((string)cfg('mail_from', 'no-reply@localhost'));
    $fromName = $strip((string)cfg('mail_name', 'brandQED'));
    $replyTo = ($replyTo !== null && valid_email($strip($replyTo))) ? $strip($replyTo) : null;

    $encSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $encFrom = '=?UTF-8?B?' . base64_encode($fromName) . '?= <' . $fromEmail . '>';
    $headers = [
        'From: ' . $encFrom,
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
    ];
    if ($replyTo) { $headers[] = 'Reply-To: ' . $replyTo; }
    $body = chunk_split(base64_encode($htmlBody));

    if ((string)cfg('smtp_host', '') === '') {
        return @mail($to, $encSubject, $body, implode("\r\n", $headers), '-f' . $fromEmail);
    }
    return smtp_send($to, $encSubject, $headers, $body, $fromEmail);
}

function smtp_send(string $to, string $encSubject, array $headers, string $body, string $from): bool {
    $host = (string)cfg('smtp_host');
    $port = (int)cfg('smtp_port', 465);
    $secure = (string)cfg('smtp_secure', 'ssl');
    $remote = ($secure === 'ssl' ? 'ssl://' : '') . $host . ':' . $port;
    $fp = @stream_socket_client($remote, $errno, $errstr, 15);
    if (!$fp) { error_log("SMTP connect failed: $errstr"); return false; }
    stream_set_timeout($fp, 15);

    $read = static function () use ($fp): string {
        $out = '';
        while (($line = fgets($fp, 515)) !== false) {
            $out .= $line;
            if (strlen($line) < 4 || $line[3] === ' ') { break; }
        }
        return $out;
    };
    $cmd = static function (string $c, string $expect) use ($fp, $read): bool {
        fwrite($fp, $c . "\r\n");
        return str_starts_with($read(), $expect);
    };

    try {
        if (!str_starts_with($read(), '220')) { throw new RuntimeException('No greeting'); }
        $ehlo = 'brandqed';
        if (!$cmd("EHLO $ehlo", '250')) { throw new RuntimeException('EHLO'); }
        if ($secure === 'tls') {
            if (!$cmd('STARTTLS', '220')) { throw new RuntimeException('STARTTLS'); }
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { throw new RuntimeException('TLS'); }
            if (!$cmd("EHLO $ehlo", '250')) { throw new RuntimeException('EHLO2'); }
        }
        if ((string)cfg('smtp_user', '') !== '') {
            if (!$cmd('AUTH LOGIN', '334')) { throw new RuntimeException('AUTH'); }
            if (!$cmd(base64_encode((string)cfg('smtp_user')), '334')) { throw new RuntimeException('USER'); }
            if (!$cmd(base64_encode((string)cfg('smtp_pass')), '235')) { throw new RuntimeException('PASS'); }
        }
        if (!$cmd("MAIL FROM:<$from>", '250')) { throw new RuntimeException('MAIL FROM'); }
        if (!$cmd("RCPT TO:<$to>", '250')) { throw new RuntimeException('RCPT'); }
        if (!$cmd('DATA', '354')) { throw new RuntimeException('DATA'); }
        $msg = implode("\r\n", $headers) . "\r\nTo: <$to>\r\nSubject: $encSubject\r\nDate: " . date('r') . "\r\n\r\n" . $body;
        $msg = preg_replace('~^\.~m', '..', $msg) ?? $msg;
        fwrite($fp, $msg . "\r\n.\r\n");
        if (!str_starts_with($read(), '250')) { throw new RuntimeException('Message rejected'); }
        $cmd('QUIT', '221');
        fclose($fp);
        return true;
    } catch (Throwable $e) {
        error_log('SMTP error: ' . $e->getMessage());
        if (is_resource($fp)) { fclose($fp); }
        return false;
    }
}
