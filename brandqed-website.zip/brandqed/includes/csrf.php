<?php
declare(strict_types=1);

function csrf_token(): string {
    ensure_session();
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(?string $token = null): bool {
    ensure_session();
    $token = $token ?? ($_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return !empty($_SESSION['_csrf']) && is_string($token) && hash_equals($_SESSION['_csrf'], $token);
}

/** Stops the request if the token is missing or wrong. */
function csrf_check(): void {
    if (!csrf_verify()) {
        http_response_code(419);
        exit('Your session expired. Please go back, refresh the page and try again.');
    }
}
