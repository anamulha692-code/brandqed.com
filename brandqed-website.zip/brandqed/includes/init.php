<?php
/**
 * Bootstrap: loads config, database, helpers and security headers.
 * Include this first on every page: require __DIR__ . '/../includes/init.php';
 */
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));

$__cfg = BASE_PATH . '/config/config.php';
if (!is_file($__cfg)) {
    http_response_code(500);
    exit('Setup needed: copy config/config.sample.php to config/config.php and fill in your details.');
}
$GLOBALS['BQ_CONFIG'] = require $__cfg;
// Folder the website is served from. Normally BASE_PATH/public_html. Set 'public_path' in config for add-on domains.
define('PUBLIC_PATH', rtrim((string)($GLOBALS['BQ_CONFIG']['public_path'] ?? '') ?: BASE_PATH . '/public_html', '/'));
define('UPLOAD_PATH', PUBLIC_PATH . '/uploads');

function cfg(string $key, $default = null) {
    return $GLOBALS['BQ_CONFIG'][$key] ?? $default;
}

// Error handling: never show errors to visitors in production
$isDev = cfg('env') === 'development';
error_reporting(E_ALL);
ini_set('display_errors', $isDev ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/php-error.log');

date_default_timezone_set('UTC');
mb_internal_encoding('UTF-8');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/upload.php';
require_once __DIR__ . '/mailer.php';

send_security_headers();
