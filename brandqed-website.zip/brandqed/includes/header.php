<?php
/**
 * Public site header + shared view helpers.
 * Each page sets $meta before including this file:
 *   $meta = ['title'=>'', 'description'=>'', 'canonical'=>'', 'og_image'=>'', 'robots'=>'', 'schema'=>[...]]
 */
declare(strict_types=1);

if (!function_exists('icon')) {
    /** Inline SVG icons (no external files, no extra requests). */
    function icon(string $name, int $size = 24): string {
        $paths = [
            'compass'  => '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
            'message'  => '<path d="M4 5h16v11H9l-5 4z"/>',
            'palette'  => '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2 0-2.5 1.5-2.5H17a4 4 0 0 0 4-4C21 6.5 17 3 12 3z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
            'rocket'   => '<path d="M5 15c-1 1-1.5 4-1.5 4s3-.5 4-1.5M14 4c3-1 6-1 6-1s0 3-1 6l-6 6-5-5z"/><circle cx="15" cy="9" r="1.2"/>',
            'repeat'   => '<path d="M4 11V9a3 3 0 0 1 3-3h12m0 0-3-3m3 3-3 3M20 13v2a3 3 0 0 1-3 3H5m0 0 3 3m-3-3 3-3"/>',
            'image'    => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',
            'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
            'search'   => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
            'check'    => '<path d="m5 12 5 5 9-10"/>',
            'arrow'    => '<path d="M5 12h14m-6-6 6 6-6 6"/>',
            'whatsapp' => '<path d="M3 21l1.6-4.8A8.5 8.5 0 1 1 8 19.5z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z"/>',
            'mail'     => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',
            'star'     => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
            'external' => '<path d="M14 4h6v6M20 4l-9 9M18 14v5H5V6h5"/>',
            'menu'     => '<path d="M4 7h16M4 12h16M4 17h16"/>',
            'close'    => '<path d="M6 6l12 12M18 6 6 18"/>',
            'instagram'=> '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r=".8"/>',
            'facebook' => '<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z"/>',
            'linkedin' => '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M8 10v6M8 7.5v.01M12 16v-6m0 3a3 3 0 0 1 6 0v3"/>',
            'behance'  => '<path d="M3 6h6a3 3 0 0 1 0 6H3zm0 6h7a3 3 0 0 1 0 6H3zM14 9h6M14.5 14.5a3 3 0 1 1 5.5 1.5h-5.5"/>',
            'dribbble' => '<circle cx="12" cy="12" r="9"/><path d="M5 8c5 1 10 0 14-3M9 4c3 4 5 9 5 16M4 14c5-2 10-1 16 2"/>',
        ];
        $p = $paths[$name] ?? $paths['check'];
        return '<svg class="icon" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            . 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p . '</svg>';
    }

    /** Project card used on home and work pages. */
    function project_card(array $p): string {
        $href = url('/work/' . $p['slug']);
        $cats = array_filter(array_map('trim', explode(',', (string)$p['categories'])));
        $cover = $p['cover_image']
            ? img_tag($p['cover_image'], $p['title'], ['class' => 'work-card__img', 'sizes' => '(max-width: 768px) 100vw, 33vw'])
            : '<div class="work-card__ph" aria-hidden="true"><span>' . e(mb_strtoupper(mb_substr((string)$p['title'], 0, 1))) . '</span></div>';
        return '<a class="work-card" href="' . e($href) . '" data-cats="' . e(implode(' ', $cats)) . '">'
            . '<div class="work-card__media">' . $cover . '</div>'
            . '<div class="work-card__body"><h3>' . e($p['title']) . '</h3>'
            . '<p>' . e(trim(($p['industry'] ?? '') . ($p['industry'] && $p['country'] ? ', ' : '') . ($p['country'] ?? ''))) . '</p></div>'
            . '<span class="work-card__go">' . icon('arrow', 20) . '</span></a>';
    }
}

$meta = $meta ?? [];
$siteName   = setting('site_name', 'brandQED');
$pageTitle  = $meta['title'] ?? setting('site_title', 'brandQED');
$pageDesc   = $meta['description'] ?? setting('seo_description');
$reqPath    = '/' . trim((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? ''), '/');
$canonical  = $meta['canonical'] ?? site_url($reqPath === '/' ? '' : $reqPath);
$ogImage    = $meta['og_image'] ?? (setting('og_image') ? site_url(upload_url(setting('og_image'))) : '');
$robots     = $meta['robots'] ?? 'index, follow';
$favFile    = setting('favicon');
$favHref    = $favFile ? upload_url($favFile) : '/assets/img/favicon.png';
$favApple   = $favHref;
if ($favFile && ($fm = media_get($favFile)) && !empty($fm['variants'])) {
    $fv = json_decode((string)$fm['variants'], true) ?: [];
    if (!empty($fv[180])) { $favApple = upload_url($fv[180]); }
}
$logoFile   = setting('logo');
$navItems   = ['/services' => 'Services', '/work' => 'Work', '/packages' => 'Packages', '/process' => 'Process', '/about' => 'About', '/contact' => 'Contact'];
$isActive   = static fn(string $p): bool => $p === $reqPath || ($p !== '/' && str_starts_with($reqPath, $p . '/'));

$schemas = [
    ['@context' => 'https://schema.org', '@type' => 'Organization', 'name' => $siteName, 'url' => site_url(),
     'logo' => $logoFile ? site_url(upload_url($logoFile)) : site_url('assets/img/logo.png'),
     'email' => setting('email'), 'telephone' => setting('whatsapp'),
     'sameAs' => array_values(array_filter([setting('social_instagram'), setting('social_facebook'), setting('social_linkedin'), setting('social_behance'), setting('social_dribbble')]))],
    ['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => $siteName, 'url' => site_url()],
];
foreach (($meta['schema'] ?? []) as $s) { $schemas[] = $s; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="<?= e($pageDesc) ?>">
<meta name="robots" content="<?= e($robots) ?>">
<meta name="theme-color" content="#070707">
<link rel="canonical" href="<?= e($canonical) ?>">
<link rel="icon" href="<?= e($favHref) ?>">
<link rel="apple-touch-icon" href="<?= e($favApple) ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= e($siteName) ?>">
<meta property="og:title" content="<?= e($pageTitle) ?>">
<meta property="og:description" content="<?= e($pageDesc) ?>">
<meta property="og:url" content="<?= e($canonical) ?>">
<?php if ($ogImage): ?><meta property="og:image" content="<?= e($ogImage) ?>">
<?php endif; ?>
<meta name="twitter:card" content="<?= $ogImage ? 'summary_large_image' : 'summary' ?>">
<meta name="twitter:title" content="<?= e($pageTitle) ?>">
<meta name="twitter:description" content="<?= e($pageDesc) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600&family=Sora:wght@500;600;700&display=swap">
<script nonce="<?= e(csp_nonce()) ?>">document.documentElement.classList.add('js')</script>
<link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
<?php foreach ($schemas as $s): ?>
<script type="application/ld+json" nonce="<?= e(csp_nonce()) ?>"><?= json_encode($s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<?php endforeach; ?>
<?php if (preg_match('~^G-[A-Z0-9]{4,20}$~', setting('ga_id'))): $ga = setting('ga_id'); ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($ga) ?>"></script>
<script nonce="<?= e(csp_nonce()) ?>">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','<?= e($ga) ?>');</script>
<?php endif; ?>
<?= with_nonce(setting('custom_head')) ?>
</head>
<body class="<?= e($meta['body_class'] ?? '') ?>">
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header" id="top">
  <div class="container nav">
    <a class="logo" href="/" aria-label="<?= e($siteName) ?> home">
      <?php
      if ($logoFile) {
          echo img_tag($logoFile, $siteName, ['class' => 'logo__img', 'eager' => true]);
      } elseif (is_file(PUBLIC_PATH . '/assets/img/logo.png')) {
          $d = @getimagesize(PUBLIC_PATH . '/assets/img/logo.png');
          echo '<img class="logo__img" src="/assets/img/logo.png" alt="' . e($siteName) . '"' . ($d ? ' width="' . (int)$d[0] . '" height="' . (int)$d[1] . '"' : '') . '>';
      } else {
          echo '<span class="logo__text">brand<b>QED</b></span>';
      }
      ?>
    </a>
    <nav class="nav__links" id="nav-links" aria-label="Main">
      <?php foreach ($navItems as $href => $label): ?>
        <a href="<?= e($href) ?>"<?= $isActive($href) ? ' aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
      <a class="btn btn--primary nav__cta" href="/contact">Book a call</a>
    </nav>
    <button class="nav__toggle" type="button" aria-controls="nav-links" aria-expanded="false" aria-label="Open menu"><?= icon('menu') ?></button>
  </div>
</header>
<main id="main">
