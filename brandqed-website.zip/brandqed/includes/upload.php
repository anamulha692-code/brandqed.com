<?php
declare(strict_types=1);

/**
 * Safe image upload.
 * - Checks the real file type (not the file name or browser-reported type)
 * - Re-encodes photos to WebP with GD, which removes any hidden code
 * - Creates smaller sizes for responsive images
 * - Uses random file names
 *
 * $opts: allow_svg (bool), allow_ico (bool), max_width (int, default 1800), sizes (array, default [480, 960])
 * Returns ['ok'=>true,'filename'=>..., 'width'=>..., 'height'=>...] or ['ok'=>false,'error'=>...]
 */
function upload_image(array $file, array $opts = []): array {
    $fail = static fn(string $m): array => ['ok' => false, 'error' => $m];

    if (!isset($file['error'], $file['tmp_name']) || is_array($file['error'])) { return $fail('Upload failed. Please try again.'); }
    if ($file['error'] === UPLOAD_ERR_NO_FILE) { return $fail('Choose a file first.'); }
    if ($file['error'] !== UPLOAD_ERR_OK) { return $fail('Upload failed (code ' . (int)$file['error'] . ').'); }
    if (!is_uploaded_file($file['tmp_name'])) { return $fail('Invalid upload.'); }

    $maxBytes = (int)cfg('max_upload_mb', 5) * 1024 * 1024;
    if ($file['size'] > $maxBytes) { return $fail('File is too large. Maximum is ' . (int)cfg('max_upload_mb', 5) . ' MB.'); }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($file['tmp_name']);
    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    $allowSvg = !empty($opts['allow_svg']);
    $allowIco = !empty($opts['allow_ico']);
    $original = clean_line(pathinfo((string)($file['name'] ?? ''), PATHINFO_FILENAME), 120);

    if (!is_dir(UPLOAD_PATH)) { @mkdir(UPLOAD_PATH, 0755, true); }
    $base = bin2hex(random_bytes(12));

    // --- SVG (logos only): strip anything that can run code
    if ($mime === 'image/svg+xml' || ($mime === 'text/plain' && $ext === 'svg') || ($mime === 'text/xml' && $ext === 'svg')) {
        if (!$allowSvg || $ext !== 'svg') { return $fail('SVG files are only allowed for logos.'); }
        $svg = sanitize_svg((string)file_get_contents($file['tmp_name']));
        if ($svg === null) { return $fail('This SVG could not be read safely. Export it again or use PNG.'); }
        $name = $base . '.svg';
        file_put_contents(UPLOAD_PATH . '/' . $name, $svg);
        return media_record($name, $original, 'image/svg+xml', 0, 0, filesize(UPLOAD_PATH . '/' . $name) ?: 0, []);
    }

    // --- ICO (favicon only)
    if (in_array($mime, ['image/x-icon', 'image/vnd.microsoft.icon'], true)) {
        if (!$allowIco || $ext !== 'ico') { return $fail('ICO files are only allowed for the favicon.'); }
        $name = $base . '.ico';
        if (!move_uploaded_file($file['tmp_name'], UPLOAD_PATH . '/' . $name)) { return $fail('Could not save the file.'); }
        return media_record($name, $original, 'image/vnd.microsoft.icon', 0, 0, filesize(UPLOAD_PATH . '/' . $name) ?: 0, []);
    }

    // --- Raster images
    $allowedMime = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowedMime[$mime]) || !in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
        return $fail('Use a JPG, PNG or WebP image.');
    }
    $info = @getimagesize($file['tmp_name']);
    if (!$info || $info[0] < 1 || $info[1] < 1 || $info[0] > 12000 || $info[1] > 12000) { return $fail('This image could not be read.'); }
    if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
        return $fail('The server needs the PHP GD extension with WebP support. Enable it in cPanel > Select PHP Version.');
    }
    $src = @imagecreatefromstring((string)file_get_contents($file['tmp_name']));
    if (!$src) { return $fail('This image could not be processed.'); }
    imagepalettetotruecolor($src);
    imagealphablending($src, true);
    imagesavealpha($src, true);

    $maxW = (int)($opts['max_width'] ?? 1800);
    $w = imagesx($src); $h = imagesy($src);
    $main = $w > $maxW ? imagescale($src, $maxW, (int)round($h * $maxW / $w)) : $src;
    $mw = imagesx($main); $mh = imagesy($main);

    $name = $base . '.webp';
    if (!imagewebp($main, UPLOAD_PATH . '/' . $name, 82)) { return $fail('Could not save the image.'); }

    $variants = [];
    foreach (($opts['sizes'] ?? [480, 960]) as $vw) {
        if ($vw >= $mw) { continue; }
        $small = imagescale($main, (int)$vw, (int)round($mh * $vw / $mw));
        $vname = $base . '-' . $vw . '.webp';
        if ($small && imagewebp($small, UPLOAD_PATH . '/' . $vname, 80)) { $variants[$vw] = $vname; }
        if ($small) { imagedestroy($small); }
    }
    if ($main !== $src) { imagedestroy($main); }
    imagedestroy($src);

    return media_record($name, $original, 'image/webp', $mw, $mh, filesize(UPLOAD_PATH . '/' . $name) ?: 0, $variants);
}

function media_record(string $name, string $original, string $mime, int $w, int $h, int $size, array $variants): array {
    q('INSERT INTO media (filename, original_name, mime, width, height, size_bytes, variants) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [$name, $original, $mime, $w ?: null, $h ?: null, $size, $variants ? json_encode($variants) : null]);
    return ['ok' => true, 'filename' => $name, 'width' => $w, 'height' => $h];
}

/** Removes scripts, event handlers and external references from an SVG. Returns null if unreadable. */
function sanitize_svg(string $svg): ?string {
    if ($svg === '' || strlen($svg) > 2 * 1024 * 1024) { return null; }
    $svg = preg_replace('~<!DOCTYPE[^>]*(\[.*?\])?[^>]*>~is', '', $svg) ?? '';
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $ok = $doc->loadXML($svg, LIBXML_NONET);
    libxml_clear_errors();
    if (!$ok || !$doc->documentElement || strtolower($doc->documentElement->nodeName) !== 'svg') { return null; }
    $bad = ['script', 'foreignobject', 'iframe', 'object', 'embed', 'audio', 'video', 'animate', 'set', 'use', 'image', 'a'];
    $xp = new DOMXPath($doc);
    foreach (iterator_to_array($xp->query('//*')) as $el) {
        if (!$el->parentNode) { continue; }
        if (in_array(strtolower($el->localName), $bad, true)) { $el->parentNode->removeChild($el); continue; }
        foreach (iterator_to_array($el->attributes) as $a) {
            $n = strtolower($a->nodeName); $v = strtolower(preg_replace('~\s+~', '', $a->nodeValue) ?? '');
            if (str_starts_with($n, 'on') || str_contains($v, 'javascript:') || str_contains($v, 'data:text') ||
                (in_array($n, ['href', 'xlink:href'], true) && !str_starts_with($v, '#'))) {
                $el->removeAttribute($a->nodeName);
            }
        }
    }
    return $doc->saveXML($doc->documentElement);
}

/** Delete a media file (and its smaller sizes) from disk and database. */
function media_delete(string $filename): void {
    $m = q_one('SELECT * FROM media WHERE filename = ?', [$filename]);
    if (!$m) { return; }
    $files = [$m['filename']];
    foreach ((json_decode((string)$m['variants'], true) ?: []) as $v) { $files[] = $v; }
    foreach ($files as $f) {
        $path = UPLOAD_PATH . '/' . basename($f);
        if (is_file($path)) { @unlink($path); }
    }
    q('DELETE FROM media WHERE filename = ?', [$filename]);
}
