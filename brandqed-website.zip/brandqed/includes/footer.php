<?php
declare(strict_types=1);
$siteName = setting('site_name', 'brandQED');
$socials = ['instagram' => 'Instagram', 'facebook' => 'Facebook', 'linkedin' => 'LinkedIn', 'behance' => 'Behance', 'dribbble' => 'Dribbble'];
?>
</main>
<footer class="site-footer">
  <div class="container footer__grid">
    <div class="footer__brand">
      <a class="logo" href="/" aria-label="<?= e($siteName) ?> home">
        <?php
        $lf = setting('logo_light', setting('logo'));
        if ($lf) { echo img_tag($lf, $siteName, ['class' => 'logo__img']); }
        elseif (is_file(PUBLIC_PATH . '/assets/img/logo.png')) { echo '<img class="logo__img" src="/assets/img/logo.png" alt="' . e($siteName) . '" width="521" height="105" loading="lazy">'; }
        else { echo '<span class="logo__text">brand<b>QED</b></span>'; }
        ?>
      </a>
      <p><?= e(setting('footer_text')) ?></p>
      <div class="socials">
        <?php foreach ($socials as $key => $label): $link = setting('social_' . $key); if ($link): ?>
          <a href="<?= e($link) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= e($label) ?>"><?= icon($key, 20) ?></a>
        <?php endif; endforeach; ?>
      </div>
    </div>
    <nav class="footer__col" aria-label="Footer">
      <h2>Explore</h2>
      <a href="/services">Services</a><a href="/work">Work</a><a href="/packages">Packages</a>
      <a href="/process">Process</a><a href="/about">About</a>
    </nav>
    <div class="footer__col">
      <h2>Contact</h2>
      <a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a>
      <a href="<?= e(whatsapp_link()) ?>" target="_blank" rel="noopener noreferrer">WhatsApp <?= e(setting('whatsapp')) ?></a>
      <span><?= e(setting('address')) ?></span>
    </div>
  </div>
  <div class="container footer__bar">
    <span>&copy; <?= date('Y') ?> <?= e($siteName) ?>. All rights reserved.</span>
    <span><a href="/privacy">Privacy</a> <a href="/terms">Terms</a></span>
  </div>
</footer>
<a class="wa-float" href="<?= e(whatsapp_link('Hi brandQED, I would like to talk about my brand.')) ?>" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"><?= icon('whatsapp', 28) ?></a>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js" defer></script>
<script src="<?= e(asset('js/main.js')) ?>" defer></script>
<?= with_nonce(setting('custom_footer')) ?>
</body>
</html>
