<?php
declare(strict_types=1);

/* ---------- Passwords ---------- */

function hash_password(string $plain): string {
    $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
    return password_hash($plain, $algo);
}

/** Returns an error message, or '' when the password is strong enough. */
function password_problem(string $p): string {
    if (mb_strlen($p) < 10) { return 'Use at least 10 characters.'; }
    if (!preg_match('~[A-Za-z]~', $p) || !preg_match('~\d~', $p)) { return 'Use both letters and numbers.'; }
    return '';
}

/* ---------- Login protection ---------- */

function login_locked(string $identifier): bool {
    $max = (int)cfg('login_max_attempts', 5);
    $mins = (int)cfg('login_lock_minutes', 15);
    $byIp = (int)q_val(
        'SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND success = 0 AND created_at > (UTC_TIMESTAMP() - INTERVAL ? MINUTE)',
        [client_ip(), $mins]
    );
    $byId = (int)q_val(
        'SELECT COUNT(*) FROM login_attempts WHERE identifier = ? AND success = 0 AND created_at > (UTC_TIMESTAMP() - INTERVAL ? MINUTE)',
        [mb_strtolower($identifier), $mins]
    );
    return $byIp >= $max || $byId >= $max;
}

function log_attempt(string $identifier, bool $ok): void {
    q('INSERT INTO login_attempts (ip, identifier, success) VALUES (?, ?, ?)',
        [client_ip(), mb_substr(mb_strtolower($identifier), 0, 190), $ok ? 1 : 0]);
}

/** Try to sign in. Returns [bool success, string message]. */
function admin_login(string $identifier, string $password): array {
    $identifier = trim($identifier);
    if ($identifier === '' || $password === '') { return [false, 'Enter your username and password.']; }
    if (login_locked($identifier)) {
        return [false, 'Too many failed attempts. Please wait ' . (int)cfg('login_lock_minutes', 15) . ' minutes and try again.'];
    }
    $user = q_one('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1', [$identifier, $identifier]);
    // Always run a hash check so timing does not reveal whether the account exists
    $hash = $user['password_hash'] ?? '$2y$10$abcdefghijklmnopqrstuuABCDEFGHIJKLMNOPQRSTUVWXYZ01234';
    $ok = password_verify($password, $hash) && $user !== null;
    log_attempt($identifier, $ok);
    if (!$ok) { return [false, 'Incorrect username or password.']; }

    if (password_needs_rehash($user['password_hash'], defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT)) {
        q('UPDATE users SET password_hash = ? WHERE id = ?', [hash_password($password), $user['id']]);
    }
    ensure_session();
    session_regenerate_id(true);
    $_SESSION['admin_id']   = (int)$user['id'];
    $_SESSION['admin_ua']   = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
    $_SESSION['admin_seen'] = time();
    $_SESSION['_csrf']      = bin2hex(random_bytes(32));
    q('UPDATE users SET last_login = UTC_TIMESTAMP() WHERE id = ?', [$user['id']]);
    return [true, 'Signed in.'];
}

function admin_logout(): void {
    ensure_session();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], true);
    }
    session_destroy();
}

/** Current admin user row, or null. Also enforces idle timeout and browser match. */
function admin_user(): ?array {
    static $user = false;
    if ($user !== false) { return $user; }
    ensure_session();
    $user = null;
    if (empty($_SESSION['admin_id'])) { return null; }
    $idle = (int)cfg('session_idle_minutes', 30) * 60;
    $uaOk = hash_equals($_SESSION['admin_ua'] ?? '', hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? ''));
    if (!$uaOk || (time() - (int)($_SESSION['admin_seen'] ?? 0)) > $idle) {
        admin_logout();
        return null;
    }
    $_SESSION['admin_seen'] = time();
    $row = q_one('SELECT id, username, email, role FROM users WHERE id = ?', [(int)$_SESSION['admin_id']]);
    $user = $row ?: null;
    return $user;
}

/** Use at the top of every admin page. Sends visitors to the login page if not signed in. */
function admin_require(): array {
    header('X-Robots-Tag: noindex, nofollow', true);
    header('Cache-Control: no-store');
    $u = admin_user();
    if (!$u) { redirect(admin_url('login.php')); }
    return $u;
}

/* ---------- Password reset by email ---------- */

/** Creates a reset token for an email. Returns the plain token (to email) or null if no such user. */
function reset_create(string $email): ?string {
    $user = q_one('SELECT id FROM users WHERE email = ?', [$email]);
    if (!$user) { return null; }
    $token = bin2hex(random_bytes(32));
    q('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, UTC_TIMESTAMP() + INTERVAL 1 HOUR)',
        [$user['id'], hash('sha256', $token)]);
    return $token;
}

/** Returns the reset row if the token is valid and unused, otherwise null. */
function reset_find(string $token): ?array {
    if (!preg_match('~^[a-f0-9]{64}$~', $token)) { return null; }
    return q_one('SELECT * FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > UTC_TIMESTAMP()',
        [hash('sha256', $token)]);
}

function reset_apply(array $row, string $newPassword): void {
    q('UPDATE users SET password_hash = ? WHERE id = ?', [hash_password($newPassword), $row['user_id']]);
    q('UPDATE password_resets SET used = 1 WHERE user_id = ?', [$row['user_id']]);
}
