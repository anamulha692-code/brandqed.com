# brandQED Website: Setup Guide (for cPanel shared hosting)

You do not need to know how to code. Follow the steps in order. Take your time.

## What you have

```
brandqed/
├── public_html/   <- the website (goes into your domain's public_html folder)
├── includes/      <- core code (goes NEXT TO public_html, not inside it)
├── config/        <- your private settings (next to public_html)
├── storage/       <- error logs (next to public_html)
├── database.sql   <- website content, imported once in phpMyAdmin
└── README.md      <- this guide
```

After upload your hosting account should look like this:

```
/home/yourusername/
├── public_html/      (website files: index.php, .htaccess, assets/, admin/, pages/, uploads/ ...)
├── includes/
├── config/
└── storage/
```

`includes`, `config` and `storage` stay OUTSIDE public_html so nobody can open them from the internet.

---

## Step 1: Requirements
- PHP 8.1 or newer.
- PHP extensions turned on: `pdo_mysql`, `gd` (with WebP support), `fileinfo`, `mbstring`.
- MySQL or MariaDB.
- SSL certificate (free AutoSSL in cPanel).

## Step 2: Choose the PHP version (do this early)
1. cPanel > **Select PHP Version** (or "MultiPHP Manager").
2. Choose **8.1, 8.2 or 8.3**.
3. In the extensions list, tick `pdo_mysql`, `gd`, `fileinfo`, `mbstring`. Save.

## Step 3: Create the database
1. cPanel > **MySQL Databases**.
2. Create a database, for example `brandqed`. cPanel adds your username in front: `yourusername_brandqed`.
3. Create a database user with a strong password. Write the details down.
4. Under "Add user to database", choose your user and your database, click Add, then tick **ALL PRIVILEGES** and save.

## Step 4: Import the content
1. cPanel > **phpMyAdmin**.
2. Click your database name on the left.
3. Open the **Import** tab, choose `database.sql`, click **Import** at the bottom.
4. You should see a green success message and a list of tables.

## Step 5: Upload the files
1. Compress the three folders and files you will upload (or use the ZIP you received).
2. cPanel > **File Manager**. Go to your home folder (the one that contains `public_html`).
3. Upload the ZIP and **Extract** it.
4. Move things to the right places:
   - everything inside `brandqed/public_html/`  ->  into `public_html/`
   - `brandqed/includes/`, `brandqed/config/`, `brandqed/storage/`  ->  next to `public_html/` (in your home folder)
5. In File Manager, click Settings (top right) and tick **Show Hidden Files (dotfiles)** so you can see `.htaccess` files. Make sure `public_html/.htaccess` exists.
6. Permissions: folders 755, files 644. For `public_html/uploads` and `storage/logs` use 755 (if uploads fail later, try 775).

**Add-on domain?** If brandQED is an add-on domain (its files live in a folder like `/home/yourusername/brandqed.com`), upload the website files there and set `'public_path'` in your config file to that full folder path.

## Step 6: Configure
1. In `config/`, make a copy of `config.sample.php` and name it `config.php`.
2. Open `config.php` (Edit) and fill in:
   - `db_name`, `db_user`, `db_pass` from Step 3 (`db_host` is usually `localhost`)
   - `site_url` -> `https://brandqed.com`
   - `install_key` -> type a long random text, for example 30 random letters and numbers. You will use it once in Step 7.
3. Save. Never share `config.php`.

## Step 7: Create your admin account
1. Open `https://brandqed.com/install.php`.
2. Enter the setup key (the `install_key` you typed), choose a username, your email, and a strong password (10+ characters, letters and numbers).
3. After success, the file tries to delete itself. If it is still in `public_html`, **delete `install.php` manually** in File Manager.

## Step 8: Sign in and make it yours
1. Open `https://brandqed.com/admin/` and sign in.
2. **Site settings:** upload your logo and favicon (512 x 512 PNG is best), check your email and WhatsApp number, add social links.
3. **Portfolio:** add your real projects with images. Delete the 3 sample projects.
4. **Testimonials** and **Counters:** replace samples with real reviews and true numbers.
5. **Packages:** set your real prices (the ones shown are placeholders).
6. **Services, FAQs, Pages (About, Privacy, Terms):** edit the text to match your business. Have the Privacy Policy and Terms reviewed for your business.

## Step 9: Turn on HTTPS
- cPanel > **SSL/TLS Status** > run **AutoSSL** for your domain.
- The `.htaccess` file already sends all visitors to `https://` and to the non-www address.

## Step 10: Email
New inquiries are saved in the admin (**Inquiries**) even if email fails. To also get them by email:
- Easiest: in cPanel > **Email Accounts**, create `no-reply@brandqed.com`. Leave `smtp_host` empty in `config.php`: the site uses the server's mail function.
- More reliable: fill the `smtp_*` settings in `config.php` (host like `mail.brandqed.com`, port 465, secure `ssl`, the email and its password).
- Set the address that receives inquiries in **Site settings > Contact**.
- Test by sending yourself a message from the Contact page.

## Step 11: SEO basics
1. Create a free account at **Google Search Console**, add your site, and submit `https://brandqed.com/sitemap.xml`.
2. Create a **Google Analytics** property and paste the ID (looks like `G-XXXXXXXXXX`) in **Site settings > SEO and tracking**.
3. Fill in the SEO title and description on important projects and pages.
4. Add a Google Business Profile and link your social profiles.

## Step 12: Backups
- In the admin go to **Backup** and download the database file once a month, and after big changes.
- Also download your `uploads` folder from File Manager (right-click, Compress, Download).
- Your host may keep automatic backups too. Check cPanel > Backup.

---

## Troubleshooting

**White page or "500 Internal Server Error"**
- Check the PHP version (Step 2) and that the extensions are on.
- Make sure `includes`, `config` and `storage` are next to `public_html`, not inside it.
- Open `storage/logs/php-error.log` in File Manager. The last lines say what is wrong. Send them to Claude.
- Temporarily set `'env' => 'development'` in `config.php` to see errors on screen. Set it back to `production` afterwards.

**"Setup needed: copy config.sample.php"**
- You did not create `config/config.php` (Step 6).

**"Database connection problem"**
- Wrong database name, user or password in `config.php`, or the user was not added to the database with all privileges (Step 3).

**Pages other than the home page show "Not found"**
- `public_html/.htaccess` is missing or hidden files were not uploaded. Turn on "Show Hidden Files" and check it exists.

**Images do not upload**
- GD with WebP support is off (Step 2), the file is bigger than 5 MB, or folder permissions block it (try 775 on `uploads`).

**No styling, plain text only**
- Check that `public_html/assets/css/style.css` exists.

**Cannot sign in / "Too many failed attempts"**
- Wait 15 minutes, or use "Forgot your password?" on the sign-in page.

**Forgot password email does not arrive**
- Fix email in Step 10. As a last resort, change the password in phpMyAdmin: table `users`, but you need a new hash, so ask Claude to help.

## Security notes
- Use a strong, unique admin password.
- To hide the admin address, rename the `admin` folder (for example to `studio-x7`) and set `'admin_path'` in `config.php` to the same name.
- Keep PHP updated in cPanel and download backups regularly.
- Never upload `config.php` to GitHub or send it to anyone.
