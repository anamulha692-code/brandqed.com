<?php
/**
 * brandQED configuration.
 * 1) Copy this file to config.php  2) Fill in your details  3) Never share config.php.
 */
return [
    // Database (create it in cPanel > MySQL Databases)
    'db_host' => 'localhost',
    'db_name' => 'cpaneluser_brandqed',
    'db_user' => 'cpaneluser_brandqed',
    'db_pass' => 'CHANGE_ME',

    // Your website address with https, no trailing slash
    'site_url' => 'https://brandqed.com',

    // Admin folder name. You can rename the folder and change this to match (e.g. 'studio-x7').
    'admin_path' => 'admin',

    // Leave empty normally. Only for add-on domains: full server path of the folder your domain serves,
    // for example '/home/youruser/brandqed.com'
    'public_path' => '',

    // 'production' hides errors, 'development' shows them
    'env' => 'production',

    // Email. Leave smtp_host empty to use PHP mail() instead.
    'mail_from'   => 'no-reply@brandqed.com',
    'mail_name'   => 'brandQED',
    'smtp_host'   => '',          // e.g. mail.brandqed.com
    'smtp_port'   => 465,         // 465 (SSL) or 587 (TLS)
    'smtp_secure' => 'ssl',       // 'ssl' or 'tls'
    'smtp_user'   => '',
    'smtp_pass'   => '',

    // Uploads
    'max_upload_mb' => 5,

    // Security
    // A long random text only you know. You type it once on the setup page (install.php).
    'install_key' => 'CHANGE_ME_TO_A_LONG_RANDOM_TEXT',
    'session_idle_minutes' => 30,
    'login_max_attempts'   => 5,    // failed tries before lockout
    'login_lock_minutes'   => 15,
];
