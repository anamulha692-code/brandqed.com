-- brandQED database schema + starter content
-- Import this file in phpMyAdmin (select your database first, then Import).
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL UNIQUE,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('owner','admin') NOT NULL DEFAULT 'admin',
  last_login DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_token (token_hash),
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  skey VARCHAR(80) PRIMARY KEY,
  svalue MEDIUMTEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stats (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(80) NOT NULL,
  value VARCHAR(20) NOT NULL,
  suffix VARCHAR(10) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS media (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(190) NOT NULL UNIQUE,
  original_name VARCHAR(190) NULL,
  mime VARCHAR(60) NOT NULL,
  width INT UNSIGNED NULL,
  height INT UNSIGNED NULL,
  size_bytes INT UNSIGNED NOT NULL DEFAULT 0,
  variants TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS projects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  slug VARCHAR(190) NOT NULL UNIQUE,
  client_name VARCHAR(120) NULL,
  industry VARCHAR(80) NULL,
  country VARCHAR(80) NULL,
  categories VARCHAR(255) NULL COMMENT 'comma separated service slugs',
  project_year SMALLINT NULL,
  cover_image VARCHAR(190) NULL,
  overview TEXT NULL,
  challenge TEXT NULL,
  solution TEXT NULL,
  result TEXT NULL,
  website_url VARCHAR(255) NULL,
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  is_sample TINYINT(1) NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0,
  seo_title VARCHAR(190) NULL,
  seo_description VARCHAR(300) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pub (is_published, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_images (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_id INT UNSIGNED NOT NULL,
  image VARCHAR(190) NOT NULL,
  caption VARCHAR(190) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  INDEX idx_project (project_id, sort_order),
  CONSTRAINT fk_img_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  logo VARCHAR(190) NULL,
  url VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_visible TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS testimonials (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  role VARCHAR(120) NULL,
  company VARCHAR(120) NULL,
  country VARCHAR(80) NULL,
  photo VARCHAR(190) NULL,
  quote TEXT NOT NULL,
  rating TINYINT NOT NULL DEFAULT 5,
  is_sample TINYINT(1) NOT NULL DEFAULT 0,
  is_visible TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(80) NOT NULL UNIQUE,
  kind ENUM('service','addon') NOT NULL DEFAULT 'service',
  title VARCHAR(120) NOT NULL,
  promise VARCHAR(255) NULL,
  best_for VARCHAR(255) NULL,
  timeline VARCHAR(80) NULL,
  icon VARCHAR(40) NULL,
  description TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_visible TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS service_points (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  service_id INT UNSIGNED NOT NULL,
  point_text VARCHAR(255) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_point_service FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS packages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  tagline VARCHAR(255) NULL,
  price VARCHAR(40) NULL COMMENT 'e.g. $990 or Custom quote',
  price_note VARCHAR(120) NULL,
  is_popular TINYINT(1) NOT NULL DEFAULT 0,
  cta_label VARCHAR(60) NOT NULL DEFAULT 'Get started',
  sort_order INT NOT NULL DEFAULT 0,
  is_visible TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS package_features (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  package_id INT UNSIGNED NOT NULL,
  feature VARCHAR(255) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_feat_package FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS process_steps (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  description TEXT NULL,
  duration VARCHAR(60) NULL,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS faqs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question VARCHAR(255) NOT NULL,
  answer TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_visible TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(80) NOT NULL UNIQUE,
  title VARCHAR(160) NOT NULL,
  content MEDIUMTEXT NULL,
  seo_title VARCHAR(190) NULL,
  seo_description VARCHAR(300) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inquiries (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  company VARCHAR(160) NULL,
  service VARCHAR(120) NULL,
  budget VARCHAR(80) NULL,
  message TEXT NOT NULL,
  link VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  is_replied TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_read (is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45) NOT NULL,
  identifier VARCHAR(190) NOT NULL,
  success TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ip (ip, created_at),
  INDEX idx_ident (identifier, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bucket VARCHAR(60) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_bucket (bucket, ip, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------
-- STARTER CONTENT (replace everything from the admin panel)
-- ---------------------------------------------------------------
INSERT INTO settings (skey, svalue) VALUES
('site_name','brandQED'),
('site_title','brandQED | Brand Strategy, Naming and Identity'),
('tagline','Brand consultancy for founders who want to be remembered'),
('hero_headline','We build brands people remember and trust.'),
('hero_subheadline','Strategy, naming, identity and launch, all under one roof.'),
('hero_btn1_text','View our work'),
('hero_btn1_link','/work'),
('hero_btn2_text','Book a free call'),
('hero_btn2_link','/contact'),
('trust_line','Trusted by founders in 10+ countries'),
('cta_headline','Ready to build a brand that lasts?'),
('cta_text','Tell us about your idea. We reply within one business day.'),
('whatsapp','+8801783475407'),
('email','hello@brandqed.com'),
('address','Bangladesh (working with clients worldwide)'),
('social_instagram',''),
('social_facebook',''),
('social_linkedin',''),
('social_behance',''),
('social_dribbble',''),
('calendly_url',''),
('footer_text','brandQED is a brand consultancy that takes ideas from name to launch.'),
('seo_description','brandQED is a brand consultancy for startups and growing businesses. Brand strategy, naming, identity design and launch support.'),
('og_image',''),
('ga_id',''),
('custom_head',''),
('custom_footer',''),
('logo',''),
('logo_light',''),
('favicon',''),
('admin_notify_email','hello@brandqed.com');

INSERT INTO stats (label, value, suffix, sort_order) VALUES
('Brands built','50','+',1),('Projects delivered','80','+',2),('Countries served','10','+',3),('Years of experience','5','+',4);

INSERT INTO services (id, slug, kind, title, promise, best_for, timeline, icon, description, sort_order) VALUES
(1,'brand-strategy','service','Brand Strategy','Know exactly who you are for, and why they should choose you.','Startups and businesses that need a clear direction before design begins.','2 to 3 weeks','compass','Research-led positioning that gives every later decision a reason.',1),
(2,'naming-messaging','service','Naming & Messaging','A name and a voice that are easy to say, easy to remember and ready to use.','New ventures and rebrands that need a name, tagline and story.','1 to 2 weeks','message','We find the words your brand will live in, then check they are available.',2),
(3,'brand-identity-design','service','Brand Identity Design','A complete visual identity that looks sharp everywhere your brand appears.','Any brand that wants a professional, consistent look.','3 to 5 weeks','palette','Logo, colour, type and guidelines built as one system.',3),
(4,'digital-launch','service','Digital Launch','Go to market with a website, social presence and launch plan that work together.','Brands about to launch or relaunch online.','2 to 4 weeks','rocket','We set up the places customers will find you and plan your first 90 days.',4),
(5,'monthly-brand-support','addon','Monthly Brand Support','A steady design and brand partner after launch.',NULL,'Monthly','repeat','Ongoing design requests, updates and guidance.',5),
(6,'ai-brand-imagery','addon','AI Brand Imagery','On-brand lifestyle and mockup visuals without a photo shoot.',NULL,'3 to 7 days','image','Custom imagery created to match your brand style.',6),
(7,'content-calendar','addon','Content Calendar','A month of post ideas and templates, ready to publish.',NULL,'1 week','calendar','Plan, topics and branded templates for your social channels.',7),
(8,'brand-audit-refresh','addon','Brand Audit & Refresh','Find what is working, fix what is not.',NULL,'1 to 2 weeks','search','A full review of your current brand with a clear action plan.',8);

INSERT INTO service_points (service_id, point_text, sort_order) VALUES
(1,'Market and competitor research',1),(1,'Positioning and unique value proposition',2),(1,'Audience personas',3),(1,'Brand purpose, mission, vision and values',4),(1,'Brand personality and tone of voice',5),(1,'Go-to-market roadmap',6),
(2,'Brand name options with availability checks',1),(2,'Domain and social handle search',2),(2,'Tagline and brand story',3),(2,'Messaging guide',4),(2,'Website and marketing copy',5),
(3,'Logo system with variations',1),(3,'Colour palette and typography',2),(3,'Brand guidelines document',3),(3,'Stationery and social templates',4),(3,'Packaging and mockups',5),
(4,'Website or landing page',1),(4,'Social media profile setup',2),(4,'Launch campaign plan',3),(4,'Ads setup',4),(4,'SEO basics',5);

INSERT INTO packages (id, name, tagline, price, price_note, is_popular, cta_label, sort_order) VALUES
(1,'Starter','For new brands that need a name and a professional look.','$990','one-time, placeholder price',0,'Choose Starter',1),
(2,'Launch','Everything to take a new brand from idea to market.','$2,490','one-time, placeholder price',1,'Choose Launch',2),
(3,'Growth','Launch, plus marketing and ongoing support.','Custom quote','tailored to your goals',0,'Request a quote',3);

INSERT INTO package_features (package_id, feature, sort_order) VALUES
(1,'Brand naming (3 options)',1),(1,'Logo system',2),(1,'Colour and typography',3),(1,'Brand guidelines',4),(1,'Unlimited revisions',5),
(2,'Everything in Starter',1),(2,'Brand strategy and positioning',2),(2,'Messaging guide and tagline',3),(2,'Website or landing page',4),(2,'Social media setup and templates',5),(2,'Unlimited revisions',6),
(3,'Everything in Launch',1),(3,'Launch campaign and ads setup',2),(3,'Content calendar',3),(3,'Monthly brand support',4),(3,'Priority communication',5),(3,'Unlimited revisions',6);

INSERT INTO process_steps (title, description, duration, sort_order) VALUES
('Discovery','We learn about your business, goals, audience and competitors in a focused kickoff call and questionnaire.','2 to 4 days',1),
('Strategy','We turn research into a clear positioning, voice and direction that guides the creative work.','1 to 2 weeks',2),
('Design','We create your name, logo and visual identity, presented with real-world mockups.','2 to 3 weeks',3),
('Review and revisions','You give feedback, we refine. Revisions are unlimited until you love it.','1 week',4),
('Delivery and launch','You receive final files and guidelines, and we help you launch.','2 to 4 days',5);

INSERT INTO faqs (question, answer, sort_order) VALUES
('How long does a brand identity project take?','Most identity projects take 3 to 5 weeks. A full strategy-to-launch project takes 8 to 10 weeks.',1),
('How do payments work?','We work with a deposit to start and the balance at delivery. Larger projects can be split into milestones.',2),
('How many revisions do I get?','Revisions are unlimited in every package. We refine until you are happy.',3),
('What files will I receive?','Logo files in vector and image formats, colour and font details, a brand guidelines document and social media templates.',4),
('Do you work with clients outside Bangladesh?','Yes. Most of our clients are international. We work online through video calls, chat and shared files.',5),
('Can you help with a website too?','Yes. The Launch and Growth packages include a website or landing page.',6),
('Do I own the final designs?','Yes. After final payment, all rights to the final brand assets transfer to you.',7),
('How do we get started?','Send a message or book a free call. We will discuss your goals and suggest the best package.',8);

INSERT INTO testimonials (name, role, company, country, quote, rating, is_sample, sort_order) VALUES
('Sample Client','Founder','Sample Company','United States','SAMPLE: Replace this with a real client review from the admin panel.',5,1,1),
('Sample Client','Co-founder','Sample Studio','United Kingdom','SAMPLE: Replace this with a real client review from the admin panel.',5,1,2),
('Sample Client','CEO','Sample Brand','Canada','SAMPLE: Replace this with a real client review from the admin panel.',5,1,3);

INSERT INTO projects (title, slug, client_name, industry, country, categories, project_year, overview, challenge, solution, result, is_featured, is_sample, sort_order) VALUES
('Sample Project One','sample-project-one','Sample Client','Technology','United States','brand-strategy,brand-identity-design',2026,'SAMPLE project. Replace with your real work.','Describe the problem the client had.','Describe what you designed and why.','Describe the outcome.',1,1,1),
('Sample Project Two','sample-project-two','Sample Client','Food and Beverage','United Kingdom','naming-messaging,brand-identity-design',2026,'SAMPLE project. Replace with your real work.','Describe the problem the client had.','Describe what you designed and why.','Describe the outcome.',1,1,2),
('Sample Project Three','sample-project-three','Sample Client','Finance','Canada','brand-identity-design,digital-launch',2026,'SAMPLE project. Replace with your real work.','Describe the problem the client had.','Describe what you designed and why.','Describe the outcome.',1,1,3);

INSERT INTO pages (slug, title, content, seo_title, seo_description) VALUES
('about','About brandQED','<p>brandQED is a brand consultancy led by a brand identity designer who believes strong brands begin with clear thinking.</p><p>We work with founders and growing businesses around the world, taking them from a first idea to a confident launch: strategy, naming, identity and digital presence in one connected process.</p><h3>What we value</h3><ul><li>Clarity before creativity</li><li>Honest, regular communication</li><li>Design that works in the real world</li></ul><p>Edit this page from the admin panel to tell your own story.</p>','About brandQED','Meet the brand consultancy behind brandQED.'),
('privacy','Privacy Policy','<p>This is a starter privacy policy. We collect only the information you send through our contact form (name, email and message) to reply to your enquiry. We do not sell your data. Replace this text with a policy reviewed for your business.</p>','Privacy Policy','How brandQED handles your information.'),
('terms','Terms of Service','<p>This is a starter terms page. Project scope, payment terms and ownership are agreed in writing before work starts. Replace this text with terms reviewed for your business.</p>','Terms of Service','Terms for working with brandQED.');
